# A Jornada de Jason: Ecos de Yarin — Base de desenvolvimento

Base inicial de scripts C# para Unity 3D + URP, pensada para Android e controles por toque.

## Conteúdo
- Movimento do Jason com CharacterController, pulo e dash.
- Joystick virtual para tela touch.
- Câmera orbital com rotação por toque e colisão.
- Vida/dano reutilizável.
- Sistema inicial de armas (manopla gravitacional, canhão de impacto e cajado elemental).
- Placa de pressão para puzzles.
- IA simples de patrulha/perseguição.
- Carregamento de cenas.

## Como instalar
1. Crie um projeto Unity 3D (URP) usando uma versão LTS compatível.
2. Copie a pasta `Assets/Scripts` deste pacote para a pasta `Assets` do projeto.
3. Adicione `CharacterController` ao Jason e atribua a câmera e o joystick no Inspector.
4. Configure o Input Manager legado (Horizontal, Vertical, Jump) ou adapte para o Input System. Esta base usa `UnityEngine.Input`.
5. Configure as cenas em File > Build Profiles/Build Settings.

## Observações honestas
Isto é uma base de programação, não um jogo completo pronto para publicar. Ainda faltam modelos, animações, áudio, VFX, UI final, mapas, checkpoints, save, balanceamento, integração de assets e testes reais no dispositivo. Os sistemas usam primitivas e referências configuradas no Inspector.

## Regiões previstas
1. Floresta das Correntezas
2. Ruínas dos Sábios
3. Picos Congelados
4. Ilha de Obsidiana
5. Cidadela de Malakor

Alvo de otimização: Android; validar FPS, memória, aquecimento e compatibilidade no aparelho real antes de lançamento.
