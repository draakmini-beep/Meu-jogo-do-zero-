using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public sealed class JasonController : MonoBehaviour
{
    [Header("Movimento")]
    [SerializeField] private float moveSpeed = 5.5f;
    [SerializeField] private float rotationSpeed = 12f;
    [SerializeField] private float jumpHeight = 1.5f;
    [SerializeField] private float gravity = -22f;
    [SerializeField] private float dashSpeed = 12f;
    [SerializeField] private float dashDuration = 0.18f;
    [Header("Referências")]
    [SerializeField] private Transform cameraTransform;
    [SerializeField] private VirtualJoystick joystick;
    [SerializeField] private Animator animator;
    private CharacterController controller;
    private Vector3 verticalVelocity;
    private float dashTimer;
    private Vector3 dashDirection;

    private void Awake() => controller = GetComponent<CharacterController>();

    private void Update()
    {
        Vector2 input = joystick != null && joystick.Value.sqrMagnitude > 0.001f
            ? joystick.Value : new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        Vector3 forward = cameraTransform ? Vector3.ProjectOnPlane(cameraTransform.forward, Vector3.up).normalized : Vector3.forward;
        Vector3 right = cameraTransform ? Vector3.ProjectOnPlane(cameraTransform.right, Vector3.up).normalized : Vector3.right;
        Vector3 move = Vector3.ClampMagnitude(forward * input.y + right * input.x, 1f);

        if (controller.isGrounded && verticalVelocity.y < 0) verticalVelocity.y = -2f;
        if ((Input.GetButtonDown("Jump")) && controller.isGrounded) verticalVelocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
        if (Input.GetKeyDown(KeyCode.LeftShift) && dashTimer <= 0f && move.sqrMagnitude > 0.05f)
        { dashDirection = move.normalized; dashTimer = dashDuration; }

        if (dashTimer > 0f)
        {
            dashTimer -= Time.deltaTime;
            controller.Move(dashDirection * dashSpeed * Time.deltaTime);
        }
        else controller.Move(move * moveSpeed * Time.deltaTime);

        verticalVelocity.y += gravity * Time.deltaTime;
        controller.Move(verticalVelocity * Time.deltaTime);
        if (move.sqrMagnitude > 0.01f)
        {
            Quaternion target = Quaternion.LookRotation(move, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, target, rotationSpeed * Time.deltaTime);
        }
        if (animator) animator.SetFloat("Speed", move.magnitude);
    }
}
