using UnityEngine;

[RequireComponent(typeof(HealthSystem))]
public sealed class EnemyGuardAI : MonoBehaviour
{
    [SerializeField] private Transform player;
    [SerializeField] private float detectionRange = 10f;
    [SerializeField] private float attackRange = 1.8f;
    [SerializeField] private float moveSpeed = 2.8f;
    [SerializeField] private float attackCooldown = 1.4f;
    [SerializeField] private float damage = 12f;
    [SerializeField] private LayerMask lineOfSightMask = ~0;
    private float nextAttack;
    private HealthSystem playerHealth;

    private void Update()
    {
        if (!player) return;
        float distance = Vector3.Distance(transform.position, player.position);
        if (distance > detectionRange) return;
        Vector3 toPlayer = player.position - transform.position;
        Vector3 flat = Vector3.ProjectOnPlane(toPlayer, Vector3.up);
        if (flat.sqrMagnitude > 0.01f) transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(flat), 8f * Time.deltaTime);
        if (distance > attackRange) transform.position += flat.normalized * moveSpeed * Time.deltaTime;
        else if (Time.time >= nextAttack && HasLineOfSight())
        {
            if (!playerHealth) playerHealth = player.GetComponentInParent<HealthSystem>();
            playerHealth?.TakeDamage(damage);
            nextAttack = Time.time + attackCooldown;
        }
    }
    private bool HasLineOfSight()
    {
        Vector3 origin = transform.position + Vector3.up;
        Vector3 target = player.position + Vector3.up;
        if (Physics.Linecast(origin, target, out RaycastHit hit, lineOfSightMask, QueryTriggerInteraction.Ignore))
            return hit.transform == player || hit.transform.IsChildOf(player);
        return true;
    }
}
