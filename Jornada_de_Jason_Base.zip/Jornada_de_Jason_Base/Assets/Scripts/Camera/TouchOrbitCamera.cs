using UnityEngine;

public sealed class TouchOrbitCamera : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private Vector3 offset = new Vector3(0, 2.5f, -5f);
    [SerializeField] private float sensitivity = 0.12f;
    [SerializeField] private float minPitch = -25f;
    [SerializeField] private float maxPitch = 65f;
    [SerializeField] private float followSmooth = 12f;
    [SerializeField] private LayerMask collisionMask = ~0;
    [SerializeField] private float collisionRadius = 0.2f;
    private float yaw;
    private float pitch = 15f;
    private int activeFinger = -1;

    private void LateUpdate()
    {
        if (!target) return;
        ReadLookInput();
        Quaternion rotation = Quaternion.Euler(pitch, yaw, 0);
        Vector3 desired = target.position + rotation * offset;
        Vector3 direction = desired - target.position;
        float distance = direction.magnitude;
        if (distance > 0.001f && Physics.SphereCast(target.position, collisionRadius, direction.normalized,
            out RaycastHit hit, distance, collisionMask, QueryTriggerInteraction.Ignore))
            desired = target.position + direction.normalized * Mathf.Max(0.25f, hit.distance - 0.12f);
        transform.position = Vector3.Lerp(transform.position, desired, followSmooth * Time.deltaTime);
        transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(target.position + Vector3.up * 1.2f - transform.position), followSmooth * Time.deltaTime);
    }

    private void ReadLookInput()
    {
        if (Input.touchCount == 0) { activeFinger = -1; return; }
        for (int i = 0; i < Input.touchCount; i++)
        {
            Touch t = Input.GetTouch(i);
            if (t.phase == TouchPhase.Began && t.position.x > Screen.width * 0.45f) activeFinger = t.fingerId;
            if (t.fingerId != activeFinger) continue;
            if (t.phase == TouchPhase.Moved)
            { yaw += t.deltaPosition.x * sensitivity; pitch -= t.deltaPosition.y * sensitivity; pitch = Mathf.Clamp(pitch, minPitch, maxPitch); }
            if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled) activeFinger = -1;
        }
#if UNITY_EDITOR || UNITY_STANDALONE
        if (Input.GetMouseButton(1)) { yaw += Input.GetAxis("Mouse X") * 4f; pitch -= Input.GetAxis("Mouse Y") * 4f; pitch = Mathf.Clamp(pitch, minPitch, maxPitch); }
#endif
    }
}
