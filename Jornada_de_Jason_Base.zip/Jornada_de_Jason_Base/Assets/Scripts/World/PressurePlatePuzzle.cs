using UnityEngine;
using UnityEngine.Events;

public sealed class PressurePlatePuzzle : MonoBehaviour
{
    [SerializeField] private LayerMask activatorMask;
    [SerializeField] private Vector3 boxSize = new Vector3(2f, 0.5f, 2f);
    [SerializeField] private Transform door;
    [SerializeField] private Vector3 doorOpenOffset = new Vector3(0, 3f, 0);
    [SerializeField] private float doorMoveSpeed = 2f;
    [SerializeField] private UnityEvent onActivated;
    private Vector3 doorClosedPosition;
    private bool activated;

    private void Start() { if (door) doorClosedPosition = door.position; }
    private void Update()
    {
        bool pressed = Physics.CheckBox(transform.position, boxSize * 0.5f, transform.rotation, activatorMask, QueryTriggerInteraction.Ignore);
        if (pressed && !activated) { activated = true; onActivated?.Invoke(); }
        if (door)
        {
            Vector3 target = activated ? doorClosedPosition + doorOpenOffset : doorClosedPosition;
            door.position = Vector3.MoveTowards(door.position, target, doorMoveSpeed * Time.deltaTime);
        }
    }
    private void OnDrawGizmosSelected() { Gizmos.color = Color.cyan; Gizmos.matrix = Matrix4x4.TRS(transform.position, transform.rotation, Vector3.one); Gizmos.DrawWireCube(Vector3.zero, boxSize); }
}
