using UnityEngine;
using UnityEngine.SceneManagement;

public static class SceneLoader
{
    public static void Load(string sceneName)
    {
        if (string.IsNullOrWhiteSpace(sceneName)) { Debug.LogError("Nome da cena vazio."); return; }
        SceneManager.LoadScene(sceneName, LoadSceneMode.Single);
    }
}
