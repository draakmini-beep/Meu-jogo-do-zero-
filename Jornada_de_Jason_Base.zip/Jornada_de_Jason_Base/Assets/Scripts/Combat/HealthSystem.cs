using System;
using UnityEngine;

public sealed class HealthSystem : MonoBehaviour
{
    [SerializeField, Min(1)] private float maxHealth = 100f;
    [SerializeField] private bool destroyOnDeath;
    public float CurrentHealth { get; private set; }
    public float Normalized => maxHealth <= 0 ? 0 : CurrentHealth / maxHealth;
    public event Action<float, float> HealthChanged;
    public event Action Died;

    private void Awake() => CurrentHealth = maxHealth;
    public void TakeDamage(float amount)
    {
        if (amount <= 0 || CurrentHealth <= 0) return;
        CurrentHealth = Mathf.Max(0, CurrentHealth - amount);
        HealthChanged?.Invoke(CurrentHealth, maxHealth);
        if (CurrentHealth <= 0) { Died?.Invoke(); if (destroyOnDeath) Destroy(gameObject); }
    }
    public void Heal(float amount)
    {
        if (amount <= 0 || CurrentHealth <= 0) return;
        CurrentHealth = Mathf.Min(maxHealth, CurrentHealth + amount);
        HealthChanged?.Invoke(CurrentHealth, maxHealth);
    }
}
