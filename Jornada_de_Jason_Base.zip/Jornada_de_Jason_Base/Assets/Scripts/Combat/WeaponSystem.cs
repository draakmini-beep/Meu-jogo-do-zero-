using UnityEngine;

public sealed class WeaponSystem : MonoBehaviour
{
    public enum WeaponType { GravityGauntlet, ImpactCannon, ElementalStaff }
    [SerializeField] private Camera aimCamera;
    [SerializeField] private Transform firePoint;
    [SerializeField] private float range = 35f;
    [SerializeField] private LayerMask hitMask = ~0;
    [SerializeField] private WeaponType equippedWeapon;
    [SerializeField] private float gravityForce = 18f;
    [SerializeField] private float impactDamage = 35f;
    [SerializeField] private float elementalDamage = 22f;

    public void Equip(WeaponType weapon) => equippedWeapon = weapon;
    public void Fire()
    {
        if (!aimCamera) return;
        Ray ray = aimCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f));
        if (!Physics.Raycast(ray, out RaycastHit hit, range, hitMask, QueryTriggerInteraction.Ignore)) return;
        Rigidbody body = hit.rigidbody;
        switch (equippedWeapon)
        {
            case WeaponType.GravityGauntlet:
                if (body && !body.isKinematic) body.AddForce((aimCamera.transform.position - hit.point).normalized * gravityForce, ForceMode.Impulse);
                break;
            case WeaponType.ImpactCannon:
                hit.collider.GetComponentInParent<HealthSystem>()?.TakeDamage(impactDamage);
                if (body && !body.isKinematic) body.AddForceAtPosition(ray.direction * 14f, hit.point, ForceMode.Impulse);
                break;
            case WeaponType.ElementalStaff:
                hit.collider.GetComponentInParent<HealthSystem>()?.TakeDamage(elementalDamage);
                break;
        }
    }
}
