using UnityEngine;
using UnityEngine.EventSystems;

public sealed class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
{
    [SerializeField] private RectTransform background;
    [SerializeField] private RectTransform handle;
    [SerializeField, Range(0.1f, 1f)] private float handleRange = 0.6f;
    public Vector2 Value { get; private set; }

    public void OnPointerDown(PointerEventData eventData) => OnDrag(eventData);

    public void OnDrag(PointerEventData eventData)
    {
        if (background == null || handle == null) return;
        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(background, eventData.position,
            eventData.pressEventCamera, out Vector2 local)) return;
        Vector2 half = background.rect.size * 0.5f;
        Value = new Vector2(half.x > 0 ? local.x / half.x : 0, half.y > 0 ? local.y / half.y : 0);
        Value = Vector2.ClampMagnitude(Value, 1f);
        handle.anchoredPosition = new Vector2(Value.x * half.x * handleRange, Value.y * half.y * handleRange);
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        Value = Vector2.zero;
        if (handle != null) handle.anchoredPosition = Vector2.zero;
    }
}
