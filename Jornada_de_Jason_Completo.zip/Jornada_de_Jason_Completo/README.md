# A Jornada de Jason: Ecos de Yarin — pacote consolidado Unity 6

**Conteúdo:** scripts e documentação recuperados dos pacotes disponíveis das etapas 223–236, organizados em `Assets/` e `Docs/`.

- Arquivos de projeto recuperados: 88
- Conflitos de mesmo caminho com conteúdo diferente ignorados após a primeira cópia: 16
- Pacotes ZIP originais preservados em `_SourcePackages/`.
- `Packages/manifest.json` incluído como ponto de partida (URP, Input System e uGUI).

## Importante
Este é um **pacote consolidado de scripts/documentação**, não um projeto Unity completo e nem um APK. Os ZIPs-fonte não continham todas as cenas, prefabs, assets artísticos/sonoros e configurações completas necessárias para afirmar que o jogo abre/compila/builda sem ajustes. Veja `Docs/CONFIGURACAO_UNITY6_ANDROID.md`.

## Instalação
Crie um projeto Unity 6 URP novo e copie `Assets/` para ele. Mescle o manifest de Packages, abra o Editor e resolva erros de compilação antes de integrar cenas e prefabs.
