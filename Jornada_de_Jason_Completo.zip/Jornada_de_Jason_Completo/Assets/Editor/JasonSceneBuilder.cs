#if UNITY_EDITOR
using System.IO;
using JornadaDeJason;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// Gera uma fase jogável de teste com todos os sistemas ligados (Jason, câmera, joystick,
/// rio com flutuabilidade, placa de pressão, armas, power-up, moedas e um inimigo).
/// Menus: Tools > A Jornada de Jason
/// </summary>
public static class JasonSceneBuilder
{
    private const string ScenePath = "Assets/Scenes/Fase_Teste.unity";
    private const string GeneratedDir = "Assets/_Project/Generated";

    [MenuItem("Tools/A Jornada de Jason/Gerar Cena Jogável de Teste")]
    public static void BuildTestScene()
    {
        Directory.CreateDirectory("Assets/Scenes");
        Directory.CreateDirectory(GeneratedDir + "/Materials");
        AssetDatabase.Refresh();

        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        Material grass = MakeMat("Grama", new Color(0.35f, 0.7f, 0.3f));
        Material rock = MakeMat("Rocha", new Color(0.5f, 0.5f, 0.55f));
        Material water = MakeMat("Agua", new Color(0.2f, 0.5f, 0.9f));
        Material wood = MakeMat("Madeira", new Color(0.65f, 0.45f, 0.25f));
        Material metal = MakeMat("Metal", new Color(0.3f, 0.3f, 0.35f));
        Material gold = MakeMat("Dourado", new Color(1f, 0.8f, 0.1f));
        Material blue = MakeMat("Jason", new Color(0.2f, 0.4f, 0.9f));
        Material red = MakeMat("Inimigo", new Color(0.85f, 0.2f, 0.2f));
        Material plateMat = MakeMat("Placa", new Color(0.9f, 0.6f, 0.1f));
        Material power = MakeMat("PowerUp", new Color(0.7f, 0.3f, 0.9f));

        // ---------- Luz ----------
        var lightGo = new GameObject("Luz Direcional");
        var light = lightGo.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.1f;
        lightGo.transform.rotation = Quaternion.Euler(50f, -30f, 0f);

        // ---------- Terreno com rio no meio (x entre 6 e 14) ----------
        Prim(PrimitiveType.Cube, "Terreno Esquerdo", new Vector3(-12f, -0.5f, 0f), new Vector3(36f, 1f, 60f), grass);
        Prim(PrimitiveType.Cube, "Terreno Direito", new Vector3(22f, -0.5f, 0f), new Vector3(16f, 1f, 60f), grass);
        Prim(PrimitiveType.Cube, "Leito do Rio", new Vector3(10f, -2.5f, 0f), new Vector3(8f, 1f, 60f), rock);

        // Volume de água: topo em y = -0.5
        GameObject waterGo = Prim(PrimitiveType.Cube, "Rio", new Vector3(10f, -1.25f, 0f), new Vector3(8f, 1.5f, 60f), water);
        waterGo.AddComponent<WaterBuoyancy>(); // o script força Is Trigger no Awake
        waterGo.GetComponent<Collider>().isTrigger = true;

        // Portão que a placa de pressão abre
        GameObject gate = Prim(PrimitiveType.Cube, "Portao", new Vector3(-14f, 1.5f, 10f), new Vector3(8f, 3f, 0.6f), rock);

        // Colunas decorativas nos limites
        Prim(PrimitiveType.Cube, "Muro Norte", new Vector3(0f, 2f, 30.5f), new Vector3(60f, 4f, 1f), rock);
        Prim(PrimitiveType.Cube, "Muro Sul", new Vector3(0f, 2f, -30.5f), new Vector3(60f, 4f, 1f), rock);
        Prim(PrimitiveType.Cube, "Muro Oeste", new Vector3(-30.5f, 2f, 0f), new Vector3(1f, 4f, 60f), rock);
        Prim(PrimitiveType.Cube, "Muro Leste", new Vector3(30.5f, 2f, 0f), new Vector3(1f, 4f, 60f), rock);

        // ---------- NavMesh (antes dos objetos dinâmicos) ----------
        BakeNavMesh();

        // ---------- Blocos de física (densidade = massa, pois o volume é 1) ----------
        MakeBlock("Bloco de Madeira", new Vector3(-4f, 1f, -3f), 0.6f, wood);
        MakeBlock("Bloco de Pedra", new Vector3(-4f, 1f, 0f), 2.6f, rock);
        MakeBlock("Bloco de Metal", new Vector3(-4f, 1f, 3f), 7.8f, metal);
        MakeBlock("Bloco de Madeira 2", new Vector3(-2f, 1f, -3f), 0.6f, wood);

        // ---------- Placa de pressão (exige a massa da pedra: 2.5) ----------
        var plate = new GameObject("Placa de Pressao");
        plate.transform.position = new Vector3(-14f, 0f, 0f);
        var plateTrigger = plate.AddComponent<BoxCollider>();
        plateTrigger.center = new Vector3(0f, 0.5f, 0f);
        plateTrigger.size = new Vector3(2f, 1f, 2f);
        plateTrigger.isTrigger = true;
        GameObject plateVisual = Prim(PrimitiveType.Cube, "Visual da Placa", new Vector3(-14f, 0.05f, 0f), new Vector3(2f, 0.1f, 2f), plateMat);
        plateVisual.transform.SetParent(plate.transform, true);
        var platePuzzle = plate.AddComponent<PressurePlatePuzzle>();
        SetFloat(platePuzzle, "requiredWeight", 2.5f);
        SetObj(platePuzzle, "plateVisual", plateVisual.transform);
        UnityEventTools.AddBoolPersistentListener(platePuzzle.onActivated, gate.SetActive, false);
        UnityEventTools.AddBoolPersistentListener(platePuzzle.onDeactivated, gate.SetActive, true);

        // ---------- Power-up e moedas ----------
        GameObject pu = Prim(PrimitiveType.Sphere, "Power-up Gravidade Zero", new Vector3(-6f, 1f, -7f), Vector3.one * 0.8f, power);
        pu.GetComponent<Collider>().isTrigger = true;
        pu.AddComponent<MapPowerUp>();

        for (int i = 0; i < 5; i++)
        {
            GameObject coin = Prim(PrimitiveType.Cylinder, "Moeda " + (i + 1), new Vector3(-16f + i * 2f, 1f, -6f), new Vector3(0.6f, 0.08f, 0.6f), gold);
            coin.transform.rotation = Quaternion.Euler(90f, 0f, 0f);
            coin.GetComponent<Collider>().isTrigger = true;
            coin.AddComponent<CoinPickup>();
        }

        // ---------- Jason ----------
        GameObject jason = Prim(PrimitiveType.Capsule, "Jason", new Vector3(-10f, 1.1f, -2f), Vector3.one, blue);
        jason.tag = "Player";
        Object.DestroyImmediate(jason.GetComponent<Collider>());
        var cc = jason.AddComponent<CharacterController>();
        cc.height = 2f;
        cc.radius = 0.5f;
        cc.center = Vector3.zero;
        var health = jason.AddComponent<HealthSystem>();
        var controller = jason.AddComponent<JasonController>();
        var weapons = jason.AddComponent<WeaponSystem>();
        var hold = new GameObject("PontoDeMira");
        hold.transform.SetParent(jason.transform, false);
        hold.transform.localPosition = new Vector3(0f, 0.8f, 2.5f);
        SetObj(weapons, "holdPoint", hold.transform);

        // ---------- Câmera ----------
        var camGo = new GameObject("Main Camera");
        camGo.tag = "MainCamera";
        var cam = camGo.AddComponent<Camera>();
        cam.clearFlags = CameraClearFlags.Skybox;
        cam.nearClipPlane = 0.1f;
        camGo.AddComponent<AudioListener>();
        camGo.transform.position = new Vector3(-10f, 4f, -9f);
        var orbit = camGo.AddComponent<TouchOrbitCamera>();
        SetObj(orbit, "target", jason.transform);
        SetObj(weapons, "aimCamera", cam);
        SetObj(controller, "cameraTransform", camGo.transform);

        // ---------- Inimigo ----------
        BuildEnemy(red, jason.transform);

        // ---------- Interface ----------
        BuildUi(controller, weapons, orbit, health);

        // ---------- Salvar e registrar nas Build Settings ----------
        EditorSceneManager.SaveScene(scene, ScenePath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        AssetDatabase.SaveAssets();
        Debug.Log("[JasonSceneBuilder] Cena gerada em " + ScenePath + " e adicionada às Build Settings.");
    }

    [MenuItem("Tools/A Jornada de Jason/Gerar Cena e Compilar APK (tudo de uma vez)")]
    public static void BuildSceneAndApk()
    {
        BuildTestScene();
        JasonAndroidBuild236.BuildAndroidApk();
    }

    // ===================================================================================
    // Construção de partes
    // ===================================================================================

    private static void MakeBlock(string name, Vector3 pos, float mass, Material mat)
    {
        GameObject b = Prim(PrimitiveType.Cube, name, pos, Vector3.one, mat);
        var rb = b.AddComponent<Rigidbody>();
        rb.mass = mass;
        rb.linearDamping = 0.1f;
    }

    private static void BuildEnemy(Material mat, Transform player)
    {
        GameObject enemy = Prim(PrimitiveType.Capsule, "Sentinela", new Vector3(-2f, 1f, 12f), Vector3.one, mat);
        var agent = enemy.AddComponent<NavMeshAgent>();
        agent.height = 2f;
        agent.radius = 0.5f;
        agent.baseOffset = 1f; // o pivô da cápsula fica no centro
        var rb = enemy.AddComponent<Rigidbody>();
        rb.isKinematic = true;

        var hp = enemy.AddComponent<HealthSystem>();
        SetBool(hp, "takesImpactDamage", true);
        SetBool(hp, "destroyOnDeath", true);

        var ai = enemy.AddComponent<EnemyGuardAI>();
        var wpA = new GameObject("Waypoint A");
        wpA.transform.position = new Vector3(-8f, 0f, 14f);
        var wpB = new GameObject("Waypoint B");
        wpB.transform.position = new Vector3(4f, 0f, 14f);
        SetObjArray(ai, "waypoints", new Object[] { wpA.transform, wpB.transform });
        SetObj(ai, "player", player);
    }

    // Usa reflexão para não quebrar a compilação caso o pacote AI Navigation não esteja instalado.
    private static void BakeNavMesh()
    {
        var surfaceType = System.Type.GetType("Unity.AI.Navigation.NavMeshSurface, Unity.AI.Navigation");
        if (surfaceType == null)
        {
            Debug.LogWarning("[JasonSceneBuilder] Pacote AI Navigation ausente. Instale 'com.unity.ai.navigation' para o inimigo patrulhar.");
            return;
        }

        var host = new GameObject("NavMesh Surface");
        Component surface = host.AddComponent(surfaceType);
        var build = surfaceType.GetMethod("BuildNavMesh", System.Type.EmptyTypes);
        if (build == null) return;
        build.Invoke(surface, null);

        var dataProp = surfaceType.GetProperty("navMeshData");
        var data = dataProp != null ? dataProp.GetValue(surface) as Object : null;
        if (data != null)
        {
            string path = GeneratedDir + "/NavMesh_FaseTeste.asset";
            AssetDatabase.DeleteAsset(path);
            AssetDatabase.CreateAsset(data, path);
        }
    }

    private static void BuildUi(JasonController controller, WeaponSystem weapons, TouchOrbitCamera orbit, HealthSystem health)
    {
        // EventSystem com o módulo de entrada correto para o projeto.
        var es = new GameObject("EventSystem", typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM
        es.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();
#else
        es.AddComponent<StandaloneInputModule>();
#endif

        var canvasGo = new GameObject("Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        var canvas = canvasGo.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasGo.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920f, 1080f);
        scaler.matchWidthOrHeight = 0.5f;

        var res = new DefaultControls.Resources
        {
            standard = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/UISprite.psd"),
            background = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/Background.psd"),
            knob = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/Knob.psd"),
            checkmark = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/Checkmark.psd"),
            dropdown = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/DropdownArrow.psd"),
            inputField = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/InputFieldBackground.psd"),
            mask = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/UIMask.psd")
        };
        Sprite circle = res.knob;

        // Zona de arrasto da câmera: metade direita da tela (criada primeiro, fica atrás dos botões).
        var lookGo = new GameObject("Zona de Olhar", typeof(RectTransform), typeof(Image), typeof(TouchLookZone));
        lookGo.transform.SetParent(canvasGo.transform, false);
        var lookRt = (RectTransform)lookGo.transform;
        lookRt.anchorMin = new Vector2(0.4f, 0f);
        lookRt.anchorMax = new Vector2(1f, 1f);
        lookRt.offsetMin = Vector2.zero;
        lookRt.offsetMax = Vector2.zero;
        var lookImg = lookGo.GetComponent<Image>();
        lookImg.color = new Color(1f, 1f, 1f, 0.003f);
        SetObj(orbit, "lookZone", lookGo.GetComponent<TouchLookZone>());

        // Joystick virtual (canto inferior esquerdo)
        var joyGo = new GameObject("Joystick", typeof(RectTransform), typeof(Image), typeof(VirtualJoystick));
        joyGo.transform.SetParent(canvasGo.transform, false);
        Place(joyGo, new Vector2(0f, 0f), new Vector2(0.5f, 0.5f), new Vector2(220f, 220f), new Vector2(280f, 280f));
        var joyImg = joyGo.GetComponent<Image>();
        joyImg.sprite = circle;
        joyImg.color = new Color(1f, 1f, 1f, 0.25f);

        var handleGo = new GameObject("Alca", typeof(RectTransform), typeof(Image));
        handleGo.transform.SetParent(joyGo.transform, false);
        Place(handleGo, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(110f, 110f));
        var handleImg = handleGo.GetComponent<Image>();
        handleImg.sprite = circle;
        handleImg.color = new Color(1f, 1f, 1f, 0.65f);
        handleImg.raycastTarget = false;

        var joy = joyGo.GetComponent<VirtualJoystick>();
        SetObj(joy, "background", joyGo.transform);
        SetObj(joy, "handle", handleGo.transform);
        SetObj(controller, "joystick", joy);

        // Botões de ação (canto inferior direito)
        MakeButton(res, canvasGo.transform, "Pular", new Vector2(-60f, 60f), controller.Jump);
        MakeButton(res, canvasGo.transform, "Dash", new Vector2(-240f, 60f), controller.Dash);
        MakeButton(res, canvasGo.transform, "Atirar", new Vector2(-60f, 240f), weapons.OnFirePressed);
        MakeButton(res, canvasGo.transform, "Arma", new Vector2(-240f, 240f), weapons.NextWeapon);

        // Barra de vida (topo esquerdo)
        GameObject sliderGo = DefaultControls.CreateSlider(res);
        sliderGo.name = "Barra de Vida";
        sliderGo.transform.SetParent(canvasGo.transform, false);
        Place(sliderGo, new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(40f, -40f), new Vector2(420f, 32f));
        var slider = sliderGo.GetComponent<Slider>();
        slider.interactable = false;
        Transform handleArea = sliderGo.transform.Find("Handle Slide Area");
        if (handleArea != null) Object.DestroyImmediate(handleArea.gameObject);
        SetObj(health, "healthBar", slider);

        // Moedas (topo direito)
        var coinsGo = new GameObject("Moedas", typeof(RectTransform), typeof(Text), typeof(CoinsLabel));
        coinsGo.transform.SetParent(canvasGo.transform, false);
        Place(coinsGo, new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(-40f, -40f), new Vector2(360f, 56f));
        var coinsText = coinsGo.GetComponent<Text>();
        coinsText.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        coinsText.fontSize = 40;
        coinsText.alignment = TextAnchor.UpperRight;
        coinsText.color = Color.white;
        coinsText.text = "Moedas: 0";
        SetObj(coinsGo.GetComponent<CoinsLabel>(), "label", coinsText);
    }

    private static void MakeButton(DefaultControls.Resources res, Transform parent, string label, Vector2 pos, UnityEngine.Events.UnityAction action)
    {
        GameObject b = DefaultControls.CreateButton(res);
        b.name = "Botao " + label;
        b.transform.SetParent(parent, false);
        Place(b, new Vector2(1f, 0f), new Vector2(1f, 0f), pos, new Vector2(160f, 160f));
        var text = b.GetComponentInChildren<Text>();
        if (text != null)
        {
            text.text = label;
            text.fontSize = 32;
        }
        UnityEventTools.AddPersistentListener(b.GetComponent<Button>().onClick, action);
    }

    // ===================================================================================
    // Utilidades
    // ===================================================================================

    private static void Place(GameObject go, Vector2 anchor, Vector2 pivot, Vector2 pos, Vector2 size)
    {
        var rt = go.GetComponent<RectTransform>();
        rt.anchorMin = anchor;
        rt.anchorMax = anchor;
        rt.pivot = pivot;
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
    }

    private static GameObject Prim(PrimitiveType type, string name, Vector3 pos, Vector3 scale, Material mat)
    {
        GameObject g = GameObject.CreatePrimitive(type);
        g.name = name;
        g.transform.position = pos;
        g.transform.localScale = scale;
        if (mat != null) g.GetComponent<Renderer>().sharedMaterial = mat;
        return g;
    }

    private static Material MakeMat(string name, Color color)
    {
        Shader sh = Shader.Find("Universal Render Pipeline/Lit");
        if (sh == null) sh = Shader.Find("Standard");
        var m = new Material(sh) { name = name };
        if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor", color);
        if (m.HasProperty("_Color")) m.SetColor("_Color", color);

        string path = GeneratedDir + "/Materials/" + name + ".mat";
        AssetDatabase.DeleteAsset(path);
        AssetDatabase.CreateAsset(m, path);
        return m;
    }

    private static void SetObj(Object target, string field, Object value)
    {
        var so = new SerializedObject(target);
        var p = so.FindProperty(field);
        if (p == null) { Debug.LogWarning("[JasonSceneBuilder] Campo não encontrado: " + target.GetType().Name + "." + field); return; }
        p.objectReferenceValue = value;
        so.ApplyModifiedPropertiesWithoutUndo();
    }

    private static void SetFloat(Object target, string field, float value)
    {
        var so = new SerializedObject(target);
        var p = so.FindProperty(field);
        if (p == null) { Debug.LogWarning("[JasonSceneBuilder] Campo não encontrado: " + target.GetType().Name + "." + field); return; }
        p.floatValue = value;
        so.ApplyModifiedPropertiesWithoutUndo();
    }

    private static void SetBool(Object target, string field, bool value)
    {
        var so = new SerializedObject(target);
        var p = so.FindProperty(field);
        if (p == null) { Debug.LogWarning("[JasonSceneBuilder] Campo não encontrado: " + target.GetType().Name + "." + field); return; }
        p.boolValue = value;
        so.ApplyModifiedPropertiesWithoutUndo();
    }

    private static void SetObjArray(Object target, string field, Object[] values)
    {
        var so = new SerializedObject(target);
        var p = so.FindProperty(field);
        if (p == null) { Debug.LogWarning("[JasonSceneBuilder] Campo não encontrado: " + target.GetType().Name + "." + field); return; }
        p.arraySize = values.Length;
        for (int i = 0; i < values.Length; i++) p.GetArrayElementAtIndex(i).objectReferenceValue = values[i];
        so.ApplyModifiedPropertiesWithoutUndo();
    }
}
#endif
