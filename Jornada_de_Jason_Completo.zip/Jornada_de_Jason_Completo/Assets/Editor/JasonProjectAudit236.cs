#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class JasonProjectAudit236
{
    [MenuItem("Tools/A Jornada de Jason/Auditoria Etapa 236")]
    public static void Run()
    {
        int errors = 0;
        int warnings = 0;

        if (EditorBuildSettings.scenes.Length == 0)
        {
            Debug.LogError("[Jason Audit] Nenhuma cena cadastrada em Build Settings.");
            errors++;
        }
        else
        {
            foreach (var scene in EditorBuildSettings.scenes)
            {
                if (!scene.enabled)
                {
                    Debug.LogWarning("[Jason Audit] Cena desativada: " + scene.path);
                    warnings++;
                }
                if (string.IsNullOrEmpty(scene.path))
                {
                    Debug.LogError("[Jason Audit] Cena com caminho vazio.");
                    errors++;
                }
            }
        }

        var active = SceneManager.GetActiveScene();
        if (!active.IsValid())
        {
            Debug.LogError("[Jason Audit] Cena ativa inválida.");
            errors++;
        }

        Debug.Log($"[Jason Audit] Finalizado. Erros: {errors}; avisos: {warnings}. " +
                  "Verifique também manualmente todas as cenas, referências e builds.");
    }
}
#endif
