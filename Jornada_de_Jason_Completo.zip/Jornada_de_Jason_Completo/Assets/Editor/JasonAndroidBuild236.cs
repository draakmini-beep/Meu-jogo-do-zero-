#if UNITY_EDITOR
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

/// <summary>
/// Compila o APK Android. Configura IL2CPP, ARM64, orientação paisagem e identificador do pacote.
/// Menu: Tools > A Jornada de Jason > Build Android APK
/// </summary>
public static class JasonAndroidBuild236
{
    private const string OutputPath = "Builds/Android/JornadaDeJason.apk";

    [MenuItem("Tools/A Jornada de Jason/Build Android APK")]
    public static void BuildAndroidApk()
    {
        var scenes = EditorBuildSettings.scenes.Where(s => s.enabled && !string.IsNullOrEmpty(s.path)).Select(s => s.path).ToArray();
        if (scenes.Length == 0)
        {
            EditorUtility.DisplayDialog("Build interrompida", "Nenhuma cena válida está cadastrada em File > Build Profiles. Use Tools > A Jornada de Jason > Gerar Cena Jogável de Teste, ou adicione suas cenas.", "OK");
            return;
        }
        if (!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Android, BuildTarget.Android))
        {
            EditorUtility.DisplayDialog("Android Build Support ausente", "Instale Android Build Support, Android SDK & NDK Tools e OpenJDK pelo Unity Hub (Installs > engrenagem > Add modules).", "OK");
            return;
        }

        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);

        PlayerSettings.productName = "A Jornada de Jason - Ecos de Yarin";
        PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "com.ecosdeyarin.jornadajason");
        PlayerSettings.bundleVersion = "0.1.0";
        PlayerSettings.Android.bundleVersionCode = 1;
        PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
        PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
        PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
        PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
        EditorUserBuildSettings.buildAppBundle = false;

        Directory.CreateDirectory(Path.GetDirectoryName(OutputPath));

        var options = new BuildPlayerOptions
        {
            scenes = scenes,
            locationPathName = OutputPath,
            target = BuildTarget.Android,
            options = BuildOptions.None
        };

        BuildReport report = BuildPipeline.BuildPlayer(options);
        if (report.summary.result == BuildResult.Succeeded)
            EditorUtility.DisplayDialog("APK gerado", "APK salvo em " + OutputPath, "OK");
        else
            EditorUtility.DisplayDialog("Build falhou", "Resultado: " + report.summary.result + ". Consulte o Console do Unity para os erros.", "OK");
    }
}
#endif
