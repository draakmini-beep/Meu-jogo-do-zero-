using UnityEngine;
using UnityEngine.Events;

public class CraftingStation227 : MonoBehaviour
{
    [SerializeField] private string stationId;
    [SerializeField] private UnityEvent onCraftRequested;

    public bool Supports(CraftingRecipe227 recipe)
    {
        return recipe != null && recipe.IsValid() &&
            (string.IsNullOrEmpty(recipe.requiredStationId) ||
             recipe.requiredStationId == stationId);
    }

    // Apenas solicita a fabricação. O gerenciador central deve validar inventário,
    // nível, ingredientes e entregar o resultado numa única transação.
    public bool RequestCraft(CraftingRecipe227 recipe)
    {
        if (!Supports(recipe)) return false;
        onCraftRequested?.Invoke();
        return true;
    }
}
