using UnityEngine;

public class GatheringTool227 : MonoBehaviour
{
    [SerializeField, Min(0)] private int toolPower = 1;
    public int ToolPower => toolPower;

    public void SetToolPower(int value) =>
        toolPower = Mathf.Max(0, value);
}
