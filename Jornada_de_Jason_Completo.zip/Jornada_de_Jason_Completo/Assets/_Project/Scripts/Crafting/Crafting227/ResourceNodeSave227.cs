using System;
using System.Collections.Generic;

[Serializable]
public class ResourceNodeState227
{
    public string nodeId;
    public int remainingHarvests;
}

[Serializable]
public class CraftingSaveData227
{
    public List<ResourceNodeState227> resourceNodes =
        new List<ResourceNodeState227>();
    public List<string> unlockedRecipeIds = new List<string>();
}
