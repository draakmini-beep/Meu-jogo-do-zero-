using UnityEngine;

[CreateAssetMenu(fileName = "Gatherable", menuName = "Jason/Crafting/Gatherable")]
public class GatherableProfile227 : ScriptableObject
{
    public string resourceId;
    public string displayName;
    [Min(1)] public int amountPerGather = 1;
    [Min(0)] public int requiredToolPower;
    public Sprite icon;

    public bool IsValid() =>
        !string.IsNullOrWhiteSpace(resourceId) &&
        !string.IsNullOrWhiteSpace(displayName) &&
        amountPerGather > 0;
}
