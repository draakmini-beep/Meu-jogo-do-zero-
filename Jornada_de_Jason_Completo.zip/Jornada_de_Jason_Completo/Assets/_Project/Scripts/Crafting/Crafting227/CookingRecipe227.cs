using UnityEngine;

[CreateAssetMenu(fileName = "CookingRecipe", menuName = "Jason/Crafting/Cooking Recipe")]
public class CookingRecipe227 : ScriptableObject
{
    public string recipeId;
    public string outputFoodItemId;
    [Min(1)] public int outputQuantity = 1;
    public RecipeIngredient227[] ingredients;
    [Min(0f)] public float preparationSeconds = 3f;
    [Min(0f)] public float nutritionValue = 10f;

    public bool IsValid()
    {
        if (string.IsNullOrWhiteSpace(recipeId) ||
            string.IsNullOrWhiteSpace(outputFoodItemId) ||
            outputQuantity < 1 || ingredients == null ||
            ingredients.Length == 0) return false;

        foreach (var item in ingredients)
            if (item == null || string.IsNullOrWhiteSpace(item.itemId) ||
                item.quantity < 1) return false;

        return true;
    }
}
