using System;
using UnityEngine;

[Serializable]
public class RecipeIngredient227
{
    public string itemId;
    [Min(1)] public int quantity = 1;
}

[CreateAssetMenu(fileName = "CraftingRecipe", menuName = "Jason/Crafting/Recipe")]
public class CraftingRecipe227 : ScriptableObject
{
    public string recipeId;
    public string outputItemId;
    [Min(1)] public int outputQuantity = 1;
    public RecipeIngredient227[] ingredients;
    public string requiredStationId;
    [Min(0)] public int requiredLevel;

    public bool IsValid()
    {
        if (string.IsNullOrWhiteSpace(recipeId) ||
            string.IsNullOrWhiteSpace(outputItemId) ||
            outputQuantity < 1 || ingredients == null ||
            ingredients.Length == 0)
            return false;

        foreach (var ingredient in ingredients)
            if (ingredient == null ||
                string.IsNullOrWhiteSpace(ingredient.itemId) ||
                ingredient.quantity < 1)
                return false;

        return true;
    }
}
