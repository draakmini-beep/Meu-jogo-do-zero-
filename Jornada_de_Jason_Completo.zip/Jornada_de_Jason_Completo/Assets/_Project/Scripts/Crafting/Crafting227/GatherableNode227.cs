using UnityEngine;
using UnityEngine.Events;

public class GatherableNode227 : MonoBehaviour
{
    [SerializeField] private string nodeId;
    [SerializeField] private GatherableProfile227 profile;
    [SerializeField, Min(1)] private int remainingHarvests = 3;
    [SerializeField] private UnityEvent onDepleted;

    public bool TryGather(GatheringTool227 tool, out string resourceId, out int amount)
    {
        resourceId = null;
        amount = 0;

        if (string.IsNullOrWhiteSpace(nodeId) || profile == null ||
            !profile.IsValid() || remainingHarvests <= 0)
            return false;

        if (profile.requiredToolPower > 0 &&
            (tool == null || tool.ToolPower < profile.requiredToolPower))
            return false;

        remainingHarvests--;
        resourceId = profile.resourceId;
        amount = profile.amountPerGather;

        if (remainingHarvests == 0)
            onDepleted?.Invoke();

        return true;
    }

    public void RestoreHarvests(int value) =>
        remainingHarvests = Mathf.Max(0, value);
}
