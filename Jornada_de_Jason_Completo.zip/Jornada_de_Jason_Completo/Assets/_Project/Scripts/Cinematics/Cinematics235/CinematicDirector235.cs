using System.Collections;
using UnityEngine;
using UnityEngine.Events;

public class CinematicDirector235 : MonoBehaviour
{
    [SerializeField] private Camera cinematicCamera;
    [SerializeField] private CinematicShot235[] shots;
    [SerializeField] private bool useUnscaledTime = true;
    [SerializeField] private UnityEvent onCinematicStarted;
    [SerializeField] private UnityEvent onCinematicFinished;

    private Coroutine playback;
    public bool IsPlaying => playback != null;

    public void Play()
    {
        if (playback != null || cinematicCamera == null ||
            shots == null || shots.Length == 0) return;
        playback = StartCoroutine(PlayRoutine());
    }

    public void Stop()
    {
        if (playback == null) return;
        StopCoroutine(playback);
        playback = null;
        onCinematicFinished?.Invoke();
    }

    private IEnumerator PlayRoutine()
    {
        onCinematicStarted?.Invoke();

        foreach (var shot in shots)
        {
            if (shot == null || shot.cameraPosition == null) continue;

            Vector3 startPosition = cinematicCamera.transform.position;
            Quaternion startRotation = cinematicCamera.transform.rotation;
            Vector3 endPosition = shot.cameraPosition.position;
            Quaternion endRotation = shot.lookAtTarget != null
                ? Quaternion.LookRotation(
                    shot.lookAtTarget.position - endPosition,
                    Vector3.up)
                : shot.cameraPosition.rotation;

            float elapsed = 0f;
            float duration = Mathf.Max(0.1f, shot.duration);

            while (elapsed < duration)
            {
                elapsed += useUnscaledTime
                    ? Time.unscaledDeltaTime : Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / duration);
                t = t * t * (3f - 2f * t);
                cinematicCamera.transform.position =
                    Vector3.Lerp(startPosition, endPosition, t);
                cinematicCamera.transform.rotation =
                    Quaternion.Slerp(startRotation, endRotation, t);
                yield return null;
            }

            float hold = Mathf.Max(0f, shot.holdAfter);
            if (hold > 0f)
            {
                if (useUnscaledTime) yield return new WaitForSecondsRealtime(hold);
                else yield return new WaitForSeconds(hold);
            }
        }

        playback = null;
        onCinematicFinished?.Invoke();
    }
}
