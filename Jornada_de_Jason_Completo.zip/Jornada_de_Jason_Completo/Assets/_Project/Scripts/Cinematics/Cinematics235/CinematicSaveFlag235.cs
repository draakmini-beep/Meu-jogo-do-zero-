using UnityEngine;

public class CinematicSaveFlag235 : MonoBehaviour
{
    [SerializeField] private string cinematicId;
    [SerializeField] private bool completed;

    public string CinematicId => cinematicId;
    public bool Completed => completed;

    // O SaveCoordinator existente deve persistir este estado.
    public void MarkCompleted()
    {
        if (!string.IsNullOrWhiteSpace(cinematicId))
            completed = true;
    }

    public void RestoreCompleted(bool value) => completed = value;
}
