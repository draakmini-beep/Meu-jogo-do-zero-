using UnityEngine;

[System.Serializable]
public class CinematicShot235
{
    public string shotName;
    public Transform cameraPosition;
    public Transform lookAtTarget;
    [Min(0.1f)] public float duration = 3f;
    [Min(0f)] public float holdAfter = 0.25f;
}
