using UnityEngine;
using UnityEngine.Events;

public class CinematicControlBridge235 : MonoBehaviour
{
    [SerializeField] private UnityEvent onLockGameplay;
    [SerializeField] private UnityEvent onUnlockGameplay;
    [SerializeField] private UnityEvent onHideHUD;
    [SerializeField] private UnityEvent onShowHUD;

    public void BeginCinematic()
    {
        onLockGameplay?.Invoke();
        onHideHUD?.Invoke();
    }

    public void EndCinematic()
    {
        onUnlockGameplay?.Invoke();
        onShowHUD?.Invoke();
    }
}
