using UnityEngine;

public class CinematicTrigger235 : MonoBehaviour
{
    [SerializeField] private CinematicDirector235 director;
    [SerializeField] private string playerTag = "Player";
    [SerializeField] private bool playOnce = true;
    private bool hasPlayed;

    private void OnTriggerEnter(Collider other)
    {
        if (hasPlayed && playOnce) return;
        if (!other.CompareTag(playerTag) || director == null) return;
        hasPlayed = true;
        director.Play();
    }

    public void ResetTrigger() => hasPlayed = false;
}
