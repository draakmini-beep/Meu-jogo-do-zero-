using UnityEngine;
using UnityEngine.Events;

public class SkyDiscovery226 : MonoBehaviour
{
    [SerializeField] private string locationId;
    [SerializeField] private UnityEvent onFirstDiscovery;
    private bool discovered;

    public bool Discover()
    {
        if (discovered || string.IsNullOrWhiteSpace(locationId))
            return false;

        discovered = true;
        onFirstDiscovery?.Invoke();
        return true;
    }

    public void RestoreDiscovered(bool value) => discovered = value;
}
