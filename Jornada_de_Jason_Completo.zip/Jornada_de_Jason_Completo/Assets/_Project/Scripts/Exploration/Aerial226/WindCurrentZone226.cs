using UnityEngine;

[RequireComponent(typeof(Collider))]
public class WindCurrentZone226 : MonoBehaviour
{
    [SerializeField] private Vector3 localWindDirection = Vector3.forward;
    [SerializeField, Min(0f)] private float windStrength = 5f;

    private void Reset() => GetComponent<Collider>().isTrigger = true;

    private void OnTriggerStay(Collider other)
    {
        var body = other.attachedRigidbody;
        if (body == null) return;

        Vector3 direction = transform.TransformDirection(
            localWindDirection.normalized);
        body.AddForce(direction * windStrength, ForceMode.Acceleration);
    }
}
