using UnityEngine;
using UnityEngine.Events;

public class AerialLandingPoint226 : MonoBehaviour
{
    [SerializeField] private string landingId;
    [SerializeField] private Transform landingTransform;
    [SerializeField] private UnityEvent onLanded;

    public bool TryLand(Transform character)
    {
        if (character == null || landingTransform == null ||
            string.IsNullOrWhiteSpace(landingId))
            return false;

        character.SetPositionAndRotation(
            landingTransform.position, landingTransform.rotation);
        onLanded?.Invoke();
        return true;
    }
}
