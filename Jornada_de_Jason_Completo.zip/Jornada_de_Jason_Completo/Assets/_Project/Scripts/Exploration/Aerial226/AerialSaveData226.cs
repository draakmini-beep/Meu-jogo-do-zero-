using System;
using System.Collections.Generic;

[Serializable]
public class AerialSaveData226
{
    public float gliderStamina;
    public bool gliderUnlocked;
    public List<string> discoveredSkyLocations = new List<string>();
}
