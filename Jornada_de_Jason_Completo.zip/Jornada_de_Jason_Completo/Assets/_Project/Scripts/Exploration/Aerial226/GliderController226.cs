using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class GliderController226 : MonoBehaviour
{
    [SerializeField] private Rigidbody body;
    [SerializeField, Min(0f)] private float forwardSpeed = 12f;
    [SerializeField, Min(0f)] private float liftStrength = 4f;
    [SerializeField, Min(0f)] private float gravityScale = 0.65f;
    [SerializeField, Min(0f)] private float steeringDegreesPerSecond = 65f;
    [SerializeField, Min(0f)] private float stamina = 100f;
    [SerializeField, Min(0f)] private float staminaDrain = 4f;
    private Vector2 input;
    private bool deployed;

    public float Stamina => stamina;
    public bool IsDeployed => deployed;

    private void Reset() => body = GetComponent<Rigidbody>();

    public void SetInput(Vector2 value) => input = Vector2.ClampMagnitude(value, 1f);

    public bool Deploy()
    {
        if (body == null || stamina <= 0f) return false;
        deployed = true;
        body.useGravity = false;
        return true;
    }

    public void Fold()
    {
        deployed = false;
        if (body != null) body.useGravity = true;
    }

    private void FixedUpdate()
    {
        if (!deployed || body == null) return;

        stamina = Mathf.Max(0f, stamina - staminaDrain * Time.fixedDeltaTime);
        if (stamina <= 0f) { Fold(); return; }

        body.AddForce(transform.forward * forwardSpeed, ForceMode.Acceleration);
        body.AddForce(Vector3.down * (Physics.gravity.magnitude * gravityScale),
            ForceMode.Acceleration);
        body.AddForce(transform.up * (input.y * liftStrength),
            ForceMode.Acceleration);

        float turn = input.x * steeringDegreesPerSecond * Time.fixedDeltaTime;
        body.MoveRotation(body.rotation * Quaternion.Euler(0f, turn, 0f));
    }

    public void RestoreStamina(float amount) =>
        stamina = Mathf.Clamp(stamina + Mathf.Max(0f, amount), 0f, 100f);

    public void LoadStamina(float value) =>
        stamina = Mathf.Clamp(value, 0f, 100f);
}
