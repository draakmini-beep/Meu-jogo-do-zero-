using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class OceanDiscoveryRecord225
{
    public string discoveryId;
    public bool discovered;
}

public class OceanDiscoveryRegistry225 : MonoBehaviour
{
    [SerializeField] private List<OceanDiscoveryRecord225> records =
        new List<OceanDiscoveryRecord225>();

    public bool Discover(string id)
    {
        if (string.IsNullOrWhiteSpace(id)) return false;

        var record = records.Find(x => x.discoveryId == id);
        if (record == null)
        {
            record = new OceanDiscoveryRecord225 { discoveryId = id };
            records.Add(record);
        }

        if (record.discovered) return false;
        record.discovered = true;
        return true;
    }

    public List<OceanDiscoveryRecord225> CreateSnapshot()
    {
        var copy = new List<OceanDiscoveryRecord225>();
        foreach (var item in records)
            copy.Add(new OceanDiscoveryRecord225 {
                discoveryId = item.discoveryId, discovered = item.discovered
            });
        return copy;
    }

    public void Restore(List<OceanDiscoveryRecord225> snapshot)
    {
        records.Clear();
        if (snapshot == null) return;
        foreach (var item in snapshot)
            if (item != null)
                records.Add(new OceanDiscoveryRecord225 {
                    discoveryId = item.discoveryId, discovered = item.discovered
                });
    }
}
