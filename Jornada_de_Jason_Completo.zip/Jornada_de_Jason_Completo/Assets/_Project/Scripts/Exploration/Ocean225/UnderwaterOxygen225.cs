using UnityEngine;
using UnityEngine.Events;

public class UnderwaterOxygen225 : MonoBehaviour
{
    [SerializeField, Min(1f)] private float maximumOxygen = 60f;
    [SerializeField, Min(0f)] private float drainPerSecond = 1f;
    [SerializeField, Min(0f)] private float recoveryPerSecond = 3f;
    [SerializeField] private UnityEvent onOxygenDepleted;

    public float CurrentOxygen { get; private set; }
    public float NormalizedOxygen =>
        maximumOxygen <= 0f ? 0f : CurrentOxygen / maximumOxygen;
    public bool IsUnderwater { get; private set; }

    private bool depletionEventSent;

    private void Awake() => CurrentOxygen = maximumOxygen;

    public void SetUnderwater(bool value)
    {
        IsUnderwater = value;
        if (!value) depletionEventSent = false;
    }

    private void Update()
    {
        if (IsUnderwater)
        {
            CurrentOxygen = Mathf.Max(0f,
                CurrentOxygen - drainPerSecond * Time.deltaTime);

            if (CurrentOxygen <= 0f && !depletionEventSent)
            {
                depletionEventSent = true;
                onOxygenDepleted?.Invoke();
            }
        }
        else
        {
            CurrentOxygen = Mathf.Min(maximumOxygen,
                CurrentOxygen + recoveryPerSecond * Time.deltaTime);
        }
    }

    public void Restore(float amount)
    {
        CurrentOxygen = Mathf.Clamp(CurrentOxygen + Mathf.Max(0f, amount),
            0f, maximumOxygen);
        if (CurrentOxygen > 0f) depletionEventSent = false;
    }

    public void LoadValue(float value)
    {
        CurrentOxygen = Mathf.Clamp(value, 0f, maximumOxygen);
        depletionEventSent = CurrentOxygen <= 0f;
    }
}
