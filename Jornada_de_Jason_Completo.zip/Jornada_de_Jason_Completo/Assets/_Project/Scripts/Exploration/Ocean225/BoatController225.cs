using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class BoatController225 : MonoBehaviour
{
    [SerializeField] private Rigidbody body;
    [SerializeField, Min(0f)] private float forwardAcceleration = 8f;
    [SerializeField, Min(0f)] private float reverseAcceleration = 3f;
    [SerializeField, Min(0f)] private float maxSpeed = 12f;
    [SerializeField, Min(0f)] private float turnSpeed = 55f;
    [SerializeField, Range(0f, 1f)] private float waterDrag = 0.15f;
    [SerializeField] private Transform waterLevel;

    private Vector2 input;
    public float Speed => body != null ? body.velocity.magnitude : 0f;

    private void Reset() => body = GetComponent<Rigidbody>();

    public void SetInput(Vector2 value) => input = Vector2.ClampMagnitude(value, 1f);

    private void FixedUpdate()
    {
        if (body == null) return;

        float acceleration = input.y >= 0f ? forwardAcceleration : reverseAcceleration;
        Vector3 forwardForce = transform.forward * (input.y * acceleration);
        body.AddForce(forwardForce, ForceMode.Acceleration);

        float speedFactor = Mathf.Clamp01(body.velocity.magnitude / 2f);
        float turn = input.x * turnSpeed * speedFactor * Time.fixedDeltaTime;
        body.MoveRotation(body.rotation * Quaternion.Euler(0f, turn, 0f));

        Vector3 horizontal = new Vector3(body.velocity.x, 0f, body.velocity.z);
        if (horizontal.magnitude > maxSpeed)
        {
            horizontal = horizontal.normalized * maxSpeed;
            body.velocity = new Vector3(horizontal.x, body.velocity.y, horizontal.z);
        }

        body.velocity = new Vector3(
            body.velocity.x * (1f - waterDrag * Time.fixedDeltaTime),
            body.velocity.y,
            body.velocity.z * (1f - waterDrag * Time.fixedDeltaTime));

        if (waterLevel != null)
        {
            Vector3 p = body.position;
            p.y = Mathf.Lerp(p.y, waterLevel.position.y, 0.08f);
            body.MovePosition(p);
        }
    }
}
