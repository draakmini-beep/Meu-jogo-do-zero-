using UnityEngine;

[RequireComponent(typeof(Collider))]
public class UnderwaterZone225 : MonoBehaviour
{
    private void Reset() => GetComponent<Collider>().isTrigger = true;

    private void OnTriggerEnter(Collider other)
    {
        var oxygen = other.GetComponentInParent<UnderwaterOxygen225>();
        if (oxygen != null) oxygen.SetUnderwater(true);
    }

    private void OnTriggerExit(Collider other)
    {
        var oxygen = other.GetComponentInParent<UnderwaterOxygen225>();
        if (oxygen != null) oxygen.SetUnderwater(false);
    }
}
