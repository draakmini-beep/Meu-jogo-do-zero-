using UnityEngine;
using UnityEngine.Events;

public class IslandLandingPoint225 : MonoBehaviour
{
    [SerializeField] private string landingPointId;
    [SerializeField] private Transform playerSpawn;
    [SerializeField] private UnityEvent onPlayerLanded;

    public string LandingPointId => landingPointId;

    public bool TryLand(GameObject player)
    {
        if (player == null || playerSpawn == null ||
            string.IsNullOrWhiteSpace(landingPointId))
            return false;

        CharacterController controller = player.GetComponent<CharacterController>();
        if (controller != null) controller.enabled = false;

        player.transform.SetPositionAndRotation(
            playerSpawn.position, playerSpawn.rotation);

        if (controller != null) controller.enabled = true;

        onPlayerLanded?.Invoke();
        return true;
    }
}
