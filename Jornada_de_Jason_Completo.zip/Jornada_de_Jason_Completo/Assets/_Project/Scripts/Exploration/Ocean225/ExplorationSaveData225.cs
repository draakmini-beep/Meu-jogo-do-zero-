using System;
using System.Collections.Generic;

[Serializable]
public class ExplorationSaveData225
{
    public string activeBoatId;
    public float boatHealth;
    public float boatFuelOrEnergy;
    public float oxygenRemaining;
    public List<string> discoveredIds = new List<string>();
    public List<string> visitedIslandIds = new List<string>();
}
