using UnityEngine;
using UnityEngine.Events;

public class ExplorationInteractable225 : MonoBehaviour
{
    [SerializeField] private string stableId;
    [SerializeField] private bool oneTime = true;
    [SerializeField] private UnityEvent onInteract;
    private bool consumed;

    public bool Interact()
    {
        if (string.IsNullOrWhiteSpace(stableId) || (oneTime && consumed))
            return false;

        consumed = true;
        onInteract?.Invoke();
        return true;
    }

    public void RestoreConsumed(bool value) => consumed = value;
}
