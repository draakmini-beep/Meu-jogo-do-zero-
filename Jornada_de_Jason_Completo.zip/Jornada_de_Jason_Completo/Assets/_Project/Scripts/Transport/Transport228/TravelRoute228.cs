using UnityEngine;

[CreateAssetMenu(fileName = "TravelRoute", menuName = "Jason/Transport/Travel Route")]
public class TravelRoute228 : ScriptableObject
{
    public string routeId;
    public string originRegionId;
    public string destinationRegionId;
    public string requiredVehicleId;
    [Min(0)] public int requiredLevel;
    [Min(0f)] public float estimatedTravelSeconds = 60f;

    public bool IsValid() =>
        !string.IsNullOrWhiteSpace(routeId) &&
        !string.IsNullOrWhiteSpace(originRegionId) &&
        !string.IsNullOrWhiteSpace(destinationRegionId);
}
