using System;
using System.Collections.Generic;

[Serializable]
public class TransportSaveData228
{
    public string selectedVehicleId;
    public string currentVehicleInstanceId;
    public float currentVehicleDurability;
    public List<string> unlockedRouteIds = new List<string>();
    public string currentRegionId;
}
