using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class VehicleController228 : MonoBehaviour
{
    [SerializeField] private VehicleProfile228 profile;
    [SerializeField] private Rigidbody body;
    [SerializeField, Range(0f, 1f)] private float steeringAtLowSpeed = 0.25f;
    private Vector2 input;
    private bool controlled;

    private void Reset() => body = GetComponent<Rigidbody>();

    public void SetControlled(bool value) => controlled = value;
    public void SetInput(Vector2 value) => input = Vector2.ClampMagnitude(value, 1f);

    private void FixedUpdate()
    {
        if (!controlled || body == null || profile == null) return;

        body.AddForce(transform.forward * input.y * profile.acceleration,
            ForceMode.Acceleration);

        Vector3 horizontal = new Vector3(body.velocity.x, 0f, body.velocity.z);
        float speedFactor = Mathf.Lerp(steeringAtLowSpeed, 1f,
            Mathf.Clamp01(horizontal.magnitude / 3f));

        float yaw = input.x * profile.turnSpeed * speedFactor * Time.fixedDeltaTime;
        body.MoveRotation(body.rotation * Quaternion.Euler(0f, yaw, 0f));

        if (horizontal.magnitude > profile.maximumSpeed)
        {
            horizontal = horizontal.normalized * profile.maximumSpeed;
            body.velocity = new Vector3(horizontal.x, body.velocity.y, horizontal.z);
        }
    }
}
