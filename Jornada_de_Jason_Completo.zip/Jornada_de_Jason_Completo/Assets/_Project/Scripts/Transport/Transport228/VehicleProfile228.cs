using UnityEngine;

[CreateAssetMenu(fileName = "VehicleProfile", menuName = "Jason/Transport/Vehicle")]
public class VehicleProfile228 : ScriptableObject
{
    public string vehicleId;
    public string displayName;
    [Min(1f)] public float maximumSpeed = 15f;
    [Min(0f)] public float acceleration = 8f;
    [Min(0f)] public float turnSpeed = 60f;
    [Min(0f)] public float durability = 100f;

    public bool IsValid() =>
        !string.IsNullOrWhiteSpace(vehicleId) &&
        !string.IsNullOrWhiteSpace(displayName) &&
        maximumSpeed > 0f;
}
