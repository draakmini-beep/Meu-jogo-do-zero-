using System;
using UnityEngine;

public class WorldTravelCoordinator228 : MonoBehaviour
{
    public event Action<TravelRoute228> TravelRequested;

    public bool RequestTravel(TravelRoute228 route,
        string currentRegionId, string ownedVehicleId, int playerLevel)
    {
        if (route == null || !route.IsValid() ||
            route.originRegionId != currentRegionId ||
            playerLevel < route.requiredLevel)
            return false;

        if (!string.IsNullOrEmpty(route.requiredVehicleId) &&
            route.requiredVehicleId != ownedVehicleId)
            return false;

        TravelRequested?.Invoke(route);
        return true;
    }
}
