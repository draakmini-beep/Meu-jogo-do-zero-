using UnityEngine;

public class VehicleSeat228 : MonoBehaviour
{
    [SerializeField] private VehicleController228 vehicle;
    [SerializeField] private Transform seatPoint;
    [SerializeField] private Transform exitPoint;
    private GameObject occupant;
    private CharacterController occupantController;

    public bool Enter(GameObject character)
    {
        if (character == null || vehicle == null || seatPoint == null ||
            occupant != null) return false;

        occupant = character;
        occupantController = character.GetComponent<CharacterController>();
        if (occupantController != null) occupantController.enabled = false;

        character.transform.SetPositionAndRotation(
            seatPoint.position, seatPoint.rotation);
        character.transform.SetParent(seatPoint, true);
        vehicle.SetControlled(true);
        return true;
    }

    public bool Exit()
    {
        if (occupant == null || exitPoint == null || vehicle == null)
            return false;

        occupant.transform.SetParent(null, true);
        occupant.transform.SetPositionAndRotation(
            exitPoint.position, exitPoint.rotation);

        if (occupantController != null) occupantController.enabled = true;
        occupant = null;
        occupantController = null;
        vehicle.SetControlled(false);
        return true;
    }
}
