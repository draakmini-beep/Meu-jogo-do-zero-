using System;
using System.Collections.Generic;

[Serializable]
public class SettlementUpgradeRecord232
{
    public string settlementId;
    public List<string> completedUpgradeIds = new List<string>();
    public int visualStage;
}

[Serializable]
public class CitySaveData232
{
    public List<SettlementUpgradeRecord232> settlements =
        new List<SettlementUpgradeRecord232>();
}
