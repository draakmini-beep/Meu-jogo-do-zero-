using UnityEngine;

[CreateAssetMenu(fileName = "SettlementUpgrade", menuName = "Jason/City/Settlement Upgrade")]
public class SettlementUpgradeProfile232 : ScriptableObject
{
    public string upgradeId;
    public string displayName;
    public string requiredUpgradeId;
    [Min(0)] public int requiredDevelopment;
    [Min(1)] public int woodCost = 10;
    [Min(0)] public int stoneCost = 5;
    [Min(0)] public int goldCost = 0;
    public GameObject visualPrefab;

    public bool IsValid() =>
        !string.IsNullOrWhiteSpace(upgradeId) &&
        !string.IsNullOrWhiteSpace(displayName) &&
        woodCost >= 0 && stoneCost >= 0 && goldCost >= 0;
}
