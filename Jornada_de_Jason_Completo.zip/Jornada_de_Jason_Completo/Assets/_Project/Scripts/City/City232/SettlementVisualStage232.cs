using UnityEngine;

public class SettlementVisualStage232 : MonoBehaviour
{
    [SerializeField] private GameObject[] visualStages;
    [SerializeField, Min(0)] private int currentStage;

    public int CurrentStage => currentStage;

    public void SetStage(int stage)
    {
        if (visualStages == null || visualStages.Length == 0) return;
        currentStage = Mathf.Clamp(stage, 0, visualStages.Length - 1);

        for (int i = 0; i < visualStages.Length; i++)
            if (visualStages[i] != null)
                visualStages[i].SetActive(i == currentStage);
    }

    private void Start() => SetStage(currentStage);
}
