using UnityEngine;

public static class SettlementUpgradeValidator232
{
    public static bool CanUpgrade(
        SettlementUpgradeProfile232 profile,
        int development,
        string completedUpgradeId)
    {
        if (profile == null || !profile.IsValid() ||
            development < profile.requiredDevelopment)
            return false;

        if (!string.IsNullOrEmpty(profile.requiredUpgradeId) &&
            profile.requiredUpgradeId != completedUpgradeId)
            return false;

        return true;
    }
}
