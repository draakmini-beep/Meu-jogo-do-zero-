using UnityEngine;

public class CombatTargetMarker234 : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private Vector3 worldOffset = new Vector3(0f, 2.2f, 0f);
    [SerializeField] private Camera targetCamera;

    private void LateUpdate()
    {
        if (target == null || targetCamera == null) return;
        transform.position = target.position + worldOffset;
        transform.forward = targetCamera.transform.forward;
    }

    public void SetTarget(Transform newTarget) => target = newTarget;
}
