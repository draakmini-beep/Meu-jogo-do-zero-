using UnityEngine;
using UnityEngine.Events;

[System.Serializable]
public class ComboStep234
{
    public string stepName = "Attack";
    [Min(0.05f)] public float inputWindow = 0.8f;
    public UnityEvent onComboHit;
}

public class CombatComboController234 : MonoBehaviour
{
    [SerializeField] private ComboStep234[] comboSteps;
    [SerializeField] private float resetDelay = 1.1f;
    [SerializeField] private UnityEvent onComboFinished;
    [SerializeField] private UnityEvent onComboReset;

    private int currentStep;
    private float lastInputTime = -999f;

    public int CurrentStep => currentStep;

    public void SubmitAttackInput()
    {
        if (comboSteps == null || comboSteps.Length == 0) return;

        if (Time.time - lastInputTime > resetDelay)
            ResetCombo(false);

        if (currentStep >= comboSteps.Length)
            currentStep = 0;

        ComboStep234 step = comboSteps[currentStep];
        if (step == null) { ResetCombo(true); return; }

        lastInputTime = Time.time;
        step.onComboHit?.Invoke();
        currentStep++;

        if (currentStep >= comboSteps.Length)
        {
            onComboFinished?.Invoke();
            currentStep = 0;
            lastInputTime = Time.time;
        }
    }

    public void CancelCombo() => ResetCombo(true);

    private void Update()
    {
        if (currentStep > 0 && Time.time - lastInputTime > resetDelay)
            ResetCombo(true);
    }

    private void ResetCombo(bool notify)
    {
        currentStep = 0;
        lastInputTime = -999f;
        if (notify) onComboReset?.Invoke();
    }
}
