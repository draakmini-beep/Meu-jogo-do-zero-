using UnityEngine;
using UnityEngine.Events;

public class DodgeCounterWindow234 : MonoBehaviour
{
    [SerializeField, Min(0.05f)] private float counterWindow = 0.65f;
    [SerializeField] private UnityEvent onWindowOpened;
    [SerializeField] private UnityEvent onSuccessfulDodge;
    [SerializeField] private UnityEvent onWindowExpired;

    private float windowEndsAt;
    private bool isOpen;

    public bool IsOpen => isOpen && Time.time <= windowEndsAt;

    public void OpenCounterWindow()
    {
        isOpen = true;
        windowEndsAt = Time.time + counterWindow;
        onWindowOpened?.Invoke();
    }

    // Chamar pelo sistema de esquiva somente após confirmar a esquiva válida.
    public void RegisterSuccessfulDodge()
    {
        if (!IsOpen) return;
        isOpen = false;
        onSuccessfulDodge?.Invoke();
    }

    private void Update()
    {
        if (isOpen && Time.time > windowEndsAt)
        {
            isOpen = false;
            onWindowExpired?.Invoke();
        }
    }
}
