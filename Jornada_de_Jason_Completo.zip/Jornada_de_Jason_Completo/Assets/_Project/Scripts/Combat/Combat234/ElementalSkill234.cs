using UnityEngine;
using UnityEngine.Events;

public enum ElementType234 { Fire, Ice, Lightning, Nature, Shadow, Light }

[System.Serializable]
public class ElementalSkillEvent234 : UnityEvent<ElementType234> { }

public class ElementalSkill234 : MonoBehaviour
{
    [SerializeField] private ElementType234 element;
    [SerializeField, Min(0f)] private float cooldown = 4f;
    [SerializeField, Min(0f)] private float localEnergyCost;
    [SerializeField] private bool useLocalEnergy;
    [SerializeField, Min(0f)] private float localEnergy = 100f;
    [SerializeField] private ElementalSkillEvent234 onSkillActivated;
    [SerializeField] private UnityEvent onNotEnoughEnergy;
    [SerializeField] private UnityEvent onCooldown;

    private float nextReadyTime;

    public bool CanActivate =>
        Time.time >= nextReadyTime &&
        (!useLocalEnergy || localEnergy >= localEnergyCost);

    public void TryActivate()
    {
        if (Time.time < nextReadyTime)
        {
            onCooldown?.Invoke();
            return;
        }

        if (useLocalEnergy)
        {
            if (localEnergy < localEnergyCost)
            {
                onNotEnoughEnergy?.Invoke();
                return;
            }
            localEnergy -= localEnergyCost;
            ActivateAfterCostCommitted();
            return;
        }

        // Sem custo local: o evento deve iniciar a validação/cobrança no manager.
        onSkillActivated?.Invoke(element);
    }

    // Chamar somente depois que o manager central confirmar o custo.
    public void ActivateAfterCostCommitted()
    {
        if (Time.time < nextReadyTime) return;
        nextReadyTime = Time.time + cooldown;
        onSkillActivated?.Invoke(element);
    }

    public void RestoreLocalEnergy(float amount)
    {
        if (amount > 0f) localEnergy += amount;
    }
}
