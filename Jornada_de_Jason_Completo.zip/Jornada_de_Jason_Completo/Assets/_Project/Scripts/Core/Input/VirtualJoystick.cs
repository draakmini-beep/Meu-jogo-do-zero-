using UnityEngine;
using UnityEngine.EventSystems;

namespace JornadaDeJason
{
    /// <summary>
    /// Joystick virtual de UI. Coloque na área esquerda da tela (Image transparente) e
    /// ligue "handle" a uma Image filha. Funciona com toque e com mouse (EventSystem).
    /// </summary>
    public class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        [SerializeField] private RectTransform background;
        [SerializeField] private RectTransform handle;
        [SerializeField, Min(1f)] private float radius = 90f;

        /// <summary>Direção atual (magnitude de 0 a 1).</summary>
        public Vector2 Value { get; private set; }

        private void Reset()
        {
            background = transform as RectTransform;
        }

        public void OnPointerDown(PointerEventData eventData) => OnDrag(eventData);

        public void OnDrag(PointerEventData eventData)
        {
            if (background == null) return;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                    background, eventData.position, eventData.pressEventCamera, out Vector2 local))
                return;

            // Independe do pivot do RectTransform: mede a partir do centro do retângulo.
            Vector2 centered = local - background.rect.center;
            Vector2 v = Vector2.ClampMagnitude(centered / radius, 1f);
            Value = v;
            if (handle != null) handle.anchoredPosition = v * radius;
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            Value = Vector2.zero;
            if (handle != null) handle.anchoredPosition = Vector2.zero;
        }

        private void OnDisable()
        {
            Value = Vector2.zero;
            if (handle != null) handle.anchoredPosition = Vector2.zero;
        }
    }
}
