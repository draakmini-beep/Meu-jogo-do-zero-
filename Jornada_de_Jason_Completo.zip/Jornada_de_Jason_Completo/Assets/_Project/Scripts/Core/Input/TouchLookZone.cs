using UnityEngine;
using UnityEngine.EventSystems;

namespace JornadaDeJason
{
    /// <summary>
    /// Área da tela (lado direito) que captura o arrasto do dedo para girar a câmera.
    /// Use uma Image transparente com "Raycast Target" ligado. A TouchOrbitCamera consome o delta.
    /// </summary>
    public class TouchLookZone : MonoBehaviour, IDragHandler, IBeginDragHandler
    {
        private Vector2 accumulated;

        public void OnBeginDrag(PointerEventData eventData) { }

        public void OnDrag(PointerEventData eventData)
        {
            accumulated += eventData.delta;
        }

        /// <summary>Retorna o deslocamento acumulado (em pixels) desde a última chamada e zera.</summary>
        public Vector2 ConsumeDelta()
        {
            Vector2 d = accumulated;
            accumulated = Vector2.zero;
            return d;
        }
    }
}
