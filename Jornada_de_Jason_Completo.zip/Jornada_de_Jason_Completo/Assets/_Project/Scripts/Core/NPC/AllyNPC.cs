using TMPro;
using UnityEngine;
using UnityEngine.Events;

namespace JornadaDeJason
{
    /// <summary>
    /// NPC aliado (Eldrin, Lyra, aldeões). Ao o jogador se aproximar (trigger), abre um painel
    /// de UI com dicas e história. Botões do painel chamam NextLine() e CloseDialogue().
    /// Também suporta aldeões que precisam ser resgatados (Rescue()).
    /// O objeto precisa de um Collider "Is Trigger" maior que o NPC; o jogador usa a tag "Player".
    /// </summary>
    [RequireComponent(typeof(Collider))]
    public class AllyNPC : MonoBehaviour
    {
        [Header("Identidade")]
        [SerializeField] private string npcName = "Eldrin";
        [TextArea(2, 5)]
        [SerializeField] private string[] lines =
        {
            "Jovem Jason... as correntezas escondem mais do que água.",
            "Pesos exatos abrem portões. Use blocos de pedra nas placas de pressão."
        };

        [Header("Painel de diálogo")]
        [SerializeField] private GameObject dialoguePanel;
        [SerializeField] private TMP_Text nameText;
        [SerializeField] private TMP_Text bodyText;
        [Tooltip("Abre sozinho ao se aproximar. Se desligado, chame OpenDialogue() por um botão.")]
        [SerializeField] private bool openOnApproach = true;
        [SerializeField] private bool lookAtPlayer = true;

        [Header("Resgate (aldeões)")]
        [SerializeField] private bool needsRescue;
        [SerializeField] private string rescuedLine = "Obrigado por me salvar!";

        [Header("Eventos")]
        public UnityEvent onDialogueStarted;
        public UnityEvent onDialogueFinished;
        public UnityEvent onRescued;

        public bool IsRescued { get; private set; }

        private static AllyNPC activeNpc;
        private int lineIndex;
        private bool playerInside;
        private Transform playerTransform;

        private void Reset()
        {
            GetComponent<Collider>().isTrigger = true;
        }

        private void Awake()
        {
            GetComponent<Collider>().isTrigger = true;
            if (dialoguePanel != null) dialoguePanel.SetActive(false);
            IsRescued = !needsRescue;
        }

        private void Update()
        {
            if (lookAtPlayer && playerInside && playerTransform != null)
            {
                Vector3 dir = playerTransform.position - transform.position;
                dir.y = 0f;
                if (dir.sqrMagnitude > 0.01f)
                    transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(dir), 5f * Time.deltaTime);
            }
        }

        private void OnTriggerEnter(Collider other)
        {
            if (!other.CompareTag("Player")) return;
            playerInside = true;
            playerTransform = other.transform;
            if (openOnApproach) OpenDialogue();
        }

        private void OnTriggerExit(Collider other)
        {
            if (!other.CompareTag("Player")) return;
            playerInside = false;
            CloseDialogue();
        }

        public void OpenDialogue()
        {
            if (dialoguePanel == null || lines == null || lines.Length == 0) return;

            // Só um diálogo aberto por vez.
            if (activeNpc != null && activeNpc != this) activeNpc.CloseDialogue();
            activeNpc = this;

            lineIndex = 0;
            dialoguePanel.SetActive(true);
            if (nameText != null) nameText.text = npcName;
            ShowCurrentLine();
            onDialogueStarted?.Invoke();
        }

        public void NextLine()
        {
            if (dialoguePanel == null || !dialoguePanel.activeSelf) return;
            lineIndex++;
            if (lineIndex >= lines.Length)
            {
                CloseDialogue();
                return;
            }
            ShowCurrentLine();
        }

        public void CloseDialogue()
        {
            if (dialoguePanel == null || !dialoguePanel.activeSelf) return;
            dialoguePanel.SetActive(false);
            if (activeNpc == this) activeNpc = null;
            onDialogueFinished?.Invoke();
        }

        /// <summary>Chame quando o puzzle/inimigo que prendia o aldeão for resolvido.</summary>
        public void Rescue()
        {
            if (IsRescued) return;
            IsRescued = true;
            if (lines != null && lines.Length > 0 && !string.IsNullOrEmpty(rescuedLine))
                lines = new[] { rescuedLine };
            onRescued?.Invoke();
        }

        private void ShowCurrentLine()
        {
            if (bodyText != null) bodyText.text = lines[Mathf.Clamp(lineIndex, 0, lines.Length - 1)];
        }

        private void OnDisable()
        {
            if (activeNpc == this) activeNpc = null;
        }
    }
}
