using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace JornadaDeJason
{
    [Serializable]
    public class CoreSaveData
    {
        public int coins;
        public List<string> ownedSkins = new List<string>();
        public string equippedSkin = "";
    }

    /// <summary>
    /// Salvamento local em JSON (Application.persistentDataPath/jornada_core_save.json).
    /// Guarda moedas e skins. Independente dos saves das etapas 223-236.
    /// </summary>
    public static class JasonSave
    {
        private const string FileName = "jornada_core_save.json";

        private static CoreSaveData data;

        /// <summary>Disparado sempre que o total de moedas muda.</summary>
        public static event Action<int> CoinsChanged;

        private static string FilePath => Path.Combine(Application.persistentDataPath, FileName);

        public static CoreSaveData Data
        {
            get
            {
                if (data == null) Load();
                return data;
            }
        }

        public static int Coins => Data.coins;

        public static void Load()
        {
            try
            {
                if (File.Exists(FilePath))
                {
                    data = JsonUtility.FromJson<CoreSaveData>(File.ReadAllText(FilePath));
                }
            }
            catch (Exception e)
            {
                Debug.LogWarning("[JasonSave] Falha ao ler o save, criando um novo: " + e.Message);
            }

            if (data == null) data = new CoreSaveData();
            if (data.ownedSkins == null) data.ownedSkins = new List<string>();
        }

        public static void Save()
        {
            try
            {
                File.WriteAllText(FilePath, JsonUtility.ToJson(Data, true));
            }
            catch (Exception e)
            {
                Debug.LogError("[JasonSave] Falha ao salvar: " + e.Message);
            }
        }

        public static void AddCoins(int amount)
        {
            if (amount <= 0) return;
            Data.coins += amount;
            Save();
            CoinsChanged?.Invoke(Data.coins);
        }

        public static bool TrySpendCoins(int amount)
        {
            if (amount < 0 || Data.coins < amount) return false;
            Data.coins -= amount;
            Save();
            CoinsChanged?.Invoke(Data.coins);
            return true;
        }

        public static bool OwnsSkin(string id) => Data.ownedSkins.Contains(id);

        public static void UnlockSkin(string id)
        {
            if (string.IsNullOrEmpty(id) || Data.ownedSkins.Contains(id)) return;
            Data.ownedSkins.Add(id);
            Save();
        }

        public static void EquipSkin(string id)
        {
            Data.equippedSkin = id;
            Save();
        }

        public static void DeleteSave()
        {
            data = new CoreSaveData();
            try { if (File.Exists(FilePath)) File.Delete(FilePath); }
            catch (Exception e) { Debug.LogWarning("[JasonSave] " + e.Message); }
            CoinsChanged?.Invoke(0);
        }
    }
}
