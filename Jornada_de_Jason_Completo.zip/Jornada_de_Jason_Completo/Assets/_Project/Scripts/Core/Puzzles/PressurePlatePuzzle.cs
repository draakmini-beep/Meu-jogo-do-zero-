using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace JornadaDeJason
{
    /// <summary>
    /// Placa de pressão física. Soma a massa dos Rigidbodies sobre ela e dispara eventos
    /// quando o peso exigido é atingido. Dois modos: peso mínimo ou peso exato (com tolerância).
    /// Use um Collider "Is Trigger" um pouco acima da superfície da placa.
    /// </summary>
    [RequireComponent(typeof(Collider))]
    public class PressurePlatePuzzle : MonoBehaviour
    {
        public enum Mode { MinimumWeight, ExactWeight }

        [Header("Regra")]
        [SerializeField] private Mode mode = Mode.MinimumWeight;
        [SerializeField, Min(0f)] private float requiredWeight = 5f;
        [Tooltip("Tolerância usada no modo ExactWeight.")]
        [SerializeField, Min(0f)] private float exactTolerance = 0.25f;
        [Tooltip("Massa contada quando o jogador pisa na placa (0 = ignora o jogador).")]
        [SerializeField, Min(0f)] private float playerWeight = 1f;

        [Header("Visual (opcional)")]
        [SerializeField] private Transform plateVisual;
        [SerializeField, Min(0f)] private float pressDepth = 0.08f;
        [SerializeField, Min(0.1f)] private float pressSpeed = 8f;

        [Header("Eventos")]
        public UnityEvent onActivated;
        public UnityEvent onDeactivated;
        public UnityEvent<float> onWeightChanged;

        public float CurrentWeight { get; private set; }
        public bool IsActive { get; private set; }

        private readonly Dictionary<Rigidbody, int> bodies = new Dictionary<Rigidbody, int>();
        private int playerContacts;
        private readonly List<Rigidbody> toRemove = new List<Rigidbody>();
        private Vector3 visualRestPosition;

        private void Awake()
        {
            GetComponent<Collider>().isTrigger = true;
            if (plateVisual != null) visualRestPosition = plateVisual.localPosition;
        }

        private void OnTriggerEnter(Collider other)
        {
            if (other.TryGetComponent(out CharacterController _))
            {
                playerContacts++;
                return;
            }

            Rigidbody rb = other.attachedRigidbody;
            if (rb == null) return;
            bodies.TryGetValue(rb, out int count);
            bodies[rb] = count + 1;
        }

        private void OnTriggerExit(Collider other)
        {
            if (other.TryGetComponent(out CharacterController _))
            {
                playerContacts = Mathf.Max(0, playerContacts - 1);
                return;
            }

            Rigidbody rb = other.attachedRigidbody;
            if (rb == null || !bodies.TryGetValue(rb, out int count)) return;
            if (count <= 1) bodies.Remove(rb);
            else bodies[rb] = count - 1;
        }

        private void FixedUpdate()
        {
            // Remove corpos destruídos durante o contato.
            toRemove.Clear();
            foreach (var kv in bodies)
                if (kv.Key == null) toRemove.Add(kv.Key);
            foreach (var rb in toRemove) bodies.Remove(rb);

            float total = 0f;
            foreach (var kv in bodies) total += kv.Key.mass;
            if (playerContacts > 0) total += playerWeight;

            if (!Mathf.Approximately(total, CurrentWeight))
            {
                CurrentWeight = total;
                onWeightChanged?.Invoke(CurrentWeight);
            }

            bool shouldBeActive = mode == Mode.MinimumWeight
                ? CurrentWeight >= requiredWeight
                : Mathf.Abs(CurrentWeight - requiredWeight) <= exactTolerance && CurrentWeight > 0f;

            if (shouldBeActive != IsActive)
            {
                IsActive = shouldBeActive;
                if (IsActive) onActivated?.Invoke();
                else onDeactivated?.Invoke();
            }
        }

        private void Update()
        {
            if (plateVisual == null) return;
            Vector3 goal = visualRestPosition + Vector3.down * (IsActive ? pressDepth : 0f);
            plateVisual.localPosition = Vector3.Lerp(plateVisual.localPosition, goal, 1f - Mathf.Exp(-pressSpeed * Time.unscaledDeltaTime));
        }
    }
}
