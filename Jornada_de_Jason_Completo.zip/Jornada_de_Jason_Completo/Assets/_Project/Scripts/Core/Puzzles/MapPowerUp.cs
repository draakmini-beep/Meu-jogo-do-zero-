using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace JornadaDeJason
{
    /// <summary>
    /// Item coletável que altera temporariamente a física: Gravidade Zero, Câmera Lenta,
    /// Super Força e Congelamento de Área. Marque o objeto do Jason com a tag "Player".
    /// O objeto fica ativo (invisível) durante o efeito para a corrotina continuar rodando.
    /// </summary>
    [RequireComponent(typeof(Collider))]
    public class MapPowerUp : MonoBehaviour
    {
        public enum PowerType { ZeroGravity, SlowMotion, SuperStrength, AreaFreeze }

        /// <summary>Multiplicador lido pelo WeaponSystem (1 = normal).</summary>
        public static float StrengthMultiplier { get; private set; } = 1f;

        // Contadores estáticos permitem vários itens ativos sem corromper os valores originais.
        private static int zeroGravityActive;
        private static int slowActive;
        private static int strengthActive;
        private static Vector3 savedGravity;
        private static float savedFixedDelta;

        [Header("Efeito")]
        [SerializeField] private PowerType type = PowerType.ZeroGravity;
        [SerializeField, Min(0.5f)] private float duration = 8f;

        [Header("Parâmetros")]
        [Tooltip("Fração da gravidade original durante Gravidade Zero.")]
        [SerializeField, Range(0f, 1f)] private float gravityScale = 0.05f;
        [SerializeField, Range(0.05f, 1f)] private float timeScale = 0.4f;
        [SerializeField, Min(1f)] private float strengthMultiplier = 2f;
        [SerializeField, Min(0.5f)] private float freezeRadius = 8f;

        [Header("Visual")]
        [SerializeField] private AudioClip pickupSound;
        [SerializeField] private float spinSpeed = 90f;

        private bool collected;
        private bool effectRunning;
        private readonly List<FrozenBody> frozen = new List<FrozenBody>();

        private struct FrozenBody
        {
            public Rigidbody body;
            public bool wasKinematic;
        }

        private void Reset()
        {
            GetComponent<Collider>().isTrigger = true;
        }

        private void Update()
        {
            if (!collected) transform.Rotate(0f, spinSpeed * Time.unscaledDeltaTime, 0f, Space.World);
        }

        private void OnTriggerEnter(Collider other)
        {
            if (collected || !other.CompareTag("Player")) return;
            collected = true;
            if (pickupSound != null) AudioSource.PlayClipAtPoint(pickupSound, transform.position);
            HideVisuals();
            StartCoroutine(RunEffect());
        }

        private void HideVisuals()
        {
            foreach (var r in GetComponentsInChildren<Renderer>()) r.enabled = false;
            foreach (var c in GetComponentsInChildren<Collider>()) c.enabled = false;
        }

        private IEnumerator RunEffect()
        {
            effectRunning = true;
            Begin();
            // Tempo real: a câmera lenta não pode alongar a própria duração.
            yield return new WaitForSecondsRealtime(duration);
            End();
            effectRunning = false;
            Destroy(gameObject);
        }

        private void Begin()
        {
            switch (type)
            {
                case PowerType.ZeroGravity:
                    if (zeroGravityActive++ == 0) savedGravity = Physics.gravity;
                    Physics.gravity = savedGravity * gravityScale;
                    break;

                case PowerType.SlowMotion:
                    if (slowActive++ == 0) savedFixedDelta = Time.fixedDeltaTime / Mathf.Max(0.0001f, Time.timeScale);
                    Time.timeScale = timeScale;
                    Time.fixedDeltaTime = savedFixedDelta * timeScale;
                    break;

                case PowerType.SuperStrength:
                    strengthActive++;
                    StrengthMultiplier = strengthMultiplier;
                    break;

                case PowerType.AreaFreeze:
                    FreezeArea();
                    break;
            }
        }

        private void End()
        {
            switch (type)
            {
                case PowerType.ZeroGravity:
                    if (zeroGravityActive > 0 && --zeroGravityActive == 0) Physics.gravity = savedGravity;
                    break;

                case PowerType.SlowMotion:
                    if (slowActive > 0 && --slowActive == 0)
                    {
                        Time.timeScale = 1f;
                        Time.fixedDeltaTime = savedFixedDelta;
                    }
                    break;

                case PowerType.SuperStrength:
                    if (strengthActive > 0 && --strengthActive == 0) StrengthMultiplier = 1f;
                    break;

                case PowerType.AreaFreeze:
                    Unfreeze();
                    break;
            }
        }

        private void FreezeArea()
        {
            frozen.Clear();
            Collider[] hits = Physics.OverlapSphere(transform.position, freezeRadius, ~0, QueryTriggerInteraction.Ignore);
            var seen = new HashSet<Rigidbody>();
            foreach (var h in hits)
            {
                Rigidbody rb = h.attachedRigidbody;
                if (rb == null || rb.isKinematic || !seen.Add(rb)) continue;
                frozen.Add(new FrozenBody { body = rb, wasKinematic = rb.isKinematic });
                rb.linearVelocity = Vector3.zero;
                rb.angularVelocity = Vector3.zero;
                rb.isKinematic = true;
            }
        }

        private void Unfreeze()
        {
            foreach (var f in frozen)
                if (f.body != null) f.body.isKinematic = f.wasKinematic;
            frozen.Clear();
        }

        // Garante a restauração da física se a cena for descarregada com o efeito ativo.
        private void OnDestroy()
        {
            if (effectRunning)
            {
                End();
                effectRunning = false;
            }
        }
    }
}
