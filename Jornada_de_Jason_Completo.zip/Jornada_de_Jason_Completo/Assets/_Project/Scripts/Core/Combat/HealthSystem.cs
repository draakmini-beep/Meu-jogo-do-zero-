using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace JornadaDeJason
{
    /// <summary>
    /// Sistema universal de vida: jogador, inimigos e estruturas destrutíveis.
    /// É a autoridade de vida do jogo (os scripts das etapas 234-236 não aplicam dano direto).
    /// Opcionalmente recebe dano de impacto físico (blocos arremessados, destroços).
    /// </summary>
    public class HealthSystem : MonoBehaviour
    {
        [Header("Vida")]
        [SerializeField, Min(1f)] private float maxHealth = 100f;
        [SerializeField] private bool invulnerable;

        [Header("Interface (opcional)")]
        [SerializeField] private Slider healthBar;
        [Tooltip("Esconde a barra enquanto a vida estiver cheia (bom para inimigos).")]
        [SerializeField] private bool hideBarWhenFull;

        [Header("Dano por impacto físico")]
        [SerializeField] private bool takesImpactDamage;
        [Tooltip("Velocidade relativa mínima para causar dano.")]
        [SerializeField, Min(0f)] private float impactSpeedThreshold = 5f;
        [Tooltip("Dano = (velocidade - limiar) * massa do objeto * este fator.")]
        [SerializeField, Min(0f)] private float impactDamageFactor = 2f;

        [Header("Morte")]
        [SerializeField] private bool destroyOnDeath;
        [SerializeField, Min(0f)] private float destroyDelay = 0.1f;

        [Header("Eventos")]
        public UnityEvent<float> onDamaged;
        public UnityEvent<float> onHealed;
        public UnityEvent onDied;

        public float CurrentHealth { get; private set; }
        public float MaxHealth => maxHealth;
        public bool IsDead { get; private set; }
        public float Normalized => maxHealth <= 0f ? 0f : CurrentHealth / maxHealth;

        private void Awake()
        {
            CurrentHealth = maxHealth;
            RefreshBar();
        }

        public void TakeDamage(float amount)
        {
            if (IsDead || invulnerable || amount <= 0f) return;

            CurrentHealth = Mathf.Max(0f, CurrentHealth - amount);
            RefreshBar();
            onDamaged?.Invoke(amount);

            if (CurrentHealth <= 0f) Die();
        }

        public void Heal(float amount)
        {
            if (IsDead || amount <= 0f) return;
            CurrentHealth = Mathf.Min(maxHealth, CurrentHealth + amount);
            RefreshBar();
            onHealed?.Invoke(amount);
        }

        public void ResetHealth()
        {
            IsDead = false;
            CurrentHealth = maxHealth;
            RefreshBar();
        }

        public void SetInvulnerable(bool value) => invulnerable = value;

        private void Die()
        {
            if (IsDead) return;
            IsDead = true;
            onDied?.Invoke();
            if (destroyOnDeath) Destroy(gameObject, destroyDelay);
        }

        private void RefreshBar()
        {
            if (healthBar == null) return;
            healthBar.minValue = 0f;
            healthBar.maxValue = maxHealth;
            healthBar.value = CurrentHealth;
            if (hideBarWhenFull) healthBar.gameObject.SetActive(CurrentHealth < maxHealth && !IsDead);
        }

        private void OnCollisionEnter(Collision collision)
        {
            if (!takesImpactDamage || IsDead) return;

            float speed = collision.relativeVelocity.magnitude;
            if (speed < impactSpeedThreshold) return;

            // Só conta o dano se o outro objeto for um corpo dinâmico (bloco, destroço).
            Rigidbody other = collision.rigidbody;
            if (other == null || other.isKinematic) return;

            float damage = (speed - impactSpeedThreshold) * other.mass * impactDamageFactor;
            TakeDamage(damage);
        }
    }
}
