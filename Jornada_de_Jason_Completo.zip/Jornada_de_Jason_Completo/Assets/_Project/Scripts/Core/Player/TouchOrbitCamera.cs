using UnityEngine;

namespace JornadaDeJason
{
    /// <summary>
    /// Câmera orbital em terceira pessoa. Gira ao deslizar o dedo na TouchLookZone
    /// (ou com o botão direito do mouse no Editor) e evita atravessar paredes.
    /// A sensibilidade é uma variável estática, alterada pelo SettingsManager.
    /// </summary>
    public class TouchOrbitCamera : MonoBehaviour
    {
        /// <summary>Multiplicador global de sensibilidade (0.2 a 3).</summary>
        public static float Sensitivity = 1f;

        [Header("Alvo")]
        [SerializeField] private Transform target;
        [SerializeField] private Vector3 targetOffset = new Vector3(0f, 1.5f, 0f);

        [Header("Entrada")]
        [SerializeField] private TouchLookZone lookZone;
        [Tooltip("Graus por pixel arrastado, antes do multiplicador de sensibilidade.")]
        [SerializeField, Min(0.001f)] private float degreesPerPixel = 0.12f;
        [SerializeField] private bool invertY;

        [Header("Órbita")]
        [SerializeField, Min(0.5f)] private float distance = 6f;
        [SerializeField, Range(-80f, 80f)] private float minPitch = -20f;
        [SerializeField, Range(-80f, 80f)] private float maxPitch = 60f;
        [SerializeField, Min(0f)] private float followSmoothing = 14f;

        [Header("Colisão")]
        [SerializeField] private LayerMask obstructionMask = ~0;
        [SerializeField, Min(0.05f)] private float collisionRadius = 0.25f;

        private float yaw;
        private float pitch = 20f;
        private Vector3 smoothedFocus;

        private void Start()
        {
            if (target != null)
            {
                yaw = target.eulerAngles.y;
                smoothedFocus = target.position + targetOffset;
            }
        }

        public void SetTarget(Transform newTarget)
        {
            target = newTarget;
            if (target != null) smoothedFocus = target.position + targetOffset;
        }

        private void LateUpdate()
        {
            if (target == null) return;

            Vector2 delta = Vector2.zero;
            if (lookZone != null) delta = lookZone.ConsumeDelta();

#if UNITY_EDITOR
            delta += EditorMouseDelta();
#endif

            float scale = degreesPerPixel * Mathf.Max(0.05f, Sensitivity);
            yaw += delta.x * scale;
            pitch += (invertY ? delta.y : -delta.y) * scale;
            pitch = Mathf.Clamp(pitch, minPitch, maxPitch);

            Vector3 focusTarget = target.position + targetOffset;
            smoothedFocus = Vector3.Lerp(smoothedFocus, focusTarget, 1f - Mathf.Exp(-followSmoothing * Time.unscaledDeltaTime));

            Quaternion rotation = Quaternion.Euler(pitch, yaw, 0f);
            Vector3 direction = rotation * Vector3.back;

            float finalDistance = distance;
            if (Physics.SphereCast(smoothedFocus, collisionRadius, direction, out RaycastHit hit,
                    distance, obstructionMask, QueryTriggerInteraction.Ignore))
            {
                if (!hit.collider.transform.IsChildOf(target))
                    finalDistance = Mathf.Max(0.5f, hit.distance);
            }

            transform.SetPositionAndRotation(smoothedFocus + direction * finalDistance, rotation);
        }

#if UNITY_EDITOR
        // Teste no Editor: arraste com o botão direito do mouse.
        private Vector2 EditorMouseDelta()
        {
#if ENABLE_INPUT_SYSTEM
            var mouse = UnityEngine.InputSystem.Mouse.current;
            if (mouse != null && mouse.rightButton.isPressed) return mouse.delta.ReadValue();
#elif ENABLE_LEGACY_INPUT_MANAGER
            if (Input.GetMouseButton(1)) return new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y")) * 10f;
#endif
            return Vector2.zero;
        }
#endif
    }
}
