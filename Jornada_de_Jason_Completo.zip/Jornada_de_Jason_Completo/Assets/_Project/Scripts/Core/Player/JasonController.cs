using UnityEngine;

namespace JornadaDeJason
{
    /// <summary>
    /// Movimentação do Jason com CharacterController: joystick virtual (toque) ou teclado (testes),
    /// rotação suave alinhada à câmera, pulo, salto duplo opcional e Dash Aéreo com cooldown.
    /// Marque o objeto com a tag "Player".
    /// </summary>
    [RequireComponent(typeof(CharacterController))]
    public class JasonController : MonoBehaviour
    {
        [Header("Referências")]
        [SerializeField] private VirtualJoystick joystick;
        [Tooltip("Se vazio, usa Camera.main.")]
        [SerializeField] private Transform cameraTransform;

        [Header("Movimento")]
        [SerializeField, Min(0f)] private float moveSpeed = 6f;
        [SerializeField, Min(0f)] private float rotationSpeed = 12f;
        [SerializeField, Min(0f)] private float acceleration = 20f;

        [Header("Pulo")]
        [SerializeField, Min(0f)] private float jumpHeight = 1.6f;
        [SerializeField] private float gravity = -25f;
        [Tooltip("Pulos extras no ar (1 = Salto Duplo).")]
        [SerializeField, Min(0)] private int extraAirJumps = 1;
        [SerializeField, Min(0f)] private float coyoteTime = 0.1f;

        [Header("Dash Aéreo")]
        [SerializeField] private bool dashEnabled = true;
        [SerializeField, Min(0f)] private float dashSpeed = 18f;
        [SerializeField, Min(0.01f)] private float dashDuration = 0.2f;
        [SerializeField, Min(0f)] private float dashCooldown = 1.2f;

        [Header("Empurrar objetos")]
        [SerializeField, Min(0f)] private float pushPower = 3f;

        public bool IsGrounded => controller.isGrounded;
        public bool IsDashing => dashTimer > 0f;
        public float DashCooldownNormalized => dashCooldown <= 0f ? 1f : 1f - Mathf.Clamp01(dashCooldownTimer / dashCooldown);

        private CharacterController controller;
        private Vector3 horizontalVelocity;
        private float verticalVelocity;
        private int airJumpsUsed;
        private float lastGroundedTime = -10f;
        private bool jumpQueued;
        private bool dashQueued;
        private float dashTimer;
        private float dashCooldownTimer;
        private Vector3 dashDirection;
        private Vector3 externalMotion;
        private bool controlEnabled = true;

        private void Awake()
        {
            controller = GetComponent<CharacterController>();
            if (cameraTransform == null && Camera.main != null)
                cameraTransform = Camera.main.transform;
        }

        // ---------- Chamadas para botões de UI e cinemáticas ----------
        public void Jump() => jumpQueued = true;
        public void Dash() => dashQueued = true;
        public void SetControlEnabled(bool value) => controlEnabled = value;

        /// <summary>Usado por correntezas e plataformas móveis para empurrar o jogador.</summary>
        public void AddExternalMotion(Vector3 motionPerSecond) => externalMotion += motionPerSecond;

        private void Update()
        {
            float dt = Time.deltaTime;
            if (dashCooldownTimer > 0f) dashCooldownTimer -= dt;

            if (JasonInput.JumpPressed()) jumpQueued = true;
            if (JasonInput.DashPressed()) dashQueued = true;

            if (!controlEnabled)
            {
                jumpQueued = false;
                dashQueued = false;
            }

            bool grounded = controller.isGrounded;
            if (grounded)
            {
                lastGroundedTime = Time.time;
                airJumpsUsed = 0;
                if (verticalVelocity < 0f) verticalVelocity = -2f;
            }

            // ----- Entrada de movimento relativa à câmera -----
            Vector2 input = Vector2.zero;
            if (controlEnabled)
            {
                input = JasonInput.KeyboardMove();
                if (joystick != null && joystick.Value.sqrMagnitude > 0.0001f) input = joystick.Value;
                input = Vector2.ClampMagnitude(input, 1f);
            }

            Vector3 camForward = Vector3.forward;
            Vector3 camRight = Vector3.right;
            if (cameraTransform != null)
            {
                camForward = Vector3.ProjectOnPlane(cameraTransform.forward, Vector3.up).normalized;
                camRight = Vector3.ProjectOnPlane(cameraTransform.right, Vector3.up).normalized;
            }
            Vector3 wishDir = camForward * input.y + camRight * input.x;

            // ----- Dash -----
            if (dashQueued)
            {
                dashQueued = false;
                if (dashEnabled && dashCooldownTimer <= 0f && !IsDashing)
                {
                    dashDirection = wishDir.sqrMagnitude > 0.01f ? wishDir.normalized : transform.forward;
                    dashTimer = dashDuration;
                    dashCooldownTimer = dashCooldown;
                    verticalVelocity = 0f;
                }
            }

            Vector3 motion;
            if (IsDashing)
            {
                dashTimer -= dt;
                motion = dashDirection * dashSpeed * dt;
                RotateTowards(dashDirection, dt);
            }
            else
            {
                Vector3 target = wishDir * moveSpeed;
                horizontalVelocity = Vector3.MoveTowards(horizontalVelocity, target, acceleration * dt);

                if (wishDir.sqrMagnitude > 0.01f) RotateTowards(wishDir, dt);

                // ----- Pulo / salto duplo -----
                if (jumpQueued)
                {
                    jumpQueued = false;
                    bool canGroundJump = Time.time - lastGroundedTime <= coyoteTime;
                    if (canGroundJump)
                    {
                        verticalVelocity = Mathf.Sqrt(jumpHeight * -2f * gravity);
                        lastGroundedTime = -10f;
                    }
                    else if (airJumpsUsed < extraAirJumps)
                    {
                        airJumpsUsed++;
                        verticalVelocity = Mathf.Sqrt(jumpHeight * -2f * gravity);
                    }
                }

                verticalVelocity += gravity * dt;
                motion = (horizontalVelocity + Vector3.up * verticalVelocity) * dt;
            }

            motion += externalMotion * dt;
            externalMotion = Vector3.zero;

            controller.Move(motion);
        }

        private void RotateTowards(Vector3 dir, float dt)
        {
            if (dir.sqrMagnitude < 0.0001f) return;
            Quaternion target = Quaternion.LookRotation(dir, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, target, 1f - Mathf.Exp(-rotationSpeed * dt));
        }

        // Empurra blocos dinâmicos ao andar contra eles.
        private void OnControllerColliderHit(ControllerColliderHit hit)
        {
            Rigidbody body = hit.collider.attachedRigidbody;
            if (body == null || body.isKinematic) return;
            if (hit.moveDirection.y < -0.3f) return;

            Vector3 push = new Vector3(hit.moveDirection.x, 0f, hit.moveDirection.z);
            body.AddForce(push * pushPower, ForceMode.Impulse);
        }
    }
}
