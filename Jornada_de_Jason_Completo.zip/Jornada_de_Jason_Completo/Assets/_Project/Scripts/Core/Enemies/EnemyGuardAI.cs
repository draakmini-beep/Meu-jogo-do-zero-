using UnityEngine;
using UnityEngine.AI;

namespace JornadaDeJason
{
    /// <summary>
    /// IA de inimigo com NavMeshAgent: patrulha, detecta, persegue e ataca em intervalos.
    /// Serve para Sentinelas (corpo a corpo), Arqueiros (ataque à distância com linha de visão)
    /// e Golems. O dano por blocos arremessados vem do HealthSystem ("Takes Impact Damage").
    ///
    /// Requer: NavMeshAgent, HealthSystem e um Rigidbody Kinematic (para receber colisões físicas).
    /// </summary>
    [RequireComponent(typeof(NavMeshAgent))]
    [RequireComponent(typeof(HealthSystem))]
    public class EnemyGuardAI : MonoBehaviour
    {
        private enum State { Patrol, Chase, Attack, Dead }

        [Header("Alvo")]
        [Tooltip("Se vazio, procura o objeto com a tag 'Player'.")]
        [SerializeField] private Transform player;

        [Header("Patrulha")]
        [SerializeField] private Transform[] waypoints;
        [SerializeField, Min(0f)] private float patrolSpeed = 2f;
        [SerializeField, Min(0f)] private float waypointWait = 1.5f;

        [Header("Detecção")]
        [SerializeField, Min(1f)] private float sightRange = 12f;
        [SerializeField, Range(10f, 360f)] private float fieldOfView = 120f;
        [SerializeField, Min(1f)] private float loseTargetRange = 18f;
        [SerializeField] private float eyeHeight = 1.5f;
        [SerializeField] private LayerMask sightBlockers = ~0;

        [Header("Perseguição e ataque")]
        [SerializeField, Min(0f)] private float chaseSpeed = 4.5f;
        [SerializeField, Min(0.5f)] private float attackRange = 2f;
        [SerializeField, Min(0.1f)] private float attackInterval = 1.4f;
        [SerializeField, Min(0f)] private float attackDamage = 10f;
        [Tooltip("Marque para Arqueiros: ataca à distância exigindo linha de visão.")]
        [SerializeField] private bool requireLineOfSight;
        [SerializeField, Min(0.05f)] private float pathRefreshInterval = 0.25f;

        [Header("Morte")]
        [SerializeField, Min(0f)] private float removeDelay = 3f;

        [Header("Animação (opcional)")]
        [SerializeField] private Animator animator;

        private static readonly int SpeedHash = Animator.StringToHash("Speed");
        private static readonly int AttackHash = Animator.StringToHash("Attack");
        private static readonly int DieHash = Animator.StringToHash("Die");

        private NavMeshAgent agent;
        private HealthSystem health;
        private HealthSystem playerHealth;
        private State state = State.Patrol;
        private int waypointIndex;
        private float waitTimer;
        private float nextAttackTime;
        private float nextPathTime;

        private void Awake()
        {
            agent = GetComponent<NavMeshAgent>();
            health = GetComponent<HealthSystem>();
            health.onDied.AddListener(OnDied);
        }

        private void Start()
        {
            if (player == null)
            {
                GameObject p = GameObject.FindGameObjectWithTag("Player");
                if (p != null) player = p.transform;
            }
            if (player != null) playerHealth = player.GetComponentInParent<HealthSystem>();
            GoToCurrentWaypoint();
        }

        private void OnDestroy()
        {
            if (health != null) health.onDied.RemoveListener(OnDied);
        }

        private void Update()
        {
            if (state == State.Dead) return;
            // Sem NavMesh sob o inimigo, o agente não pode andar (evita erros no Console).
            if (!agent.isOnNavMesh) return;
            if (animator != null) SetFloatSafe(SpeedHash, agent.velocity.magnitude);
            if (player == null) { Patrol(); return; }

            float dist = Vector3.Distance(transform.position, player.position);
            bool playerDead = playerHealth != null && playerHealth.IsDead;

            switch (state)
            {
                case State.Patrol:
                    if (!playerDead && CanSeePlayer(dist)) { state = State.Chase; agent.speed = chaseSpeed; }
                    else Patrol();
                    break;

                case State.Chase:
                    if (playerDead || dist > loseTargetRange)
                    {
                        state = State.Patrol;
                        agent.speed = patrolSpeed;
                        GoToCurrentWaypoint();
                        break;
                    }
                    if (dist <= attackRange && (!requireLineOfSight || HasLineOfSight()))
                    {
                        state = State.Attack;
                        agent.ResetPath();
                        break;
                    }
                    if (Time.time >= nextPathTime)
                    {
                        nextPathTime = Time.time + pathRefreshInterval;
                        agent.SetDestination(player.position);
                    }
                    break;

                case State.Attack:
                    if (playerDead) { state = State.Patrol; agent.speed = patrolSpeed; GoToCurrentWaypoint(); break; }
                    FacePlayer();
                    if (dist > attackRange * 1.2f || (requireLineOfSight && !HasLineOfSight()))
                    {
                        state = State.Chase;
                        break;
                    }
                    if (Time.time >= nextAttackTime)
                    {
                        nextAttackTime = Time.time + attackInterval;
                        PerformAttack();
                    }
                    break;
            }
        }

        private void Patrol()
        {
            agent.speed = patrolSpeed;
            if (waypoints == null || waypoints.Length == 0) return;
            if (agent.pathPending) return;

            if (agent.remainingDistance <= agent.stoppingDistance + 0.2f)
            {
                waitTimer += Time.deltaTime;
                if (waitTimer >= waypointWait)
                {
                    waitTimer = 0f;
                    waypointIndex = (waypointIndex + 1) % waypoints.Length;
                    GoToCurrentWaypoint();
                }
            }
        }

        private void GoToCurrentWaypoint()
        {
            if (waypoints == null || waypoints.Length == 0 || !agent.isOnNavMesh) return;
            Transform wp = waypoints[waypointIndex];
            if (wp != null) agent.SetDestination(wp.position);
        }

        private bool CanSeePlayer(float dist)
        {
            if (dist > sightRange) return false;
            Vector3 to = player.position - transform.position;
            to.y = 0f;
            if (Vector3.Angle(transform.forward, to) > fieldOfView * 0.5f) return false;
            return HasLineOfSight();
        }

        private bool HasLineOfSight()
        {
            Vector3 eye = transform.position + Vector3.up * eyeHeight;
            Vector3 target = player.position + Vector3.up * 1f;
            Vector3 dir = target - eye;
            if (Physics.Raycast(eye, dir.normalized, out RaycastHit hit, dir.magnitude, sightBlockers, QueryTriggerInteraction.Ignore))
                return hit.collider.transform.IsChildOf(player) || hit.collider.transform == player;
            return true;
        }

        private void FacePlayer()
        {
            Vector3 dir = player.position - transform.position;
            dir.y = 0f;
            if (dir.sqrMagnitude < 0.001f) return;
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(dir), 10f * Time.deltaTime);
        }

        private void PerformAttack()
        {
            if (animator != null) TriggerSafe(AttackHash);
            if (playerHealth != null) playerHealth.TakeDamage(attackDamage);
        }

        private void OnDied()
        {
            state = State.Dead;
            if (agent != null && agent.enabled)
            {
                if (agent.isOnNavMesh) agent.ResetPath();
                agent.enabled = false;
            }
            if (animator != null) TriggerSafe(DieHash);
            Destroy(gameObject, removeDelay);
        }

        // Evita avisos quando o Animator não tem o parâmetro.
        private void SetFloatSafe(int hash, float value)
        {
            foreach (var p in animator.parameters)
                if (p.nameHash == hash) { animator.SetFloat(hash, value); return; }
        }

        private void TriggerSafe(int hash)
        {
            foreach (var p in animator.parameters)
                if (p.nameHash == hash) { animator.SetTrigger(hash); return; }
        }
    }
}
