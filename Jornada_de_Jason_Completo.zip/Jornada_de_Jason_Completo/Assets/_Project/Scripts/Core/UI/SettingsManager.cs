using System;
using TMPro;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

namespace JornadaDeJason
{
    /// <summary>
    /// Configurações salvas em PlayerPrefs: volume geral (AudioListener), música e SFX (AudioMixer
    /// opcional), qualidade gráfica (Baixa/Média/Alta), sensibilidade da câmera e idioma.
    /// As configurações salvas são aplicadas automaticamente ao carregar qualquer cena.
    /// </summary>
    public class SettingsManager : MonoBehaviour
    {
        private const string KeyMaster = "cfg_master";
        private const string KeyMusic = "cfg_music";
        private const string KeySfx = "cfg_sfx";
        private const string KeyQuality = "cfg_quality";
        private const string KeySensitivity = "cfg_sensitivity";
        private const string KeyLanguage = "cfg_language";

        public const string MusicParam = "MusicVolume";
        public const string SfxParam = "SFXVolume";

        /// <summary>0 = Português, 1 = English (ou o que seu sistema de textos definir).</summary>
        public static int Language { get; private set; }
        public static event Action<int> LanguageChanged;

        [Header("Áudio (opcional)")]
        [Tooltip("Mixer com parâmetros expostos 'MusicVolume' e 'SFXVolume' (em dB).")]
        [SerializeField] private AudioMixer mixer;

        [Header("Controles de UI")]
        [SerializeField] private Slider masterSlider;
        [SerializeField] private Slider musicSlider;
        [SerializeField] private Slider sfxSlider;
        [SerializeField] private Slider sensitivitySlider;
        [Tooltip("Opções esperadas: Baixa, Média, Alta.")]
        [SerializeField] private TMP_Dropdown qualityDropdown;
        [SerializeField] private TMP_Dropdown languageDropdown;

        // Aplica as preferências salvas assim que qualquer cena carrega (inclusive as fases).
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void ApplyOnStartup()
        {
            ApplyMaster(PlayerPrefs.GetFloat(KeyMaster, 1f));
            ApplyQuality(PlayerPrefs.GetInt(KeyQuality, DefaultQualityTier()));
            TouchOrbitCamera.Sensitivity = PlayerPrefs.GetFloat(KeySensitivity, 1f);
            Language = PlayerPrefs.GetInt(KeyLanguage, 0);
        }

        private void OnEnable()
        {
            // Preenche a UI sem disparar eventos e depois liga os listeners.
            if (masterSlider != null) { masterSlider.SetValueWithoutNotify(PlayerPrefs.GetFloat(KeyMaster, 1f)); masterSlider.onValueChanged.AddListener(SetMaster); }
            if (musicSlider != null) { musicSlider.SetValueWithoutNotify(PlayerPrefs.GetFloat(KeyMusic, 0.8f)); musicSlider.onValueChanged.AddListener(SetMusic); }
            if (sfxSlider != null) { sfxSlider.SetValueWithoutNotify(PlayerPrefs.GetFloat(KeySfx, 0.8f)); sfxSlider.onValueChanged.AddListener(SetSfx); }
            if (sensitivitySlider != null)
            {
                sensitivitySlider.minValue = 0.2f;
                sensitivitySlider.maxValue = 3f;
                sensitivitySlider.SetValueWithoutNotify(PlayerPrefs.GetFloat(KeySensitivity, 1f));
                sensitivitySlider.onValueChanged.AddListener(SetSensitivity);
            }
            if (qualityDropdown != null)
            {
                qualityDropdown.SetValueWithoutNotify(Mathf.Clamp(PlayerPrefs.GetInt(KeyQuality, DefaultQualityTier()), 0, 2));
                qualityDropdown.onValueChanged.AddListener(SetQualityTier);
            }
            if (languageDropdown != null)
            {
                languageDropdown.SetValueWithoutNotify(PlayerPrefs.GetInt(KeyLanguage, 0));
                languageDropdown.onValueChanged.AddListener(SetLanguage);
            }

            // Áudio do mixer só pode ser aplicado quando há referência.
            ApplyMixer(PlayerPrefs.GetFloat(KeyMusic, 0.8f), PlayerPrefs.GetFloat(KeySfx, 0.8f));
        }

        private void OnDisable()
        {
            if (masterSlider != null) masterSlider.onValueChanged.RemoveListener(SetMaster);
            if (musicSlider != null) musicSlider.onValueChanged.RemoveListener(SetMusic);
            if (sfxSlider != null) sfxSlider.onValueChanged.RemoveListener(SetSfx);
            if (sensitivitySlider != null) sensitivitySlider.onValueChanged.RemoveListener(SetSensitivity);
            if (qualityDropdown != null) qualityDropdown.onValueChanged.RemoveListener(SetQualityTier);
            if (languageDropdown != null) languageDropdown.onValueChanged.RemoveListener(SetLanguage);
            PlayerPrefs.Save();
        }

        public void SetMaster(float value)
        {
            PlayerPrefs.SetFloat(KeyMaster, value);
            ApplyMaster(value);
        }

        public void SetMusic(float value)
        {
            PlayerPrefs.SetFloat(KeyMusic, value);
            SetMixerVolume(MusicParam, value);
        }

        public void SetSfx(float value)
        {
            PlayerPrefs.SetFloat(KeySfx, value);
            SetMixerVolume(SfxParam, value);
        }

        public void SetSensitivity(float value)
        {
            PlayerPrefs.SetFloat(KeySensitivity, value);
            TouchOrbitCamera.Sensitivity = value;
        }

        /// <summary>0 = Baixa, 1 = Média, 2 = Alta.</summary>
        public void SetQualityTier(int tier)
        {
            tier = Mathf.Clamp(tier, 0, 2);
            PlayerPrefs.SetInt(KeyQuality, tier);
            ApplyQuality(tier);
        }

        public void SetLanguage(int index)
        {
            PlayerPrefs.SetInt(KeyLanguage, index);
            Language = index;
            LanguageChanged?.Invoke(index);
        }

        public void ResetToDefaults()
        {
            PlayerPrefs.DeleteKey(KeyMaster);
            PlayerPrefs.DeleteKey(KeyMusic);
            PlayerPrefs.DeleteKey(KeySfx);
            PlayerPrefs.DeleteKey(KeyQuality);
            PlayerPrefs.DeleteKey(KeySensitivity);
            PlayerPrefs.DeleteKey(KeyLanguage);
            ApplyOnStartup();
            OnDisable();
            OnEnable();
        }

        // ---------- Aplicação ----------
        private static void ApplyMaster(float value) => AudioListener.volume = Mathf.Clamp01(value);

        private static int DefaultQualityTier() => 1;

        private static void ApplyQuality(int tier)
        {
            int count = QualitySettings.names.Length;
            if (count == 0) return;
            // Mapeia Baixa/Média/Alta para os níveis disponíveis no projeto.
            int level = Mathf.RoundToInt(Mathf.Clamp(tier, 0, 2) / 2f * (count - 1));
            QualitySettings.SetQualityLevel(level, true);
        }

        private void ApplyMixer(float music, float sfx)
        {
            SetMixerVolume(MusicParam, music);
            SetMixerVolume(SfxParam, sfx);
        }

        private void SetMixerVolume(string parameter, float linear)
        {
            if (mixer == null) return;
            float dB = Mathf.Log10(Mathf.Max(0.0001f, linear)) * 20f;
            mixer.SetFloat(parameter, dB);
        }
    }
}
