using UnityEngine;
using UnityEngine.UI;

namespace JornadaDeJason
{
    /// <summary>Texto de HUD que mostra as moedas salvas e se atualiza sozinho.</summary>
    public class CoinsLabel : MonoBehaviour
    {
        [SerializeField] private Text label;
        [SerializeField] private string prefix = "Moedas: ";

        private void OnEnable()
        {
            JasonSave.CoinsChanged += Refresh;
            Refresh(JasonSave.Coins);
        }

        private void OnDisable()
        {
            JasonSave.CoinsChanged -= Refresh;
        }

        private void Refresh(int coins)
        {
            if (label != null) label.text = prefix + coins;
        }
    }
}
