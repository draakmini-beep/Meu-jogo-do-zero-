using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace JornadaDeJason
{
    /// <summary>
    /// Tela de carregamento assíncrona com barra de progresso e dicas aleatórias.
    /// Coloque num Canvas com um painel "loadingPanel" (inicialmente desligado).
    /// Botões chamam LoadLevel("NomeDaCena") ou LoadLevelByIndex(n).
    /// As cenas precisam estar em File > Build Profiles (Scene List).
    /// </summary>
    public class LevelLoader : MonoBehaviour
    {
        [Header("Interface")]
        [SerializeField] private GameObject loadingPanel;
        [SerializeField] private Slider progressBar;
        [SerializeField] private TMP_Text progressText;
        [SerializeField] private TMP_Text tipText;

        [Header("Comportamento")]
        [Tooltip("Tempo mínimo na tela, para dar tempo de ler a dica.")]
        [SerializeField, Min(0f)] private float minDisplayTime = 1.5f;
        [SerializeField, Min(0.5f)] private float tipInterval = 3.5f;
        [SerializeField, Min(0.1f)] private float barSpeed = 1.5f;

        [Header("Dicas e história")]
        [TextArea(2, 4)]
        [SerializeField] private string[] tips =
        {
            "Blocos de madeira boiam; pedra e metal afundam. Use isso para atravessar rios.",
            "Placas de pressão somam a massa dos blocos. Encontre o peso exato!",
            "O Cajado de Gelo cria plataformas sobre a água, mas elas derretem depois de um tempo.",
            "A Manopla Gravitacional ergue blocos; arremesse-os contra guardas para causar dano.",
            "Yarin está presa na Cidadela de Malakor. Cada região traz você mais perto dela.",
            "Use a Visão Analítica para revelar mecanismos escondidos nos enigmas."
        };

        private bool loading;

        private void Awake()
        {
            if (loadingPanel != null) loadingPanel.SetActive(false);
        }

        public void LoadLevel(string sceneName)
        {
            if (loading) return;
            if (!Application.CanStreamedLevelBeLoaded(sceneName))
            {
                Debug.LogError("[LevelLoader] Cena não encontrada nas Build Settings: " + sceneName);
                return;
            }
            StartCoroutine(LoadRoutine(() => SceneManager.LoadSceneAsync(sceneName)));
        }

        public void LoadLevelByIndex(int buildIndex)
        {
            if (loading) return;
            if (buildIndex < 0 || buildIndex >= SceneManager.sceneCountInBuildSettings)
            {
                Debug.LogError("[LevelLoader] Índice de cena inválido: " + buildIndex);
                return;
            }
            StartCoroutine(LoadRoutine(() => SceneManager.LoadSceneAsync(buildIndex)));
        }

        public void ReloadCurrentLevel() => LoadLevelByIndex(SceneManager.GetActiveScene().buildIndex);

        private IEnumerator LoadRoutine(System.Func<AsyncOperation> start)
        {
            loading = true;
            Time.timeScale = 1f; // garante que pausa/câmera lenta não travem o carregamento

            if (loadingPanel != null) loadingPanel.SetActive(true);
            ShowRandomTip();
            SetProgress(0f);

            AsyncOperation op = start();
            op.allowSceneActivation = false;

            float elapsed = 0f;
            float shown = 0f;
            float tipTimer = 0f;

            // O progresso do Unity para em 0.9 até permitir a ativação da cena.
            while (true)
            {
                float dt = Time.unscaledDeltaTime;
                elapsed += dt;
                tipTimer += dt;
                if (tipTimer >= tipInterval) { tipTimer = 0f; ShowRandomTip(); }

                float target = Mathf.Clamp01(op.progress / 0.9f);
                shown = Mathf.MoveTowards(shown, target, barSpeed * dt);
                SetProgress(shown);

                if (op.progress >= 0.9f && shown >= 0.99f && elapsed >= minDisplayTime) break;
                yield return null;
            }

            SetProgress(1f);
            op.allowSceneActivation = true;
            while (!op.isDone) yield return null;

            loading = false;
        }

        private void SetProgress(float value)
        {
            if (progressBar != null) progressBar.value = value;
            if (progressText != null) progressText.text = Mathf.RoundToInt(value * 100f) + "%";
        }

        private void ShowRandomTip()
        {
            if (tipText == null || tips == null || tips.Length == 0) return;
            tipText.text = tips[Random.Range(0, tips.Length)];
        }
    }
}
