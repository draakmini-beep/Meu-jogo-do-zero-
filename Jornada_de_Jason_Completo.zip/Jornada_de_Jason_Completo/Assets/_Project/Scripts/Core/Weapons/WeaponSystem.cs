using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace JornadaDeJason
{
    /// <summary>
    /// Armas físicas do Jason: Manopla Gravitacional (ergue/arremessa blocos),
    /// Canhão de Impacto (onda de choque) e Cajado de Gelo (plataformas de gelo sobre a água).
    /// A mira vai do centro da tela (câmera). Botões de UI chamam OnFirePressed() e NextWeapon().
    /// </summary>
    public class WeaponSystem : MonoBehaviour
    {
        public enum WeaponType { GravityGauntlet, ImpactCannon, IceStaff }

        [Header("Mira")]
        [Tooltip("Se vazio, usa Camera.main.")]
        [SerializeField] private Camera aimCamera;
        [Tooltip("Ponto onde o bloco fica preso (filho do Jason, à frente).")]
        [SerializeField] private Transform holdPoint;
        [SerializeField] private LayerMask aimMask = ~0;
        [SerializeField] private WeaponType current = WeaponType.GravityGauntlet;

        [Header("Manopla Gravitacional")]
        [SerializeField, Min(1f)] private float grabRange = 12f;
        [SerializeField, Min(0.1f)] private float maxGrabMass = 15f;
        [SerializeField, Min(1f)] private float holdFollowGain = 12f;
        [SerializeField, Min(0f)] private float throwForce = 22f;

        [Header("Canhão de Impacto")]
        [SerializeField, Min(0.1f)] private float cannonCooldown = 1.2f;
        [SerializeField, Min(0.5f)] private float cannonRadius = 6f;
        [SerializeField, Min(0f)] private float cannonForce = 600f;
        [SerializeField, Min(0f)] private float cannonUpwards = 0.6f;
        [SerializeField, Min(0f)] private float cannonDamage = 25f;
        [SerializeField, Min(1f)] private float cannonRange = 40f;
        [SerializeField] private GameObject cannonEffectPrefab;

        [Header("Cajado de Gelo")]
        [SerializeField, Min(0.1f)] private float iceCooldown = 0.8f;
        [SerializeField, Min(1f)] private float iceRange = 25f;
        [SerializeField] private Vector3 iceSize = new Vector3(3f, 0.3f, 3f);
        [SerializeField, Min(0.1f)] private float iceMass = 0.4f;
        [SerializeField, Min(1f)] private float iceLifetime = 15f;
        [SerializeField] private Material iceMaterial;
        [Tooltip("Opcional: prefab próprio da plataforma. Se vazio, cria um cubo.")]
        [SerializeField] private GameObject icePlatformPrefab;

        [Header("Eventos")]
        public UnityEvent<int> onWeaponChanged;
        public UnityEvent onFired;

        public WeaponType Current => current;

        private Rigidbody held;
        private bool heldHadGravity;
        private float nextCannonTime;
        private float nextIceTime;
        private readonly List<GameObject> icePlatforms = new List<GameObject>();

        private void Awake()
        {
            if (aimCamera == null) aimCamera = Camera.main;
        }

        private void Start()
        {
            onWeaponChanged?.Invoke((int)current);
        }

        // ---------- API para botões de UI ----------
        public void SelectWeapon(int index)
        {
            int count = System.Enum.GetValues(typeof(WeaponType)).Length;
            index = Mathf.Clamp(index, 0, count - 1);
            if ((WeaponType)index == current) return;
            ReleaseHeld(false);
            current = (WeaponType)index;
            onWeaponChanged?.Invoke(index);
        }

        public void NextWeapon()
        {
            int count = System.Enum.GetValues(typeof(WeaponType)).Length;
            SelectWeapon(((int)current + 1) % count);
        }

        public void OnFirePressed()
        {
            switch (current)
            {
                case WeaponType.GravityGauntlet: UseGauntlet(); break;
                case WeaponType.ImpactCannon: FireCannon(); break;
                case WeaponType.IceStaff: FireIce(); break;
            }
        }

        private void Update()
        {
            if (JasonInput.FirePressed()) OnFirePressed();
            if (JasonInput.NextWeaponPressed()) NextWeapon();
        }

        private void FixedUpdate()
        {
            if (held == null) return;
            Vector3 anchor = holdPoint != null ? holdPoint.position : transform.position + transform.forward * 2.5f + Vector3.up;
            Vector3 toTarget = anchor - held.position;
            held.linearVelocity = toTarget * holdFollowGain;
            held.angularVelocity *= 0.9f;
        }

        // ---------- Manopla Gravitacional ----------
        private void UseGauntlet()
        {
            if (held != null)
            {
                ThrowHeld();
                return;
            }

            if (!TryAimRay(grabRange, out RaycastHit hit)) return;
            Rigidbody rb = hit.rigidbody;
            if (rb == null || rb.isKinematic) return;
            if (rb.mass > maxGrabMass * MapPowerUp.StrengthMultiplier) return;

            held = rb;
            heldHadGravity = rb.useGravity;
            rb.useGravity = false;
            onFired?.Invoke();
        }

        private void ThrowHeld()
        {
            Rigidbody rb = held;
            ReleaseHeld(true);
            if (rb == null) return;
            Vector3 dir = aimCamera != null ? aimCamera.transform.forward : transform.forward;
            rb.AddForce(dir * throwForce * MapPowerUp.StrengthMultiplier * Mathf.Max(1f, rb.mass * 0.25f), ForceMode.Impulse);
            onFired?.Invoke();
        }

        private void ReleaseHeld(bool keepVelocity)
        {
            if (held == null) return;
            held.useGravity = heldHadGravity;
            if (!keepVelocity) held.linearVelocity = Vector3.zero;
            held = null;
        }

        // ---------- Canhão de Impacto ----------
        private void FireCannon()
        {
            if (Time.time < nextCannonTime) return;
            nextCannonTime = Time.time + cannonCooldown;

            Vector3 point;
            if (TryAimRay(cannonRange, out RaycastHit hit)) point = hit.point;
            else point = GetAimOrigin() + GetAimDirection() * cannonRange;

            float strength = MapPowerUp.StrengthMultiplier;
            Collider[] hits = Physics.OverlapSphere(point, cannonRadius, ~0, QueryTriggerInteraction.Ignore);
            var processed = new HashSet<Rigidbody>();
            var damaged = new HashSet<HealthSystem>();

            foreach (var c in hits)
            {
                Rigidbody rb = c.attachedRigidbody;
                if (rb != null && !rb.isKinematic && processed.Add(rb))
                    rb.AddExplosionForce(cannonForce * strength, point, cannonRadius, cannonUpwards, ForceMode.Impulse);

                HealthSystem hp = c.GetComponentInParent<HealthSystem>();
                if (hp != null && !hp.CompareTag("Player") && damaged.Add(hp))
                {
                    float falloff = 1f - Mathf.Clamp01(Vector3.Distance(point, c.bounds.ClosestPoint(point)) / cannonRadius);
                    hp.TakeDamage(cannonDamage * strength * Mathf.Max(0.25f, falloff));
                }
            }

            if (cannonEffectPrefab != null)
                Destroy(Instantiate(cannonEffectPrefab, point, Quaternion.identity), 3f);
            onFired?.Invoke();
        }

        // ---------- Cajado de Gelo ----------
        private void FireIce()
        {
            if (Time.time < nextIceTime) return;

            // Precisa incluir triggers para acertar o volume de água.
            Ray ray = new Ray(GetAimOrigin(), GetAimDirection());
            if (!Physics.Raycast(ray, out RaycastHit hit, iceRange, aimMask, QueryTriggerInteraction.Collide)) return;

            WaterBuoyancy water = hit.collider.GetComponentInParent<WaterBuoyancy>();
            if (water == null) return;

            nextIceTime = Time.time + iceCooldown;
            Vector3 pos = new Vector3(hit.point.x, water.SurfaceY, hit.point.z);
            CreateIcePlatform(pos);
            onFired?.Invoke();
        }

        private void CreateIcePlatform(Vector3 position)
        {
            GameObject go;
            if (icePlatformPrefab != null)
            {
                go = Instantiate(icePlatformPrefab, position, Quaternion.identity);
            }
            else
            {
                go = GameObject.CreatePrimitive(PrimitiveType.Cube);
                go.name = "PlataformaDeGelo";
                go.transform.position = position;
                go.transform.localScale = iceSize;
                if (iceMaterial != null) go.GetComponent<Renderer>().sharedMaterial = iceMaterial;
            }

            if (!go.TryGetComponent(out Rigidbody rb)) rb = go.AddComponent<Rigidbody>();
            rb.mass = iceMass;
            rb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
            rb.linearDamping = 1f;

            // Limita plataformas simultâneas (desempenho em celulares).
            icePlatforms.RemoveAll(p => p == null);
            while (icePlatforms.Count >= 6)
            {
                Destroy(icePlatforms[0]);
                icePlatforms.RemoveAt(0);
            }
            icePlatforms.Add(go);
            Destroy(go, iceLifetime);
        }

        // ---------- Utilidades de mira ----------
        private Vector3 GetAimOrigin() => aimCamera != null ? aimCamera.transform.position : transform.position + Vector3.up;
        private Vector3 GetAimDirection() => aimCamera != null ? aimCamera.transform.forward : transform.forward;

        private bool TryAimRay(float range, out RaycastHit hit)
        {
            Ray ray = new Ray(GetAimOrigin(), GetAimDirection());
            // Ignora o próprio Jason ao mirar.
            RaycastHit[] all = Physics.RaycastAll(ray, range, aimMask, QueryTriggerInteraction.Ignore);
            float best = float.MaxValue;
            hit = default;
            bool found = false;
            foreach (var h in all)
            {
                if (h.collider.transform.IsChildOf(transform)) continue;
                if (h.distance < best)
                {
                    best = h.distance;
                    hit = h;
                    found = true;
                }
            }
            return found;
        }
    }
}
