using UnityEngine;

namespace JornadaDeJason
{
    /// <summary>
    /// Volume de água (rio/lago). Coloque num objeto com um Collider marcado "Is Trigger".
    /// Calcula empuxo, arrasto e correnteza para Rigidbodies dentro do volume.
    ///
    /// Densidade do objeto = massa / volume da caixa envolvente (bounds).
    /// Com waterDensity = 1: madeira ~0.6 boia; pedra ~2.6 e metal ~7.8 afundam.
    /// Ajuste a massa do Rigidbody para decidir se o bloco boia ou afunda.
    /// </summary>
    [RequireComponent(typeof(Collider))]
    public class WaterBuoyancy : MonoBehaviour
    {
        [Header("Flutuabilidade")]
        [SerializeField, Min(0.01f)] private float waterDensity = 1f;
        [Tooltip("Se vazio, a superfície é o topo do Collider.")]
        [SerializeField] private bool useCustomSurface;
        [SerializeField] private float customSurfaceY;

        [Header("Arrasto")]
        [SerializeField, Min(0f)] private float angularDrag = 1.5f;
        [Tooltip("Quão forte o objeto é arrastado para a velocidade da água.")]
        [SerializeField, Min(0f)] private float flowDrag = 2f;

        [Header("Correnteza")]
        [Tooltip("Direção local do fluxo (em espaço do mundo se 'flowInWorldSpace').")]
        [SerializeField] private Vector3 flowDirection = Vector3.forward;
        [SerializeField] private bool flowInWorldSpace;
        [SerializeField, Min(0f)] private float flowStrength = 2f;
        [SerializeField, Min(0f)] private float playerPushFactor = 0.6f;

        private Collider volume;

        public float SurfaceY => useCustomSurface ? customSurfaceY : volume.bounds.max.y;

        public Vector3 FlowVelocity
        {
            get
            {
                Vector3 dir = flowInWorldSpace ? flowDirection : transform.TransformDirection(flowDirection);
                return dir.normalized * flowStrength;
            }
        }

        private void Awake()
        {
            volume = GetComponent<Collider>();
            volume.isTrigger = true;
        }

        /// <summary>Para puzzles de "redirecionar correntezas".</summary>
        public void SetFlow(Vector3 direction, float strength)
        {
            flowDirection = direction;
            flowStrength = Mathf.Max(0f, strength);
        }

        public void SetFlowStrength(float strength) => flowStrength = Mathf.Max(0f, strength);

        public void SetFlowDirection(Vector3 direction) => flowDirection = direction;

        private void OnTriggerStay(Collider other)
        {
            // Jogador (CharacterController) é carregado pela correnteza.
            if (other.TryGetComponent(out JasonController jason))
            {
                jason.AddExternalMotion(FlowVelocity * playerPushFactor);
                return;
            }

            Rigidbody rb = other.attachedRigidbody;
            if (rb == null || rb.isKinematic) return;

            Bounds b = other.bounds;
            float height = Mathf.Max(0.01f, b.size.y);
            float submergedFraction = Mathf.Clamp01((SurfaceY - b.min.y) / height);
            if (submergedFraction <= 0f) return;

            // Volume aproximado pela caixa envolvente.
            float volumeTotal = Mathf.Max(0.001f, b.size.x * b.size.y * b.size.z);
            float submergedVolume = volumeTotal * submergedFraction;

            // Empuxo (Arquimedes): densidade_água * volume_submerso * g, para cima.
            float buoyancy = waterDensity * submergedVolume * Physics.gravity.magnitude;
            rb.AddForce(Vector3.up * buoyancy, ForceMode.Force);

            // Arrasto proporcional à parte submersa; arrasta para a velocidade da água.
            Vector3 relative = FlowVelocity - rb.linearVelocity;
            rb.AddForce(relative * flowDrag * submergedFraction, ForceMode.Acceleration);
            rb.AddTorque(-rb.angularVelocity * angularDrag * submergedFraction, ForceMode.Acceleration);
        }
    }
}
