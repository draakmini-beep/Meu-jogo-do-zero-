using UnityEngine;

namespace JornadaDeJason
{
    /// <summary>Moeda coletável. Collider "Is Trigger"; o jogador usa a tag "Player".</summary>
    [RequireComponent(typeof(Collider))]
    public class CoinPickup : MonoBehaviour
    {
        [SerializeField, Min(1)] private int value = 1;
        [SerializeField] private AudioClip pickupSound;
        [SerializeField] private float spinSpeed = 120f;

        private bool collected;

        private void Reset()
        {
            GetComponent<Collider>().isTrigger = true;
        }

        private void Update()
        {
            transform.Rotate(0f, spinSpeed * Time.unscaledDeltaTime, 0f, Space.World);
        }

        private void OnTriggerEnter(Collider other)
        {
            if (collected || !other.CompareTag("Player")) return;
            collected = true;
            JasonSave.AddCoins(value);
            if (pickupSound != null) AudioSource.PlayClipAtPoint(pickupSound, transform.position);
            Destroy(gameObject);
        }
    }
}
