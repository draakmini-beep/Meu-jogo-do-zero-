using UnityEngine;

namespace JornadaDeJason
{
    /// <summary>
    /// Coloque no Jason (nas fases). Ao iniciar, aplica a skin equipada na loja
    /// nos Renderers indicados. Se a lista estiver vazia, usa todos os filhos.
    /// </summary>
    public class SkinApplier : MonoBehaviour
    {
        [SerializeField] private SkinCatalog catalog;
        [SerializeField] private Renderer[] targetRenderers;

        private void Start()
        {
            Apply();
        }

        public void Apply()
        {
            if (catalog == null) return;
            SkinDefinition skin = catalog.GetEquippedOrDefault();
            if (skin == null || skin.material == null) return;

            Renderer[] targets = (targetRenderers != null && targetRenderers.Length > 0)
                ? targetRenderers
                : GetComponentsInChildren<Renderer>();

            foreach (var r in targets)
            {
                if (r == null) continue;
                var mats = r.sharedMaterials;
                for (int i = 0; i < mats.Length; i++) mats[i] = skin.material;
                r.sharedMaterials = mats;
            }
        }
    }
}
