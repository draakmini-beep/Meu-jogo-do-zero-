using System;
using UnityEngine;

namespace JornadaDeJason
{
    [Serializable]
    public class SkinDefinition
    {
        public string id = "explorador";
        public string displayName = "Explorador";
        [Min(0)] public int price = 0;
        public Material material;
        [TextArea] public string description;
    }

    /// <summary>
    /// Catálogo de skins. Crie pelo menu: Assets > Create > Jornada de Jason > Catálogo de Skins.
    /// A primeira skin deve custar 0 (já vem desbloqueada).
    /// Sugestões: Explorador, Cavaleiro de Cristal, Armadura Vulcânica.
    /// </summary>
    [CreateAssetMenu(fileName = "SkinCatalog", menuName = "Jornada de Jason/Catálogo de Skins")]
    public class SkinCatalog : ScriptableObject
    {
        public SkinDefinition[] skins = new SkinDefinition[0];

        public SkinDefinition Find(string id)
        {
            if (skins == null) return null;
            foreach (var s in skins)
                if (s != null && s.id == id) return s;
            return null;
        }

        public bool IsOwned(SkinDefinition skin)
        {
            return skin != null && (skin.price <= 0 || JasonSave.OwnsSkin(skin.id));
        }

        public SkinDefinition GetEquippedOrDefault()
        {
            var equipped = Find(JasonSave.Data.equippedSkin);
            if (equipped != null && IsOwned(equipped)) return equipped;
            return skins != null && skins.Length > 0 ? skins[0] : null;
        }
    }
}
