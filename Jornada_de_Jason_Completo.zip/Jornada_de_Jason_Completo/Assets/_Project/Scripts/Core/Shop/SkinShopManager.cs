using TMPro;
using UnityEngine;
using UnityEngine.Events;

namespace JornadaDeJason
{
    /// <summary>
    /// Loja de skins com pré-visualização 3D. Um modelo do Jason fica num "palco" (com câmera
    /// própria ou RenderTexture) e gira devagar; os botões Anterior/Próxima trocam a skin
    /// exibida e o botão de ação compra ou equipa. Tudo é salvo em JSON via JasonSave.
    /// </summary>
    public class SkinShopManager : MonoBehaviour
    {
        [Header("Dados")]
        [SerializeField] private SkinCatalog catalog;

        [Header("Pré-visualização 3D")]
        [SerializeField] private Transform previewPivot;
        [SerializeField] private Renderer[] previewRenderers;
        [SerializeField, Min(0f)] private float previewSpinSpeed = 30f;

        [Header("Interface")]
        [SerializeField] private TMP_Text skinNameText;
        [SerializeField] private TMP_Text descriptionText;
        [SerializeField] private TMP_Text priceText;
        [SerializeField] private TMP_Text coinsText;
        [SerializeField] private TMP_Text actionButtonText;
        [SerializeField] private TMP_Text feedbackText;

        [Header("Textos")]
        [SerializeField] private string buyLabel = "Comprar";
        [SerializeField] private string equipLabel = "Equipar";
        [SerializeField] private string equippedLabel = "Equipado";
        [SerializeField] private string notEnoughCoinsText = "Moedas insuficientes";

        [Header("Eventos")]
        public UnityEvent onPurchased;
        public UnityEvent onEquipped;
        public UnityEvent onPurchaseFailed;

        private int index;

        private void OnEnable()
        {
            JasonSave.CoinsChanged += OnCoinsChanged;
            if (catalog != null && catalog.skins != null && catalog.skins.Length > 0)
            {
                var equipped = catalog.GetEquippedOrDefault();
                index = Mathf.Max(0, System.Array.IndexOf(catalog.skins, equipped));
            }
            if (feedbackText != null) feedbackText.text = "";
            Refresh();
        }

        private void OnDisable()
        {
            JasonSave.CoinsChanged -= OnCoinsChanged;
        }

        private void Update()
        {
            if (previewPivot != null)
                previewPivot.Rotate(0f, previewSpinSpeed * Time.unscaledDeltaTime, 0f, Space.World);
        }

        private void OnCoinsChanged(int coins)
        {
            if (coinsText != null) coinsText.text = coins.ToString();
        }

        // ---------- Botões ----------
        public void Next() => Step(1);
        public void Previous() => Step(-1);

        public void OnActionButton()
        {
            SkinDefinition skin = Current();
            if (skin == null) return;

            if (!catalog.IsOwned(skin))
            {
                if (JasonSave.TrySpendCoins(skin.price))
                {
                    JasonSave.UnlockSkin(skin.id);
                    JasonSave.EquipSkin(skin.id);
                    SetFeedback("");
                    onPurchased?.Invoke();
                }
                else
                {
                    SetFeedback(notEnoughCoinsText);
                    onPurchaseFailed?.Invoke();
                }
            }
            else
            {
                JasonSave.EquipSkin(skin.id);
                onEquipped?.Invoke();
            }
            Refresh();
        }

        // ---------- Interno ----------
        private void Step(int dir)
        {
            if (catalog == null || catalog.skins == null || catalog.skins.Length == 0) return;
            int n = catalog.skins.Length;
            index = ((index + dir) % n + n) % n;
            SetFeedback("");
            Refresh();
        }

        private SkinDefinition Current()
        {
            if (catalog == null || catalog.skins == null || catalog.skins.Length == 0) return null;
            index = Mathf.Clamp(index, 0, catalog.skins.Length - 1);
            return catalog.skins[index];
        }

        private void Refresh()
        {
            SkinDefinition skin = Current();
            if (coinsText != null) coinsText.text = JasonSave.Coins.ToString();
            if (skin == null) return;

            if (previewRenderers != null && skin.material != null)
            {
                foreach (var r in previewRenderers)
                {
                    if (r == null) continue;
                    var mats = r.sharedMaterials;
                    for (int i = 0; i < mats.Length; i++) mats[i] = skin.material;
                    r.sharedMaterials = mats;
                }
            }

            bool owned = catalog.IsOwned(skin);
            bool equipped = JasonSave.Data.equippedSkin == skin.id
                            || (string.IsNullOrEmpty(JasonSave.Data.equippedSkin) && catalog.skins[0] == skin);

            if (skinNameText != null) skinNameText.text = skin.displayName;
            if (descriptionText != null) descriptionText.text = skin.description;
            if (priceText != null) priceText.text = owned ? "" : skin.price.ToString();
            if (actionButtonText != null)
                actionButtonText.text = !owned ? buyLabel : (equipped ? equippedLabel : equipLabel);
        }

        private void SetFeedback(string text)
        {
            if (feedbackText != null) feedbackText.text = text;
        }
    }
}
