using UnityEngine;

[CreateAssetMenu(fileName = "Armor", menuName = "Jason/Equipment/Armor")]
public class ArmorProfile223 : ScriptableObject
{
    public string armorId;
    public string armorName;
    public EquipmentProfile223 equipmentProfile;
    [Range(0f, 0.9f)] public float physicalResistance;
    [Range(0f, 0.9f)] public float fireResistance;
    [Range(0f, 0.9f)] public float iceResistance;
    [Range(0f, 0.9f)] public float electricResistance;
    [Range(0f, 0.9f)] public float shadowResistance;

    public float GetResistance(WeaponElement223 element)
    {
        switch (element)
        {
            case WeaponElement223.Fire: return fireResistance;
            case WeaponElement223.Ice: return iceResistance;
            case WeaponElement223.Electric: return electricResistance;
            case WeaponElement223.Shadow: return shadowResistance;
            default: return physicalResistance;
        }
    }

    public float CalculateDamage(float damage, WeaponElement223 element)
    {
        return Mathf.Max(0f, damage * (1f - GetResistance(element)));
    }
}
