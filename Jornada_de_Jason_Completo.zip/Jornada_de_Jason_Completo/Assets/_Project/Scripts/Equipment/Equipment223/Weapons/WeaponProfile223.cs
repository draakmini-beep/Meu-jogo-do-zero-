using UnityEngine;

[CreateAssetMenu(fileName = "Weapon", menuName = "Jason/Equipment/Weapon")]
public class WeaponProfile223 : ScriptableObject
{
    public string weaponId;
    public string weaponName;
    public WeaponElement223 element;
    [Min(0f)] public float baseDamage = 20f;
    [Min(0.01f)] public float attackSpeed = 1f;
    [Range(0f, 1f)] public float criticalChance = 0.05f;
    public GameObject weaponPrefab;
    public EquipmentProfile223 equipmentProfile;

    public bool IsValid()
    {
        return !string.IsNullOrWhiteSpace(weaponId) &&
               baseDamage >= 0f && attackSpeed > 0f &&
               criticalChance >= 0f && criticalChance <= 1f;
    }
}
