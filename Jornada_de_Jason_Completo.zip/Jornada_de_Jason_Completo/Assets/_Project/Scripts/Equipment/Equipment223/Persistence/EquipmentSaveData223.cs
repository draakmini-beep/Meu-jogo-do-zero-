using System;
using System.Collections.Generic;

[Serializable]
public class EquipmentItemSave223
{
    public string equipmentId;
    public string instanceId;
    public EquipmentSlot223 slot;
    public float durability;
    public int upgradeLevel;
    public List<string> enchantmentIds = new List<string>();
}

[Serializable]
public class EquipmentSaveData223
{
    public List<EquipmentItemSave223> equipped = new List<EquipmentItemSave223>();
    public string selectedWeaponId;
    public string selectedArmorSetId;
}
