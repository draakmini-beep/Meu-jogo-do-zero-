using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class EquippedItem223
{
    public EquipmentSlot223 slot;
    public EquipmentProfile223 profile;
}

public class EquipmentManager223 : MonoBehaviour
{
    [SerializeField] private List<EquippedItem223> equipped = new List<EquippedItem223>();
    public event Action OnEquipmentChanged;

    public bool Equip(EquipmentProfile223 profile)
    {
        if (profile == null || !profile.IsValid()) return false;
        int index = equipped.FindIndex(x => x.slot == profile.slot);
        if (index >= 0) equipped[index].profile = profile;
        else equipped.Add(new EquippedItem223 { slot = profile.slot, profile = profile });
        OnEquipmentChanged?.Invoke();
        return true;
    }

    public bool Unequip(EquipmentSlot223 slot)
    {
        int removed = equipped.RemoveAll(x => x.slot == slot);
        if (removed == 0) return false;
        OnEquipmentChanged?.Invoke();
        return true;
    }

    public EquipmentProfile223 GetEquipped(EquipmentSlot223 slot)
    {
        var entry = equipped.Find(x => x.slot == slot);
        return entry != null ? entry.profile : null;
    }

    public EquipmentProfile223[] GetAllEquipped()
    {
        var result = new List<EquipmentProfile223>();
        foreach (var entry in equipped)
            if (entry != null && entry.profile != null) result.Add(entry.profile);
        return result.ToArray();
    }
}
