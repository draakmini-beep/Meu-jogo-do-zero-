public enum EquipmentRarity223
{
    Common, Uncommon, Rare, Epic, Legendary, Mythic
}

public enum EquipmentSlot223
{
    Weapon, Helmet, Chest, Gloves, Legs, Boots, Accessory
}

public enum WeaponElement223
{
    Physical, Fire, Ice, Electric, Nature, Shadow, Light
}
