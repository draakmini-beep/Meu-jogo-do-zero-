using UnityEngine;

public class EquipmentDurability223 : MonoBehaviour
{
    [SerializeField, Min(1f)] private float maximumDurability = 100f;
    [SerializeField] private float currentDurability = 100f;
    public float Current => currentDurability;
    public bool IsBroken => currentDurability <= 0f;
    public float Percentage => maximumDurability <= 0f ? 0f : currentDurability / maximumDurability;

    private void OnValidate()
    {
        maximumDurability = Mathf.Max(1f, maximumDurability);
        currentDurability = Mathf.Clamp(currentDurability, 0f, maximumDurability);
    }

    public void ApplyWear(float amount)
    {
        currentDurability = Mathf.Clamp(currentDurability - Mathf.Max(0f, amount), 0f, maximumDurability);
    }

    public void Repair(float amount)
    {
        currentDurability = Mathf.Clamp(currentDurability + Mathf.Max(0f, amount), 0f, maximumDurability);
    }

    public void Restore(float value)
    {
        currentDurability = Mathf.Clamp(value, 0f, maximumDurability);
    }
}
