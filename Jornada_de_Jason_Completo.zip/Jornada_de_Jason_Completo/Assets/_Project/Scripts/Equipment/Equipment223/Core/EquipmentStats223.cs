using System;
using UnityEngine;

[Serializable]
public class EquipmentStats223
{
    public float attack;
    public float defense;
    public float health;
    public float stamina;
    [Range(0f, 1f)] public float criticalChance;
    public float movementSpeed;

    public EquipmentStats223 Clone()
    {
        return new EquipmentStats223 {
            attack = attack, defense = defense, health = health,
            stamina = stamina, criticalChance = criticalChance,
            movementSpeed = movementSpeed
        };
    }

    public void Add(EquipmentStats223 other)
    {
        if (other == null) return;
        attack += other.attack;
        defense += other.defense;
        health += other.health;
        stamina += other.stamina;
        criticalChance += other.criticalChance;
        movementSpeed += other.movementSpeed;
    }
}
