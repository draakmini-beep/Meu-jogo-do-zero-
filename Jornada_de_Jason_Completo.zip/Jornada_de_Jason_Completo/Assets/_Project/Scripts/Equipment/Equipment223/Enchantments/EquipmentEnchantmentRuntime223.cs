using System.Collections.Generic;
using UnityEngine;

public class EquipmentEnchantmentRuntime223 : MonoBehaviour
{
    [SerializeField] private List<EquipmentEnchantment223> enchantments = new List<EquipmentEnchantment223>();

    public bool Add(EquipmentEnchantment223 enchantment, int playerLevel)
    {
        if (enchantment == null || playerLevel < enchantment.requiredLevel ||
            enchantments.Contains(enchantment)) return false;
        enchantments.Add(enchantment);
        return true;
    }

    public bool Remove(string id)
    {
        return enchantments.RemoveAll(x => x != null && x.enchantmentId == id) > 0;
    }

    public float GetBonus(EnchantmentType223 type)
    {
        float total = 0f;
        foreach (var item in enchantments)
            if (item != null && item.type == type) total += item.value;
        return total;
    }
}
