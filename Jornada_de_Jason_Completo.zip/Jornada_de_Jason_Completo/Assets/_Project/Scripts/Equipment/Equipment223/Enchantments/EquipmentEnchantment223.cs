using UnityEngine;

public enum EnchantmentType223
{
    Attack, Defense, Health, CriticalChance, FireDamage,
    IceDamage, ElectricDamage, Regeneration
}

[CreateAssetMenu(fileName = "Enchantment", menuName = "Jason/Equipment/Enchantment")]
public class EquipmentEnchantment223 : ScriptableObject
{
    public string enchantmentId;
    public string enchantmentName;
    public EnchantmentType223 type;
    public float value = 5f;
    [Min(1)] public int requiredLevel = 1;
    public Sprite icon;
}
