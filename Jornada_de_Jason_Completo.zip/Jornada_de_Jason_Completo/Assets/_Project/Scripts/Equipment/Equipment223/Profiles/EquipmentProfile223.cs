using UnityEngine;

[CreateAssetMenu(fileName = "Equipment", menuName = "Jason/Equipment/Profile")]
public class EquipmentProfile223 : ScriptableObject
{
    public string equipmentId;
    public string equipmentName;
    [TextArea] public string description;
    public EquipmentSlot223 slot;
    public EquipmentRarity223 rarity;
    public EquipmentStats223 stats = new EquipmentStats223();
    public GameObject visualPrefab;
    public Sprite icon;
    [Min(1)] public int requiredLevel = 1;
    [Min(0)] public int upgradeLevel;
    [Min(0)] public int maximumUpgradeLevel = 10;

    public bool IsValid()
    {
        return !string.IsNullOrWhiteSpace(equipmentId) &&
               !string.IsNullOrWhiteSpace(equipmentName) &&
               requiredLevel >= 1 &&
               maximumUpgradeLevel >= upgradeLevel;
    }
}
