using UnityEngine;
using UnityEngine.Events;

public class NPCReaction231 : MonoBehaviour
{
    [SerializeField] private NPCMemory231 memory;
    [SerializeField] private string eventFactId;
    [SerializeField] private UnityEvent onFirstReaction;
    [SerializeField] private UnityEvent onKnownEventReaction;

    public void ReactToWorldEvent()
    {
        bool known = memory != null && memory.Knows(eventFactId);
        if (known) onKnownEventReaction?.Invoke();
        else onFirstReaction?.Invoke();
    }
}
