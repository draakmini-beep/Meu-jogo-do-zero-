using System;
using UnityEngine;

[Serializable]
public class NPCRelationshipRecord231
{
    public string npcId;
    public int affinity;
    public int trust;
    public int fear;
    public int respect;

    public void ClampValues()
    {
        affinity = Mathf.Clamp(affinity, -100, 100);
        trust = Mathf.Clamp(trust, 0, 100);
        fear = Mathf.Clamp(fear, 0, 100);
        respect = Mathf.Clamp(respect, 0, 100);
    }
}
