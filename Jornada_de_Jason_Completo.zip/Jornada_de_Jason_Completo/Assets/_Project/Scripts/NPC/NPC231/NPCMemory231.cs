using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class NPCMemoryFact231
{
    public string factId;
    public string subjectId;
    [TextArea] public string summary;
    public int worldDay;
    public float importance = 1f;
}

public class NPCMemory231 : MonoBehaviour
{
    [SerializeField, Min(1)] private int maximumFacts = 30;
    [SerializeField] private List<NPCMemoryFact231> facts =
        new List<NPCMemoryFact231>();

    public bool Remember(NPCMemoryFact231 fact)
    {
        if (fact == null || string.IsNullOrWhiteSpace(fact.factId))
            return false;

        int existing = facts.FindIndex(x => x != null && x.factId == fact.factId);
        if (existing >= 0) facts[existing] = Copy(fact);
        else facts.Add(Copy(fact));

        while (facts.Count > maximumFacts)
        {
            int least = 0;
            for (int i = 1; i < facts.Count; i++)
                if (facts[i] == null ||
                    (facts[least] != null &&
                     facts[i].importance < facts[least].importance))
                    least = i;
            facts.RemoveAt(least);
        }
        return true;
    }

    public bool Knows(string factId) =>
        facts.Exists(x => x != null && x.factId == factId);

    public List<NPCMemoryFact231> Snapshot()
    {
        var copy = new List<NPCMemoryFact231>();
        foreach (var fact in facts)
            if (fact != null) copy.Add(Copy(fact));
        return copy;
    }

    public void Restore(List<NPCMemoryFact231> snapshot)
    {
        facts.Clear();
        if (snapshot == null) return;
        foreach (var fact in snapshot)
            if (fact != null) facts.Add(Copy(fact));
    }

    private static NPCMemoryFact231 Copy(NPCMemoryFact231 source) =>
        new NPCMemoryFact231 {
            factId = source.factId, subjectId = source.subjectId,
            summary = source.summary, worldDay = source.worldDay,
            importance = source.importance
        };
}
