using System;
using UnityEngine;

[Serializable]
public class NPCScheduleEntry231
{
    [Range(0, 23)] public int startHour;
    [Range(0, 23)] public int endHour;
    public string activityId;
    public Transform destination;
}

[CreateAssetMenu(fileName = "NPCSchedule", menuName = "Jason/NPC/Daily Schedule")]
public class NPCDailySchedule231 : ScriptableObject
{
    public NPCScheduleEntry231[] entries;

    public NPCScheduleEntry231 GetEntry(int hour)
    {
        if (entries == null || hour < 0 || hour > 23) return null;

        foreach (var entry in entries)
        {
            if (entry == null) continue;
            bool active = entry.startHour <= entry.endHour
                ? hour >= entry.startHour && hour < entry.endHour
                : hour >= entry.startHour || hour < entry.endHour;

            if (active) return entry;
        }
        return null;
    }
}
