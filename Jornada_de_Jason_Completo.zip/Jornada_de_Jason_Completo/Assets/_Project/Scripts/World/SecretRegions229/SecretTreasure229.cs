using UnityEngine;
using UnityEngine.Events;

public class SecretTreasure229 : MonoBehaviour
{
    [SerializeField] private string treasureId;
    [SerializeField] private bool opened;
    [SerializeField] private UnityEvent onRewardRequested;

    public bool TryOpen()
    {
        if (opened || string.IsNullOrWhiteSpace(treasureId))
            return false;

        // O evento deve solicitar uma recompensa ao serviço transacional central.
        // Só confirme opened após o serviço confirmar a entrega em produção.
        onRewardRequested?.Invoke();
        return true;
    }

    public void ConfirmRewardCommitted() => opened = true;
    public void RestoreOpened(bool value) => opened = value;
}
