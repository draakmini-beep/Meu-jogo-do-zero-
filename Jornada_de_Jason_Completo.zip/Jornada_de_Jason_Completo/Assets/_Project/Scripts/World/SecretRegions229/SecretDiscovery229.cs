using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

[Serializable]
public class SecretDiscoveryRecord229
{
    public string discoveryId;
    public bool discovered;
}

public class SecretDiscovery229 : MonoBehaviour
{
    [SerializeField] private string discoveryId;
    [SerializeField] private UnityEvent onFirstDiscovery;
    [SerializeField] private List<SecretDiscoveryRecord229> records =
        new List<SecretDiscoveryRecord229>();

    public bool Discover()
    {
        if (string.IsNullOrWhiteSpace(discoveryId)) return false;

        var record = records.Find(x => x.discoveryId == discoveryId);
        if (record == null)
        {
            record = new SecretDiscoveryRecord229 { discoveryId = discoveryId };
            records.Add(record);
        }

        if (record.discovered) return false;
        record.discovered = true;
        onFirstDiscovery?.Invoke();
        return true;
    }

    public List<SecretDiscoveryRecord229> CreateSnapshot()
    {
        var copy = new List<SecretDiscoveryRecord229>();
        foreach (var r in records)
            copy.Add(new SecretDiscoveryRecord229 {
                discoveryId = r.discoveryId, discovered = r.discovered
            });
        return copy;
    }

    public void Restore(List<SecretDiscoveryRecord229> snapshot)
    {
        records.Clear();
        if (snapshot == null) return;
        foreach (var r in snapshot)
            if (r != null)
                records.Add(new SecretDiscoveryRecord229 {
                    discoveryId = r.discoveryId, discovered = r.discovered
                });
    }
}
