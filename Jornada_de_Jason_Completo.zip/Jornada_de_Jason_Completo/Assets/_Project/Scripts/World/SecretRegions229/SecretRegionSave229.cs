using System;
using System.Collections.Generic;

[Serializable]
public class SecretRegionSave229
{
    public List<string> unlockedRegionIds = new List<string>();
    public List<string> discoveredLocationIds = new List<string>();
    public List<string> completedSecretEventIds = new List<string>();
}
