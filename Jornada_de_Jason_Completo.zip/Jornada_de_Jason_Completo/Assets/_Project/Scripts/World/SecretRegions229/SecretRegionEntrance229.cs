using UnityEngine;
using UnityEngine.Events;

[RequireComponent(typeof(Collider))]
public class SecretRegionEntrance229 : MonoBehaviour
{
    [SerializeField] private SecretRegionProfile229 region;
    [SerializeField] private string playerTag = "Player";
    [SerializeField] private UnityEvent onRegionEntered;
    [SerializeField] private UnityEvent onAccessDenied;
    private bool activated;

    private void Reset() => GetComponent<Collider>().isTrigger = true;

    public bool TryEnter(SecretRegionAccessContext229 context)
    {
        if (activated || !SecretRegionAccess229.CanAccess(region, context))
        {
            onAccessDenied?.Invoke();
            return false;
        }

        activated = true;
        onRegionEntered?.Invoke();
        return true;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag(playerTag)) return;
        // A cena deve chamar TryEnter com dados reais de missão, chave e nível.
        // Não inventamos acesso ao inventário ou ao sistema de missões aqui.
    }

    public void ResetEntrance() => activated = false;
}
