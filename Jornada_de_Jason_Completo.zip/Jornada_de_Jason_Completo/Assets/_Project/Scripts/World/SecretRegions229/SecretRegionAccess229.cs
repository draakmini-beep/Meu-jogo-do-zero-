using System;
using UnityEngine;

[Serializable]
public class SecretRegionAccessContext229
{
    public string completedQuestId;
    public string ownedKeyId;
    public int playerLevel;
}

public static class SecretRegionAccess229
{
    public static bool CanAccess(
        SecretRegionProfile229 profile,
        SecretRegionAccessContext229 context)
    {
        if (profile == null || !profile.IsValid() || context == null)
            return false;

        if (context.playerLevel < profile.requiredPlayerLevel)
            return false;

        if (!string.IsNullOrEmpty(profile.requiredQuestId) &&
            profile.requiredQuestId != context.completedQuestId)
            return false;

        if (!string.IsNullOrEmpty(profile.requiredKeyId) &&
            profile.requiredKeyId != context.ownedKeyId)
            return false;

        return true;
    }
}
