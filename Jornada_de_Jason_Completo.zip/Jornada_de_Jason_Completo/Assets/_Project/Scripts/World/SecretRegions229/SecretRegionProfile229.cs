using UnityEngine;

[CreateAssetMenu(fileName = "SecretRegion", menuName = "Jason/World/Secret Region")]
public class SecretRegionProfile229 : ScriptableObject
{
    public string regionId;
    public string displayName;
    [TextArea] public string description;
    public string requiredQuestId;
    public string requiredKeyId;
    [Min(0)] public int requiredPlayerLevel;
    public Sprite mapIcon;
    public bool IsValid() =>
        !string.IsNullOrWhiteSpace(regionId) &&
        !string.IsNullOrWhiteSpace(displayName);
}
