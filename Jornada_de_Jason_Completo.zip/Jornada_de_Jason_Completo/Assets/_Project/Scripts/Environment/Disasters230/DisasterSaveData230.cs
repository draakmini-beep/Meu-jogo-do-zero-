using System;

[Serializable]
public class DisasterSaveData230
{
    public string activeDisasterId;
    public bool disasterActive;
    public float remainingSeconds;
    public float floodNormalizedLevel;
}
