using System;
using UnityEngine;
using UnityEngine.Events;

public class DisasterRuntime230 : MonoBehaviour
{
    [SerializeField] private DisasterProfile230 profile;
    [SerializeField] private UnityEvent onStarted;
    [SerializeField] private UnityEvent onEnded;

    public event Action<DisasterProfile230> Started;
    public event Action<DisasterProfile230> Ended;
    public bool IsActive { get; private set; }
    public float RemainingSeconds { get; private set; }

    public bool StartDisaster(DisasterProfile230 newProfile)
    {
        if (IsActive || newProfile == null || !newProfile.IsValid())
            return false;

        profile = newProfile;
        RemainingSeconds = profile.durationSeconds;
        IsActive = true;
        onStarted?.Invoke();
        Started?.Invoke(profile);
        return true;
    }

    public void StopDisaster()
    {
        if (!IsActive) return;
        IsActive = false;
        RemainingSeconds = 0f;
        onEnded?.Invoke();
        Ended?.Invoke(profile);
    }

    private void Update()
    {
        if (!IsActive) return;
        RemainingSeconds -= Time.deltaTime;
        if (RemainingSeconds <= 0f) StopDisaster();
    }

    public void RestoreState(bool active, float remaining)
    {
        IsActive = active && profile != null && profile.IsValid();
        RemainingSeconds = IsActive
            ? Mathf.Clamp(remaining, 0f, profile.durationSeconds) : 0f;
    }
}
