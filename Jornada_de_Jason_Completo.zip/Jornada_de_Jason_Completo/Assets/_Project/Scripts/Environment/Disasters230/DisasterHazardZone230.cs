using UnityEngine;
using UnityEngine.Events;

[RequireComponent(typeof(Collider))]
public class DisasterHazardZone230 : MonoBehaviour
{
    [SerializeField] private UnityEvent onPlayerEntered;
    [SerializeField] private UnityEvent onPlayerExited;
    [SerializeField] private string playerTag = "Player";

    private void Reset() => GetComponent<Collider>().isTrigger = true;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag(playerTag)) onPlayerEntered?.Invoke();
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag(playerTag)) onPlayerExited?.Invoke();
    }
}
