using UnityEngine;

public enum DisasterType230
{
    Thunderstorm,
    Blizzard,
    Flood,
    VolcanicEruption,
    Sandstorm,
    Heatwave
}

[CreateAssetMenu(fileName = "DisasterProfile", menuName = "Jason/Environment/Disaster")]
public class DisasterProfile230 : ScriptableObject
{
    public string disasterId;
    public DisasterType230 type;
    [Min(1f)] public float durationSeconds = 60f;
    [Min(0f)] public float intensity = 1f;
    public GameObject visualPrefab;
    public AudioClip ambientAudio;

    public bool IsValid() =>
        !string.IsNullOrWhiteSpace(disasterId) && durationSeconds > 0f;
}
