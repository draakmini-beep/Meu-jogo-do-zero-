using UnityEngine;
using UnityEngine.Events;

public class WeatherImpactBridge230 : MonoBehaviour
{
    [SerializeField] private UnityEvent onStormStarted;
    [SerializeField] private UnityEvent onBlizzardStarted;
    [SerializeField] private UnityEvent onHeatwaveStarted;
    [SerializeField] private UnityEvent onVolcanicEventStarted;
    [SerializeField] private UnityEvent onDisasterEnded;

    public void HandleStarted(DisasterProfile230 profile)
    {
        if (profile == null) return;

        switch (profile.type)
        {
            case DisasterType230.Thunderstorm:
            case DisasterType230.Sandstorm:
                onStormStarted?.Invoke();
                break;
            case DisasterType230.Blizzard:
                onBlizzardStarted?.Invoke();
                break;
            case DisasterType230.Heatwave:
                onHeatwaveStarted?.Invoke();
                break;
            case DisasterType230.VolcanicEruption:
                onVolcanicEventStarted?.Invoke();
                break;
        }
    }

    public void HandleEnded(DisasterProfile230 profile) =>
        onDisasterEnded?.Invoke();
}
