using UnityEngine;
using UnityEngine.Events;

public class LightningStrike230 : MonoBehaviour
{
    [SerializeField] private ParticleSystem lightningEffect;
    [SerializeField] private AudioSource thunderAudio;
    [SerializeField] private UnityEvent onStrike;

    public void Strike()
    {
        if (lightningEffect != null) lightningEffect.Play();
        if (thunderAudio != null) thunderAudio.Play();
        onStrike?.Invoke();
    }
}
