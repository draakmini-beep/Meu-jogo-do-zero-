using UnityEngine;

public class FloodVisualController230 : MonoBehaviour
{
    [SerializeField] private Transform waterSurface;
    [SerializeField] private float minimumHeight;
    [SerializeField] private float maximumHeight = 5f;
    [SerializeField, Range(0f, 1f)] private float normalizedLevel;

    public float NormalizedLevel => normalizedLevel;

    public void SetLevel(float value)
    {
        normalizedLevel = Mathf.Clamp01(value);
        if (waterSurface == null) return;

        Vector3 p = waterSurface.localPosition;
        p.y = Mathf.Lerp(minimumHeight, maximumHeight, normalizedLevel);
        waterSurface.localPosition = p;
    }
}
