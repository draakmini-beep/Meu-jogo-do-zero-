using UnityEngine;

public class CompanionFollow224 : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private CompanionProfile224 profile;
    [SerializeField] private float stoppingDistance = 1.5f;
    [SerializeField] private float rotationSpeed = 8f;

    public void SetTarget(Transform newTarget) => target = newTarget;

    private void Update()
    {
        if (target == null || profile == null) return;

        Vector3 offset = transform.position - target.position;
        Vector3 desired = target.position -
            target.forward * profile.followDistance +
            target.right * Mathf.Sign(offset.x) * 1.2f;
        desired.y = transform.position.y;

        Vector3 delta = desired - transform.position;
        if (delta.magnitude > stoppingDistance)
            transform.position = Vector3.MoveTowards(transform.position,
                desired, profile.movementSpeed * Time.deltaTime);

        Vector3 look = target.position - transform.position;
        look.y = 0f;
        if (look.sqrMagnitude > 0.01f)
        {
            Quaternion rotation = Quaternion.LookRotation(look);
            transform.rotation = Quaternion.Slerp(transform.rotation,
                rotation, rotationSpeed * Time.deltaTime);
        }
    }
}
