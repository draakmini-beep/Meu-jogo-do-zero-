using UnityEngine;

public enum CompanionRole224 { Scout, Defender, Attacker, Healer }

[CreateAssetMenu(fileName = "CompanionProfile", menuName = "Jason/Companions/Profile")]
public class CompanionProfile224 : ScriptableObject
{
    public string companionId;
    public string companionName;
    public CompanionRole224 role;
    [Min(0.1f)] public float followDistance = 3f;
    [Min(0.1f)] public float movementSpeed = 4f;
    [Min(0f)] public float attackDamage = 8f;
    [Min(0f)] public float detectionRadius = 8f;
    public GameObject prefab;
}
