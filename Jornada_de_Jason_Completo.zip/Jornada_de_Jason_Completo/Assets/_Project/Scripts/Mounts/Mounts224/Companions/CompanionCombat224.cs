using UnityEngine;

public class CompanionCombat224 : MonoBehaviour
{
    [SerializeField] private CompanionProfile224 profile;
    [SerializeField] private Transform target;
    [SerializeField] private float attackCooldown = 1.5f;
    private float nextAttackTime;

    public void SetTarget(Transform enemy) => target = enemy;

    private void Update()
    {
        if (profile == null || target == null ||
            Time.time < nextAttackTime) return;

        float distance = Vector3.Distance(transform.position, target.position);
        if (distance > profile.detectionRadius) return;

        // Integration point: call the project's single authoritative enemy damage API.
        // This component intentionally does not create a second health/damage system.
        nextAttackTime = Time.time + attackCooldown;
    }
}
