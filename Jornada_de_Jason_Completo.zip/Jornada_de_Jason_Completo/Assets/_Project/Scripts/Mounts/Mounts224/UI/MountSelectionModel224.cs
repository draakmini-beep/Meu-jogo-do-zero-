using System.Collections.Generic;
using UnityEngine;

public class MountSelectionModel224 : MonoBehaviour
{
    [SerializeField] private MountRegistry224 registry;
    [SerializeField] private string activeMountInstanceId;

    public string ActiveMountInstanceId => activeMountInstanceId;

    public bool SelectMount(string instanceId)
    {
        if (registry == null ||
            !registry.TryGet(instanceId, out var record) ||
            record == null || !record.tamed || !record.unlocked)
            return false;

        activeMountInstanceId = instanceId;
        return true;
    }
}
