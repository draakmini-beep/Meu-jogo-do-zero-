using UnityEngine;

[CreateAssetMenu(fileName = "TamingProfile", menuName = "Jason/Mounts/Taming Profile")]
public class TamingProfile224 : ScriptableObject
{
    [Min(0f)] public float trustRequired = 100f;
    [Min(0f)] public float trustPerFeeding = 20f;
    [Min(0f)] public float feedingCooldown = 2f;
    public string requiredFoodItemId;
}
