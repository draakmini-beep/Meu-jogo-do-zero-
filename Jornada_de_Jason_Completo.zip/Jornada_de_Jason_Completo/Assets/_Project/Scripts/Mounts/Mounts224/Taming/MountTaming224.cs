using UnityEngine;

public class MountTaming224 : MonoBehaviour
{
    [SerializeField] private TamingProfile224 tamingProfile;
    [SerializeField] private MountRecord224 record;
    private float nextFeedingTime;

    public bool TryFeed(string foodItemId)
    {
        if (tamingProfile == null || record == null ||
            record.tamed || Time.time < nextFeedingTime ||
            foodItemId != tamingProfile.requiredFoodItemId)
            return false;

        nextFeedingTime = Time.time + tamingProfile.feedingCooldown;
        record.trust = Mathf.Clamp(record.trust + tamingProfile.trustPerFeeding,
            0f, tamingProfile.trustRequired);

        if (record.trust >= tamingProfile.trustRequired)
        {
            record.tamed = true;
            record.unlocked = true;
        }
        return true;
    }

    public MountRecord224 GetRecordCopy()
    {
        return record == null ? null : record.Clone();
    }

    public void Initialize(MountRecord224 value)
    {
        record = value == null ? null : value.Clone();
    }
}
