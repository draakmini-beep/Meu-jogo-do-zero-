using System;

[Serializable]
public class MountRecord224
{
    public string instanceId;
    public string mountId;
    public string nickname;
    public float health;
    public float stamina;
    public float trust;
    public bool tamed;
    public bool unlocked;

    public MountRecord224 Clone()
    {
        return (MountRecord224)MemberwiseClone();
    }
}
