using System.Collections.Generic;
using UnityEngine;

public class MountRegistry224 : MonoBehaviour
{
    private readonly Dictionary<string, MountRecord224> records =
        new Dictionary<string, MountRecord224>();

    public bool Register(MountRecord224 record)
    {
        if (record == null || string.IsNullOrWhiteSpace(record.instanceId) ||
            records.ContainsKey(record.instanceId)) return false;
        records.Add(record.instanceId, record.Clone());
        return true;
    }

    public bool TryGet(string instanceId, out MountRecord224 record)
    {
        if (records.TryGetValue(instanceId, out var stored))
        {
            record = stored.Clone();
            return true;
        }
        record = null;
        return false;
    }

    public bool UpdateRecord(MountRecord224 record)
    {
        if (record == null || string.IsNullOrWhiteSpace(record.instanceId) ||
            !records.ContainsKey(record.instanceId)) return false;
        records[record.instanceId] = record.Clone();
        return true;
    }

    public List<MountRecord224> CreateSnapshot()
    {
        var snapshot = new List<MountRecord224>();
        foreach (var record in records.Values) snapshot.Add(record.Clone());
        return snapshot;
    }

    public void Restore(List<MountRecord224> snapshot)
    {
        records.Clear();
        if (snapshot == null) return;
        foreach (var record in snapshot) Register(record);
    }
}
