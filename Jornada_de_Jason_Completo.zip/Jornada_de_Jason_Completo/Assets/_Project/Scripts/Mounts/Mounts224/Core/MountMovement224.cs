using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class MountMovement224 : MonoBehaviour
{
    [SerializeField] private MountController224 mount;
    [SerializeField] private Transform cameraTransform;
    [SerializeField] private float turnSpeed = 180f;
    [SerializeField] private float gravity = -20f;
    private CharacterController controller;
    private float verticalVelocity;
    private Vector2 input;

    private void Awake()
    {
        controller = GetComponent<CharacterController>();
        if (mount == null) mount = GetComponent<MountController224>();
    }

    // Connect this method to the game's existing mobile input layer.
    public void SetMoveInput(Vector2 value)
    {
        input = Vector2.ClampMagnitude(value, 1f);
    }

    private void Update()
    {
        if (mount == null || mount.Profile == null || controller == null) return;

        Vector3 forward = cameraTransform != null
            ? Vector3.ProjectOnPlane(cameraTransform.forward, Vector3.up).normalized
            : Vector3.forward;
        Vector3 right = cameraTransform != null
            ? Vector3.ProjectOnPlane(cameraTransform.right, Vector3.up).normalized
            : Vector3.right;

        Vector3 direction = forward * input.y + right * input.x;
        if (direction.sqrMagnitude > 0.01f)
        {
            Quaternion target = Quaternion.LookRotation(direction.normalized);
            transform.rotation = Quaternion.RotateTowards(
                transform.rotation, target, turnSpeed * Time.deltaTime);
        }

        float speed = mount.IsExhausted ? mount.Profile.moveSpeed * 0.45f :
            mount.Profile.moveSpeed;

        if (input.sqrMagnitude > 0.01f) mount.TryConsumeStamina(Time.deltaTime);
        else mount.RecoverStamina(Time.deltaTime);

        if (controller.isGrounded && verticalVelocity < 0f) verticalVelocity = -2f;
        verticalVelocity += gravity * Time.deltaTime;

        Vector3 movement = direction.normalized * speed * input.magnitude;
        movement.y = verticalVelocity;
        controller.Move(movement * Time.deltaTime);
    }
}
