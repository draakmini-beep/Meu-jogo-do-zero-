using UnityEngine;

public class MountController224 : MonoBehaviour
{
    [SerializeField] private MountProfile224 profile;
    [SerializeField] private Transform riderMountPoint;
    [SerializeField] private float currentStamina = 100f;
    [SerializeField] private float currentHealth = 100f;

    public MountProfile224 Profile => profile;
    public float StaminaNormalized => profile == null ? 0f :
        Mathf.Clamp01(currentStamina / profile.maximumStamina);
    public bool IsExhausted => currentStamina <= 0f;

    private void Awake()
    {
        if (profile != null)
        {
            currentStamina = profile.maximumStamina;
            currentHealth = profile.maximumHealth;
        }
    }

    public bool CanRide()
    {
        return profile != null && currentHealth > 0f;
    }

    public bool TryConsumeStamina(float deltaTime)
    {
        if (profile == null || currentStamina <= 0f) return false;
        currentStamina = Mathf.Max(0f,
            currentStamina - profile.staminaDrainPerSecond * Mathf.Max(0f, deltaTime));
        return currentStamina > 0f;
    }

    public void RecoverStamina(float deltaTime)
    {
        if (profile == null) return;
        currentStamina = Mathf.Min(profile.maximumStamina,
            currentStamina + profile.staminaRecoveryPerSecond * Mathf.Max(0f, deltaTime));
    }

    public void ApplyDamage(float amount)
    {
        currentHealth = Mathf.Max(0f, currentHealth - Mathf.Max(0f, amount));
    }

    public Transform GetRiderMountPoint() => riderMountPoint;

    public void RestoreVitals(float health, float stamina)
    {
        if (profile == null) return;
        currentHealth = Mathf.Clamp(health, 0f, profile.maximumHealth);
        currentStamina = Mathf.Clamp(stamina, 0f, profile.maximumStamina);
    }
}
