using UnityEngine;

public enum MountSpecies224 { Horse, Wolf, Deer, Bear, Dragon, FantasyCreature }
public enum MountTemperament224 { Calm, Cautious, Aggressive, Playful }

[CreateAssetMenu(fileName = "MountProfile", menuName = "Jason/Mounts/Mount Profile")]
public class MountProfile224 : ScriptableObject
{
    public string mountId;
    public string displayName;
    public MountSpecies224 species;
    public MountTemperament224 temperament;
    [Min(0.1f)] public float moveSpeed = 7f;
    [Min(1f)] public float maximumStamina = 100f;
    [Min(1f)] public float maximumHealth = 100f;
    [Min(0f)] public float staminaDrainPerSecond = 8f;
    [Min(0f)] public float staminaRecoveryPerSecond = 5f;
    public GameObject worldPrefab;
    public Sprite icon;

    public bool IsValid()
    {
        return !string.IsNullOrWhiteSpace(mountId) &&
               !string.IsNullOrWhiteSpace(displayName) &&
               moveSpeed > 0f && maximumStamina > 0f && maximumHealth > 0f;
    }
}
