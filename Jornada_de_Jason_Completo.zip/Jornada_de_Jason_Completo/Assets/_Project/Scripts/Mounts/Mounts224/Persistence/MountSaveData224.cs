using System;
using System.Collections.Generic;

[Serializable]
public class MountSaveData224
{
    public List<MountRecord224> ownedMounts = new List<MountRecord224>();
    public string activeMountInstanceId;
    public string activeCompanionId;
}
