# A Jornada de Jason: Ecos de Yarin — projeto completo (scripts + fase de teste + build Android)

## Gerar o APK em 4 passos

1. **Unity Hub:** instale o **Unity 6 (6000.x)** com os módulos **Android Build Support**, **Android SDK & NDK Tools** e **OpenJDK**.
2. **Crie um projeto novo** com o template **3D (URP)** e feche o Editor. Copie as pastas `Assets` e `Packages` deste pacote para dentro do projeto (mescle, se perguntar).
   - Se o projeto novo já tiver um `Packages/manifest.json`, **adicione** a linha `"com.unity.ai.navigation": "2.0.5"` em vez de substituir o arquivo.
3. Abra o projeto e espere a importação. Se aparecer a janela de **TMP Essentials**, clique em *Import*. Confirme que o Console não tem erros vermelhos.
4. No menu: **Tools > A Jornada de Jason > Gerar Cena e Compilar APK (tudo de uma vez)**.
   O APK sai em `Builds/Android/JornadaDeJason.apk` (IL2CPP, ARM64, paisagem).

Para só ver a fase no Editor: **Tools > A Jornada de Jason > Gerar Cena Jogável de Teste** e aperte Play.

## O que a fase de teste tem
- Jason (joystick virtual à esquerda, arrasto da câmera na metade direita, botões Pular / Dash / Atirar / Arma).
- Rio com flutuabilidade: madeira boia, pedra e metal afundam, correnteza empurra blocos e o jogador.
- Placa de pressão que abre o portão com o peso da pedra (2,5).
- Três armas: Manopla Gravitacional, Canhão de Impacto e Cajado de Gelo (cria plataformas sobre o rio).
- Power-up de Gravidade Zero, moedas salvas em JSON e um inimigo que patrulha, persegue e ataca.

**Teclado no Editor:** WASD move, Espaço pula, Shift dash, F atira, E troca de arma, botão direito do mouse gira a câmera.

## Scripts novos (`Assets/_Project/Scripts/Core`)
| Pasta | Scripts |
|---|---|
| Input | `JasonInput`, `VirtualJoystick`, `TouchLookZone` |
| Player | `JasonController`, `TouchOrbitCamera` |
| Combat | `HealthSystem` |
| Water | `WaterBuoyancy` |
| Weapons | `WeaponSystem` |
| Puzzles | `PressurePlatePuzzle`, `MapPowerUp` |
| Enemies | `EnemyGuardAI` |
| NPC | `AllyNPC` |
| UI | `LevelLoader`, `SettingsManager`, `CoinsLabel` |
| Save / Shop | `JasonSave`, `SkinCatalog`, `SkinShopManager`, `SkinApplier`, `CoinPickup` |

Todos usam o namespace `JornadaDeJason` e não colidem com os 82 scripts das etapas 223–236.

## Peso/densidade dos blocos (WaterBuoyancy)
Densidade = massa do Rigidbody / volume da caixa do objeto. Com água = 1: madeira 0,6 boia; pedra 2,6 e metal 7,8 afundam. Para um bloco 1×1×1, a massa é a densidade.

## Montagem das telas que a fase de teste NÃO cria (menu, loja, carregamento, NPC)
Estes scripts já estão prontos, mas as telas precisam ser desenhadas no Canvas:

**Carregamento (`LevelLoader`)**
1. Canvas > Panel "TelaCarregamento" (desligado) com um `Slider` (barra), um `TMP_Text` (porcentagem) e um `TMP_Text` (dica).
2. Adicione `LevelLoader` ao Canvas e arraste esses itens para os campos.
3. No botão "Jogar": On Click → `LevelLoader.LoadLevel` com o nome da cena (ela precisa estar em Build Profiles).

**Configurações (`SettingsManager`)**
1. Painel com 4 `Slider` (geral, música, SFX, sensibilidade), um `TMP_Dropdown` de qualidade (Baixa, Média, Alta) e um de idioma.
2. Adicione `SettingsManager` ao painel e arraste os controles. (Mixer é opcional: parâmetros expostos `MusicVolume` e `SFXVolume`.)

**Loja de skins (`SkinShopManager`)**
1. Crie o catálogo: Assets > Create > Jornada de Jason > Catálogo de Skins. A 1ª skin custa 0. Crie um Material por skin (Explorador, Cavaleiro de Cristal, Armadura Vulcânica).
2. Coloque um modelo do Jason num palco com câmera própria (ou RenderTexture), arraste o pivô e os Renderers para o `SkinShopManager`.
3. Botões: Anterior → `Previous`, Próxima → `Next`, Comprar/Equipar → `OnActionButton`.
4. Nas fases, adicione `SkinApplier` ao Jason com o mesmo catálogo.

**NPCs (`AllyNPC`)**
1. NPC com um Collider "Is Trigger" maior que ele. Painel de diálogo com 2 `TMP_Text` e um botão "Próximo" → `NextLine`.
2. Escreva as falas no Inspector (dicas de puzzle da Eldrin, loja da Lyra). Aldeões: marque *Needs Rescue* e chame `Rescue()` do puzzle.

## Integração com as etapas 223–236
- `HealthSystem` é a autoridade de vida: ligue `CombatComboController234` (`onComboHit`) ao dano via `HealthSystem.TakeDamage`.
- `CinematicDirector235` → `onCinematicStarted`: chame `JasonController.SetControlEnabled(false)`; `onCinematicFinished`: `true`.
- Super Força: `WeaponSystem` já multiplica por `MapPowerUp.StrengthMultiplier`.

## Limites conhecidos (sem rodar o Unity, não dá para garantir mais)
- **Não compilei nem testei no Unity.** O código foi revisado, mas pode haver pequenos erros de compilação ao importar; mande o texto do Console que eu corrijo.
- A fase é de teste, feita com formas simples. As 5 regiões, modelos 3D low-poly, áudio e as fases finais precisam ser criados.
- Falta Visão Analítica, Escudo Cinético e Arco de Gancho (estão no GDD, não nos prompts A–E).
- Para publicar: assinatura (keystore), ícone e Android App Bundle.
