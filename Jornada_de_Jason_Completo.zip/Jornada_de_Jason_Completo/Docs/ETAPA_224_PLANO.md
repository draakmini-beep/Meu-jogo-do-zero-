# Etapa 224 — Plano de integração

## Montarias
- Criar perfis para cavalo, lobo, cervo, urso e criaturas fantásticas.
- Configurar `MountController224` e `MountMovement224` no prefab.
- Adicionar CharacterController, collider, Animator e pontos de sela.
- Criar fluxo de montar/desmontar que bloqueie o movimento a pé enquanto Jason estiver montado.
- Usar o mesmo input mobile existente.

## Domesticação
- Criar `TamingProfile224` para cada espécie.
- Configurar alimento necessário, confiança por alimentação e cooldown.
- Na integração final, primeiro reservar/consumir alimento por transação no inventário; só então conceder confiança.
- Persistir confiança, estado domesticado e ID de instância.

## Companheiros
- Criar perfil por companheiro.
- Definir papel: explorador, defensor, atacante ou curandeiro.
- Implementar estados Follow, Stay, Return, Assist e Disabled.
- Integrar navegação ao controlador de movimento compartilhado.
- Ligar combate ao HealthSystem/dano já existente, sem duplicar vida ou dano.

## Android
- Botões Montar/Desmontar, Chamar, Aguardar e Trocar companheiro.
- Alvos grandes para toque e suporte a paisagem.
- Reduzir atualizações de IA fora da câmera e limitar companheiros ativos em aparelhos modestos.

## Persistência
- Adicionar `MountSaveData224` ao save global existente.
- Persistir instâncias, saúde, stamina, confiança, nome, montaria ativa e companheiro ativo.
- Validar IDs desconhecidos e dados corrompidos durante o carregamento.
