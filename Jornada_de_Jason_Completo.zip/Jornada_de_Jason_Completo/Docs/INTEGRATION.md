# Guia de integração — Etapas 229 e 230

## Etapa 229 — Regiões secretas
- Crie `SecretRegionProfile229` para cada área oculta.
- Use `SecretRegionEntrance229` nos portais/passagens.
- Configure os requisitos de missão, chave e nível.
- Ligue `onRegionEntered` ao fluxo de transição do `WorldRegionManager` existente.
- `SecretDiscovery229` registra descobertas por ID; integre o snapshot ao SaveCoordinator.
- Recompensas devem ser entregues por transação idempotente do inventário/progressão.
- Não crie um segundo mapa, manager de regiões ou sistema de missões.

## Etapa 230 — Clima e desastres
- Use `DisasterProfile230` como configuração de cada desastre.
- `DisasterRuntime230` é um executor local de duração/estado; o agendamento deve
  vir do relógio/eventos do mundo já existentes (DayNightCycle/WeatherManager).
- `DisasterHazardZone230` emite eventos de entrada/saída; conecte-os ao HealthSystem
  oficial e a sistemas existentes de abrigo/temperatura.
- `FloodVisualController230` é apenas uma representação visual de nível de água.
  Não altera automaticamente física, navegação, drowning ou terreno.
- `LightningStrike230` é um ponto de efeito visual com UnityEvent; não calcula
  dano nem procura jogadores automaticamente.
- Evite outro relógio global, WeatherManager ou HealthSystem.

## Android
- Use volumes simples, VFX com limite de partículas e distância de ativação.
- Evite luzes em tempo real numerosas; prefira iluminação baked e efeitos baratos.
- Teste desempenho em aparelho de entrada e intermediário.
