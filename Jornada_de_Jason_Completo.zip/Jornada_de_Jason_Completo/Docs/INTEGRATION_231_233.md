# Integração das etapas 231–233

## 231 — NPCs
- NPCDailySchedule231 é um dado de agenda; ligue os pontos/horários ao sistema
  de movimento já existente. Não adicione outro NavMeshAgent executor.
- NPCMemory231 armazena fatos simples por ID. Defina política de expiração e
  limite de memória por NPC para evitar crescimento infinito.
- NPCReaction231 emite eventos Unity; conecte diálogo/reputação existentes.
- A simulação fora de cena deve ser data-only e coordenada pelos managers de
  mundo já existentes.

## 232 — Cidades
- SettlementUpgradeProfile232 define custos e pré-requisitos.
- SettlementUpgradeValidator232 apenas valida dados/contexto. O consumo de
  recursos e atualização do assentamento precisam ocorrer numa transação central.
- SettlementVisualStage232 controla somente apresentação visual; não é uma
  segunda autoridade de população, economia ou progresso.
- Use CivilizationWorldManager219 / SettlementRegistry219 já planejados.

## 233 — Consolidação
- ProjectReadinessReport233 executa verificações básicas em objetos atribuídos.
  Não substitui compilação, testes de cena, profiler ou build Android.
- Preencha referências no Inspector. A auditoria não descobre automaticamente
  todas as dependências do projeto.
- Teste primeiro no Editor e depois em dispositivos Android reais.
- APK só pode ser declarado pronto após build bem-sucedido e instalação/teste.
