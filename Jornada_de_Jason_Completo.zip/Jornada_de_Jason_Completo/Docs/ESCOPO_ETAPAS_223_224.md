# Registro das etapas 223 e 224

## Etapa 223 — Equipamentos, armas lendárias e personalização
Escopo anteriormente especificado:
- Raridades comum, incomum, rara, épica, lendária e mítica.
- Atributos de ataque, defesa, vida, stamina, crítico e velocidade.
- Armas elementais das cinco regiões.
- Armaduras e resistências elementais.
- Conjuntos, encantamentos, aprimoramentos e durabilidade.
- Slots de equipamento, aparência de Jason e interface Android.
- Integração com RPGInventory, RPGProgression e SaveCoordinator.

Os scripts individuais desta etapa não estavam disponíveis como arquivos no
ambiente ao montar o pacote consolidado. O escopo está documentado, mas não
deve ser confundido com código incluído ou integrado.

## Etapa 224 — Montarias e companheiros
Escopo anteriormente especificado:
- Montarias, vida, stamina e velocidade.
- Domesticação, alimentação e confiança.
- Companheiros que seguem Jason e auxiliam em combate.
- Seleção, inventário e salvamento de montarias.

Os scripts individuais desta etapa não estavam disponíveis como arquivos no
ambiente ao montar o pacote consolidado. O escopo está documentado, mas não
deve ser confundido com código incluído ou integrado.
