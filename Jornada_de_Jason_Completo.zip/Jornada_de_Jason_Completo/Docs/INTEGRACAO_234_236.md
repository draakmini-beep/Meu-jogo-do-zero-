# Guia de integração

## Etapa 234 — Combate
- `CombatComboController234` controla apenas a janela/ordem dos golpes e emite
  UnityEvents. Ligue `onComboHit` ao método de ataque já existente.
- `ElementalSkill234` valida cooldown e custo configurado localmente. Para stamina
  ou mana reais, desligue o custo local e faça a cobrança no manager central
  antes de chamar `ActivateAfterCostCommitted()`.
- `DodgeCounterWindow234` é apenas uma janela temporal. O sistema de combate
  existente deve confirmar que o ataque inimigo foi evitado e chamar
  `RegisterSuccessfulDodge()`.
- Não deixe este pacote aplicar dano diretamente. `HealthSystem` continua sendo
  a autoridade de vida.

## Etapa 235 — Cinemáticas
- Configure `CinematicSequence235` com planos em ordem.
- Arraste câmeras e transforms de destino no Inspector.
- `CinematicDirector235` move a câmera por interpolação simples. Para Timeline,
  Cinemachine ou animações complexas, use o sistema nativo já instalado e
  mantenha este director desativado.
- Ligue `onCinematicStarted`/`onCinematicFinished` ao bloqueio de input,
  HUD e áudio existentes.
- Não destrua o jogador nem altere cenas sem integrar o SaveCoordinator.

## Etapa 236 — Auditoria
- O auditor Editor verifica itens básicos e referências configuradas.
- Não substitui testes automatizados, profiling, testes de aparelho, revisão
  de colisores, Addressables ou análise de crash.
- Menu: Tools > A Jornada de Jason > Auditoria Etapa 236.
- Corrija erros antes de gerar build Android.
