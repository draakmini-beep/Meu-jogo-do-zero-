# Testes finais — Etapa 236

## Editor
- [ ] Abrir cada cena principal sem erros no Console.
- [ ] Verificar Missing Script em todos os prefabs e cenas.
- [ ] Testar novo jogo, salvar, fechar, reabrir e carregar.
- [ ] Testar combate normal, combos, esquiva, habilidades e chefes.
- [ ] Testar missões, diálogos, resgate de Yarin e encerramento.
- [ ] Testar todas as regiões, portais e eventos climáticos.
- [ ] Testar menus, pausa, configurações e HUD.

## Android físico
- [ ] Instalar build limpa.
- [ ] Testar controles touch em orientação paisagem.
- [ ] Testar Low/Medium/High.
- [ ] Medir FPS, memória, temperatura e tempo de carregamento.
- [ ] Testar suspensão/retorno do aplicativo.
- [ ] Testar armazenamento e restauração do progresso.
- [ ] Verificar logs de falhas e tela preta.

## Antes de publicar
- [ ] Definir identificador de pacote e versão.
- [ ] Configurar assinatura de release.
- [ ] Revisar permissões.
- [ ] Gerar build release e instalar em aparelho de teste.
- [ ] Guardar backup do projeto e da chave de assinatura.
