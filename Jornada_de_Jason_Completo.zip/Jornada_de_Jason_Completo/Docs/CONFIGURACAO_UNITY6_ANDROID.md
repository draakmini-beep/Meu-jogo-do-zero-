# Configuração inicial — Unity 6 / Android

Este pacote reúne scripts e documentação recuperados das etapas 223–236. Ele **não é um projeto Unity completo pronto para build**: os arquivos-fonte disponíveis não incluem todas as cenas, prefabs, modelos, texturas, áudio, metas de assets nem configurações completas de ProjectSettings.

1. Crie um projeto 3D (URP) no Unity 6.
2. Feche o Editor e copie a pasta `Assets` deste pacote para a raiz do projeto.
3. Compare/mescle `Packages/manifest.json` com o manifest do projeto; não substitua cegamente se já houver dependências.
4. Reabra o projeto e aguarde a importação.
5. Corrija erros de compilação/dependências antes de montar cenas.
6. Instale Android Build Support (SDK, NDK e OpenJDK) pelo Unity Hub.
7. Em Build Profiles, selecione Android, configure orientação, identificador e arquitetura; faça primeiro um build de teste.
8. Use `Assets/Editor/JasonProjectAudit236.cs` (se presente) e os checklists em `Docs` para auditoria.

## Limites conhecidos
- Não há garantia de compilação: os scripts precisam ser integrados às APIs/sistemas anteriores e validados no Editor.
- Não foram recuperadas cenas principais prontas nem todos os recursos visuais/sonoros.
- APK não foi gerado; isso exige Unity instalado e build Android executado/testado.
