# A Jornada de Jason: Ecos de Yarin — preparação de build Android

Este pacote contém os 82 scripts C# recuperados das etapas 223–236, documentação e manifest de pacotes, além de um comando de build Android para o Editor Unity.

## Estado real do material recebido

**Ainda não é possível entregar um APK funcional a partir dos ZIPs recebidos.** O pacote de origem contém scripts e documentos, mas não contém cenas `.unity`, prefabs, modelos 3D, texturas, áudio nem configurações completas de projeto. Também não há Unity Editor/Android Build Support disponível no ambiente em que este pacote foi preparado. Portanto, não foi executada nem validada uma compilação APK.

## Como continuar no Unity 6

1. Crie/abra um projeto 3D URP no Unity 6.
2. Copie as pastas `Assets` e `Packages` deste pacote para o projeto (mescle o `manifest.json`, sem apagar dependências que já existam).
3. Recupere ou crie as cenas, prefabs e recursos visuais/sonoros ausentes; adicione as cenas em **File > Build Profiles**.
4. Instale pelo Unity Hub: **Android Build Support**, **Android SDK & NDK Tools** e **OpenJDK**.
5. Aguarde a importação, corrija erros no Console e execute os testes documentados em `Docs/TESTES_MANUAIS_236.md`.
6. No menu **Tools > A Jornada de Jason > Build Android APK**, execute a compilação. O APK será salvo em `Builds/Android/JornadaDeJason.apk`.

O script de build não cria cenas nem substitui assets ausentes; ele apenas compila quando o projeto estiver completo e sem erros.
